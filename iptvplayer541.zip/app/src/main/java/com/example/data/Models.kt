package com.example.data

data class PlaylistItem(
    val id: Long = 0,
    val name: String,
    val type: String, // "M3U", "Xtream", "Stalker"
    val url: String = "",
    val username: String? = null,
    val password: String? = null,
    val macAddress: String? = null,
    val ipAddress: String? = null,
    val customIp: String? = null,
    val isActive: Boolean = true
)

data class ChannelItem(
    val id: Long = 0,
    val playlistId: Long,
    val name: String,
    val logoUrl: String = "",
    val streamUrl: String,
    val groupName: String,
    val type: String, // "Live"
    val hasCatchup: Boolean = false,
    val catchupDurationDays: Int = 0,
    val tvArchiveDuration: Int = 0,
    val tvArchiveType: String = "",
    val allowLocalTimeshift: Int = 0,
    val archiveDate: String = "",
    val allowPvr: Int = 0,
    val stalkerId: String = ""
)

data class HistoryItem(
    val id: Long = 0,
    val playlistId: Long,
    val channelName: String,
    val streamUrl: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class FavoriteItem(
    val id: Long = 0,
    val playlistId: Long,
    val channelName: String,
    val streamUrl: String
)

data class RecordingItem(
    val id: Long = 0,
    val playlistId: Long,
    val channelName: String,
    val streamUrl: String,
    val filepath: String,
    val programTitle: String,
    val scheduledAt: Long = System.currentTimeMillis(),
    val durationMinutes: Int,
    val isCompleted: Boolean = true
)

data class WatchProgress(
    val id: Long = 0,
    val playlistId: Long,
    val contentType: String, // "series" or "movie"
    val showId: String = "",
    val seasonNumber: Int = -1,
    val episodeNumber: Int = -1,
    val episodeId: String,
    val title: String,
    val posterUrl: String = "",
    val positionMs: Long,
    val durationMs: Long = 0,
    val lastWatchedAt: Long = System.currentTimeMillis()
)

data class EpgProgram(
    val title: String,
    val startTime: String, // HH:mm
    val endTime: String,   // HH:mm
    val description: String,
    val startHour: Int,
    val endHour: Int,
    val startTimestamp: Long = 0L,
    val endTimestamp: Long = 0L,
    val id: String = "",
    val realId: String = "",
    val markArchive: Int = 0
)

data class Cat(
    val id: String,
    val title: String
)

data class StalkerCategory(
    val id: String,
    val title: String,
    val isSeries: Boolean
)

data class EpgProgramItem(
    val id: String = "",
    val chId: String = "",
    val name: String,
    val description: String = "",
    val startTimestamp: Long = 0L, // Unix timestamp in millis
    val stopTimestamp: Long = 0L,  // Unix timestamp in millis
    val startTimeFormatted: String = "",
    val stopTimeFormatted: String = "",
    val realId: String = "",
    val markArchive: Int = 0
)

data class EpisodeItem(
    val name: String,
    val url: String,
    val duration: String = "",
    val season: String = "1"
)

class CatchupStreamException(override val message: String) : Exception(message)

enum class StalkerCmdFormat {
    JSON_XTREAM,
    STALKER_MEDIA,
    UNKNOWN
}

fun detectCmdFormat(rawCmd: String): StalkerCmdFormat {
    if (rawCmd.isBlank()) return StalkerCmdFormat.UNKNOWN

    var clean = rawCmd.trim()
    if (clean.startsWith("ffmpeg ")) {
        clean = clean.substringAfter("ffmpeg ").trim()
    }

    if (clean.startsWith("stalker://")) {
        try {
            val uri = android.net.Uri.parse(clean)
            val innerCmd = uri.getQueryParameter("cmd")
            if (!innerCmd.isNullOrEmpty()) {
                clean = innerCmd.trim()
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun checkJsonForStreamId(jsonStr: String): Boolean {
        val s = jsonStr.trim()
        if (!s.startsWith("{")) return false
        return try {
            val obj = org.json.JSONObject(s)
            obj.has("stream_id")
        } catch (e: Exception) {
            false
        }
    }

    if (checkJsonForStreamId(clean)) {
        return StalkerCmdFormat.JSON_XTREAM
    }

    var decoded = ""
    try {
        val bytes = android.util.Base64.decode(clean, android.util.Base64.DEFAULT)
        decoded = String(bytes, Charsets.UTF_8).trim()
    } catch (e: Exception) {
        try {
            val bytes = java.util.Base64.getDecoder().decode(clean)
            decoded = String(bytes, Charsets.UTF_8).trim()
        } catch (e2: Exception) {
            decoded = ""
        }
    }

    if (decoded.isNotEmpty() && checkJsonForStreamId(decoded)) {
        return StalkerCmdFormat.JSON_XTREAM
    }

    if (clean.contains("/media/", ignoreCase = true) || decoded.contains("/media/", ignoreCase = true)) {
        return StalkerCmdFormat.STALKER_MEDIA
    }

    return StalkerCmdFormat.UNKNOWN
}

/**
 * Extrait intelligemment le nom de la playlist depuis l'URL du portail Stalker.
 * 1. Supprime http:// et https://
 * 2. Extrait le Hostname (jusqu'au premier / ou :)
 * 3. Supprime www. au début
 * 4. Ajoute un suffixe incrémental (_2, _3, etc.) si le nom existe déjà.
 */
fun extractStalkerPlaylistNameFromUrl(portalUrl: String, existingNames: List<String> = emptyList()): String {
    val trimmed = portalUrl.trim()
    if (trimmed.isEmpty()) return "Stalker Portal"

    // 1 & 2. Supprime le protocole http:// et https://
    val clean = trimmed.replace(Regex("(?i)^https?://"), "")

    // 3. Extrait uniquement le HOSTNAME (après http(s):// jusqu'au premier / ou :)
    val hostname = clean.substringBefore("/").substringBefore(":")

    // 4. Nettoie le hostname : supprime www. au début
    var baseName = hostname.replace(Regex("(?i)^www\\."), "").trim()
    if (baseName.isEmpty()) {
        baseName = "Stalker Portal"
    }

    // 5 & 6. Utilise le nom ou ajoute un suffixe incrémental (_2, _3, etc.) si déjà existant
    var finalName = baseName
    var counter = 2
    val lowerExisting = existingNames.map { it.lowercase().trim() }
    while (lowerExisting.contains(finalName.lowercase().trim())) {
        finalName = "${baseName}_$counter"
        counter++
    }

    return finalName
}

fun getAutomaticEpgForChannel(channelName: String): List<EpgProgram> {
    val cal = java.util.Calendar.getInstance()
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.set(java.util.Calendar.MILLISECOND, 0)

    val cleanName = channelName.trim()
    val isSports = cleanName.contains("sport", ignoreCase = true) || cleanName.contains("foot", ignoreCase = true) || cleanName.contains("bein", ignoreCase = true) || cleanName.contains("canal+", ignoreCase = true)
    val isNews = cleanName.contains("news", ignoreCase = true) || cleanName.contains("info", ignoreCase = true) || cleanName.contains("bfm", ignoreCase = true) || cleanName.contains("cnews", ignoreCase = true)
    val isCinema = cleanName.contains("cine", ignoreCase = true) || cleanName.contains("film", ignoreCase = true) || cleanName.contains("movie", ignoreCase = true) || cleanName.contains("hbo", ignoreCase = true)
    val isKids = cleanName.contains("kid", ignoreCase = true) || cleanName.contains("toon", ignoreCase = true) || cleanName.contains("disney", ignoreCase = true) || cleanName.contains("gulli", ignoreCase = true)

    val scheduleTemplates = when {
        isSports -> listOf(
            Triple(0, 6, "Rediffusion : Match de Championnat" to "Revivez les meilleurs moments et actions du grand match de la semaine."),
            Triple(6, 9, "Morning Sport Club" to "Toute l'actualité sportive du matin, transferts et analyses."),
            Triple(9, 12, "Magazine Omnisports" to "Documentaires et coulisses des plus grands événements sportifs."),
            Triple(12, 14, "Direct : Journal des Sports" to "Les résultats en direct, points sur les classements et interviews."),
            Triple(14, 17, "Grand Format : Coupe d'Europe" to "Retour en images sur les grandes rencontres européennes."),
            Triple(17, 20, "Avant-Match & Débrief" to "Plateau d'experts, compositions d'équipes et statistiques clés."),
            Triple(20, 23, "DIRECT : Grand Match du Soir" to "Le choc au sommet en direct avec les commentaires exclusifs."),
            Triple(23, 24, "L'After Show & Synthèse" to "Analyses tactiques, réactions des entraîneurs et débats.")
        )
        isNews -> listOf(
            Triple(0, 6, "La Nuit de l'Info" to "Éditions en continu, points météo et récapitulatif international."),
            Triple(6, 9, "La Grande Matinale" to "Le direct de l'info, météo, revue de presse et invités politiques."),
            Triple(9, 12, "Le Direct 9h-12h" to "Suivi des grands événements mondiaux et reportages terrain."),
            Triple(12, 14, "L'Édition de la Mi-Journée" to "Le journal complet avec les correspondants en direct."),
            Triple(14, 17, "Débats & Analyse" to "Table ronde sur les grands enjeux économiques et de société."),
            Triple(17, 20, "Le Grand Journal du Soir" to "L'essentiel de l'information nationale et internationale décrypté."),
            Triple(20, 22, "Le Grand Débat Politique" to "Analyses approfondies avec éditorialistes et experts."),
            Triple(22, 24, "Soir Info & Perspectives" to "Bilan de la journée et premières pistes du lendemain.")
        )
        isCinema -> listOf(
            Triple(0, 2, "Cinéma Nocturne" to "Film d'auteur et thrillers psychologiques primés en festival."),
            Triple(2, 6, "Nuit des Courts-Métrages" to "Sélection des meilleurs films courts et indépendants."),
            Triple(6, 10, "Classiques du 7ème Art" to "Les chefs-d'œuvre restaurés qui ont marqué l'histoire du cinéma."),
            Triple(10, 13, "Ciné-Magazine & Coulisses" to "Interviews exclusives, tournages et secrets de réalisation."),
            Triple(13, 16, "Film Famille & Aventure" to "Un grand spectacle cinématographique pour tous les publics."),
            Triple(16, 20, "Blockbuster de l'Après-Midi" to "Action, cascades et grands effets spéciaux hollywoodiens."),
            Triple(20, 22, "Le Film Événement" to "Première diffusion télévisée du long-métrage à succès."),
            Triple(22, 24, "Frissons & Polar" to "Thriller sombre et haletant avec un casting exceptionnel.")
        )
        isKids -> listOf(
            Triple(0, 6, "Contes & Berceuses" to "Douces animations pour accompagner la nuit des tout-petits."),
            Triple(6, 9, "Le Club des Toons" to "Dessins animés énergiques et aventures drôles pour le réveil."),
            Triple(9, 12, "Les P'tits Aventuriers" to "Séries éducatives, découverte de la nature et sciences amusantes."),
            Triple(12, 14, "Ciné Mini" to "Long-métrage d'animation familial féerique et coloré."),
            Triple(14, 17, "Les Héros de l'Action" to "Super-héros, quêtes épiques et combats magiques."),
            Triple(17, 19, "Toons Express" to "Les séries préférées après l'école avec rires garantis."),
            Triple(19, 21, "La Grande Soirée Animée" to "Le rendez-vous dessin animé du soir en famille."),
            Triple(21, 24, "Manga & Légendes" to "Séries d'animation pour adolescents et passionnés.")
        )
        else -> listOf(
            Triple(0, 6, "Programmes de la Nuit" to "Sélection musicale, documentaires d'évasion et rediffusions."),
            Triple(6, 9, "Télématin & Infos" to "Magazine matinal, chroniques vie pratique, culture et météo."),
            Triple(9, 12, "Magazine Découverte" to "Évasion, patrimoine, gastronomie et portraits de passionnés."),
            Triple(12, 14, "Le Journal de 13h" to "L'actualité régionale et nationale, terroirs et reportages."),
            Triple(14, 17, "Documentaire & Société" to "Immersion dans les grandes aventures humaines et historiques."),
            Triple(17, 20, "Le Jeu & Divertissement" to "Quiz quotidien, jeux de culture générale et bonne humeur."),
            Triple(20, 21, "Le Grand Journal de 20h" to "Le grand rendez-vous d'information de référence."),
            Triple(21, 23, "La Grande Soirée Divertissement" to "Spectacle, grand jeu ou film du prime-time."),
            Triple(23, 24, "Débat & Libre Antenne" to "Discussion ouverte sur les sujets d'actualité du moment.")
        )
    }

    return scheduleTemplates.mapIndexed { idx, (startH, endH, prog) ->
        val startCal = cal.clone() as java.util.Calendar
        startCal.set(java.util.Calendar.HOUR_OF_DAY, startH)
        val endCal = cal.clone() as java.util.Calendar
        endCal.set(java.util.Calendar.HOUR_OF_DAY, endH)

        val startTs = startCal.timeInMillis
        val endTs = if (endH == 24) {
            endCal.set(java.util.Calendar.HOUR_OF_DAY, 23)
            endCal.set(java.util.Calendar.MINUTE, 59)
            endCal.set(java.util.Calendar.SECOND, 59)
            endCal.timeInMillis
        } else {
            endCal.timeInMillis
        }

        val startFormatted = String.format("%02d:00", startH)
        val endFormatted = if (endH == 24) "00:00" else String.format("%02d:00", endH)

        EpgProgram(
            title = prog.first,
            startTime = startFormatted,
            endTime = endFormatted,
            description = prog.second,
            startHour = startH,
            endHour = endH,
            startTimestamp = startTs,
            endTimestamp = endTs,
            id = "auto_${cleanName}_$idx",
            realId = "auto_${cleanName}_$idx",
            markArchive = 1
        )
    }
}



