package com.example.ui

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.Player
import androidx.media3.common.MediaItem
import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.json.JSONArray
import java.util.concurrent.TimeUnit
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.URLDecoder
import java.util.Collections

class IptvViewModel(application: Application) : AndroidViewModel(application) {

    private val backgroundScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.Main
    )

    private val playerPrefs = application.getSharedPreferences("player_prefs", android.content.Context.MODE_PRIVATE)

    private val _subtitlesEnabled = MutableStateFlow(playerPrefs.getBoolean("subtitles_enabled", true))
    val subtitlesEnabled: StateFlow<Boolean> = _subtitlesEnabled.asStateFlow()

    private val _subtitleStyleMode = MutableStateFlow(
        playerPrefs.getString("subtitle_style_mode", "Texte jaune #FFE000, contour noir") ?: "Texte jaune #FFE000, contour noir"
    )
    val subtitleStyleMode: StateFlow<String> = _subtitleStyleMode.asStateFlow()

    private val _subtitleSizeState = MutableStateFlow(
        playerPrefs.getString("subtitle_size_state", "Moyen") ?: "Moyen"
    )
    val subtitleSizeState: StateFlow<String> = _subtitleSizeState.asStateFlow()

    private val _subtitleTranslationEnabled = MutableStateFlow(playerPrefs.getBoolean("subtitle_translation_enabled", false))
    val subtitleTranslationEnabled: StateFlow<Boolean> = _subtitleTranslationEnabled.asStateFlow()

    private val _subtitleTargetLanguage = MutableStateFlow(
        playerPrefs.getString("subtitle_target_lang", com.google.mlkit.nl.translate.TranslateLanguage.ENGLISH) ?: com.google.mlkit.nl.translate.TranslateLanguage.ENGLISH
    )
    val subtitleTargetLanguage: StateFlow<String> = _subtitleTargetLanguage.asStateFlow()

    private val _resizeModeState = MutableStateFlow(playerPrefs.getInt("player_resize_mode", 0))
    val resizeModeState: StateFlow<Int> = _resizeModeState.asStateFlow()

    private val _playbackSpeedState = MutableStateFlow(playerPrefs.getFloat("player_playback_speed", 1.0f))
    val playbackSpeedState: StateFlow<Float> = _playbackSpeedState.asStateFlow()

    private val _imageEnhancementMode = MutableStateFlow(playerPrefs.getString("player_image_enhancement", "Désactivé") ?: "Désactivé")
    val imageEnhancementMode: StateFlow<String> = _imageEnhancementMode.asStateFlow()

    private val _activeVideoQuality = MutableStateFlow(playerPrefs.getString("player_video_quality", "Auto (UHD/FHD)") ?: "Auto (UHD/FHD)")
    val activeVideoQuality: StateFlow<String> = _activeVideoQuality.asStateFlow()

    private val _activeAudioFormat = MutableStateFlow(playerPrefs.getString("player_audio_format", "Stéréo (Défaut)") ?: "Stéréo (Défaut)")
    val activeAudioFormat: StateFlow<String> = _activeAudioFormat.asStateFlow()

    private val _preferredAudioLanguage = MutableStateFlow(playerPrefs.getString("player_preferred_audio_lang", "auto") ?: "auto")
    val preferredAudioLanguage: StateFlow<String> = _preferredAudioLanguage.asStateFlow()

    private val _preferredSubtitleLanguage = MutableStateFlow(playerPrefs.getString("player_preferred_subtitle_lang", "auto") ?: "auto")
    val preferredSubtitleLanguage: StateFlow<String> = _preferredSubtitleLanguage.asStateFlow()

    private val _brightnessLevel = MutableStateFlow(playerPrefs.getFloat("player_brightness", 1.0f))
    val brightnessLevel: StateFlow<Float> = _brightnessLevel.asStateFlow()

    private val _zoomLevel = MutableStateFlow(playerPrefs.getFloat("player_zoom", 1.0f))
    val zoomLevel: StateFlow<Float> = _zoomLevel.asStateFlow()

    // Flux de sous-titres distincts pour éviter tout conflit ou écrasement intempestif
    private val _nativeSubtitleText = MutableStateFlow<String?>(null)
    private val _translatedNativeSubtitleText = MutableStateFlow<String?>(null)

    private val _voiceSubtitleText = MutableStateFlow<String?>(null)
    private val _translatedVoiceSubtitleText = MutableStateFlow<String?>(null)

    private val _translatedSubtitleText = MutableStateFlow<String?>(null)
    val translatedSubtitleText: StateFlow<String?> = _translatedSubtitleText.asStateFlow()
    val externalTranslatedSubtitle: StateFlow<String?> = _translatedSubtitleText.asStateFlow()
    val _externalTranslatedSubtitle: StateFlow<String?> get() = externalTranslatedSubtitle

    private val _currentSubtitleText = MutableStateFlow<String?>(null)
    val currentSubtitleText: StateFlow<String?> = _currentSubtitleText.asStateFlow()

    /**
     * Coordonne l'affichage des sous-titres sans collision.
     * Si les sous-titres vocaux sont actifs et transcrits, ils s'affichent en priorité.
     * Si les sous-titres vocaux sont silencieux, les sous-titres natifs du flux prennent le relais sans coupure.
     */
    private fun syncSubtitleDisplay() {
        if (_voiceSubtitlesEnabled.value) {
            val voiceRaw = _voiceSubtitleText.value
            val voiceTrans = _translatedVoiceSubtitleText.value
            if (!voiceRaw.isNullOrBlank()) {
                _currentSubtitleText.value = voiceRaw
                _translatedSubtitleText.value = if (_subtitleTranslationEnabled.value) {
                    if (!voiceTrans.isNullOrBlank()) voiceTrans else voiceRaw
                } else null
            } else {
                _currentSubtitleText.value = null
                _translatedSubtitleText.value = null
            }
            return
        } else if (_subtitlesEnabled.value) {
            _currentSubtitleText.value = _nativeSubtitleText.value
            _translatedSubtitleText.value = if (_subtitleTranslationEnabled.value) _translatedNativeSubtitleText.value else null
        } else {
            _currentSubtitleText.value = null
            _translatedSubtitleText.value = null
        }
    }

    /**
     * Détermine intelligemment la langue parlée sur la chaîne actuelle (via piste audio ou métadonnées du flux).
     */
    fun resolveChannelLanguageCode(): String {
        val channel = _selectedChannel.value
        val title = channel?.name.orEmpty()
        val group = channel?.groupName.orEmpty()
        val titleUpper = title.uppercase()
        val groupUpper = group.uppercase()

        val isExplicitlyFrench = titleUpper.contains(" FR") || titleUpper.contains("FR ") ||
                titleUpper.contains("(FR)") || titleUpper.contains("[FR]") || titleUpper.contains("FRANCE") ||
                groupUpper.contains("FRANCE") || groupUpper.contains("FRANCAIS") || groupUpper.contains("FRENCH")
        if (isExplicitlyFrench) return "fr"

        val isExplicitlyEnglish = titleUpper.contains(" EN") || titleUpper.contains("EN ") ||
                titleUpper.contains("(EN)") || titleUpper.contains("[EN]") || titleUpper.contains("UK") ||
                titleUpper.contains("USA") || groupUpper.contains("ENGLISH") || groupUpper.contains("USA") ||
                groupUpper.contains("UK")
        if (isExplicitlyEnglish) return "en"

        // 1. Détection prioritaire Arabe si le titre ou groupe contient "AR" ou "العربية" ou caractères arabes
        if (title.contains("العربية") || group.contains("العربية") ||
            titleUpper.contains("AR") && (
                titleUpper.contains("AR ") || titleUpper.contains("AR:") || titleUpper.contains("AR|") ||
                titleUpper.contains("AR -") || titleUpper.contains("AR-") || titleUpper.contains("[AR]") ||
                titleUpper.contains("(AR)") || titleUpper.startsWith("AR") || titleUpper.endsWith("AR") ||
                titleUpper.contains("|AR") || titleUpper.contains(" AR")
            ) ||
            title.any { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' } ||
            group.any { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' } ||
            groupUpper.contains("ARAB") || groupUpper.contains("OSN") ||
            groupUpper.contains("MBC") || groupUpper.contains("BEIN") || titleUpper.contains("BEIN") ||
            groupUpper.contains("ROTANA") || titleUpper.contains("ROTANA") ||
            groupUpper.contains("MOROCCO") || groupUpper.contains("MAROC") ||
            groupUpper.contains("ALGERI") || groupUpper.contains("TUNIS") || groupUpper.contains("EGYPT") ||
            groupUpper.contains("SAUDI") || groupUpper.contains("EMIRATES") || groupUpper.contains("QATAR") ||
            groupUpper.contains("JAZEERA") || titleUpper.contains("JAZEERA") ||
            groupUpper.contains("HADATH") || titleUpper.contains("HADATH") ||
            groupUpper.contains("MAGHREB") || groupUpper.contains("LIBYA") || groupUpper.contains("IRAQ")
        ) {
            return "ar"
        }

        // 2. Détection via catégorie ou nom de chaîne
        val channelLangHint = channel?.let {
            com.example.data.TranslationManager.inferLanguageFromChannel(it.groupName, it.name)
        }
        if (!channelLangHint.isNullOrBlank()) {
            val inferred = channelLangHint.lowercase()
            return when {
                inferred.startsWith("ar") -> "ar"
                inferred.startsWith("fr") -> "fr"
                inferred.startsWith("en") -> "en"
                else -> if (inferred.length >= 2) inferred.take(2) else "fr"
            }
        }

        // 3. Détection via piste audio du flux
        val audioLang = activeSubtitleLanguage
        if (!audioLang.isNullOrBlank()) {
            val audio = audioLang.lowercase()
            return when {
                audio.startsWith("ar") -> "ar"
                audio.startsWith("en") -> "en"
                audio.startsWith("fr") -> "fr"
                else -> if (audio.length >= 2) audio.take(2) else "fr"
            }
        }

        return "fr"
    }

    private val _subtitleOcrEnabled = MutableStateFlow(playerPrefs.getBoolean("subtitle_ocr_enabled", true))
    val subtitleOcrEnabled: StateFlow<Boolean> = _subtitleOcrEnabled.asStateFlow()

    // Sous-titres vocaux hors-ligne (Sherpa-ONNX)
    val allVoskModels = com.example.data.SherpaSubtitleManager.allModels
    val allSherpaModels = com.example.data.SherpaSubtitleManager.allModels

    val liveVoiceSourceLang = MutableStateFlow(playerPrefs.getString("live_voice_source_lang", "auto") ?: "auto")
    val liveVoiceTargetLang: StateFlow<String> = _subtitleTargetLanguage.asStateFlow()

    private val _voiceSubtitlesEnabled = MutableStateFlow(playerPrefs.getBoolean("voice_subtitles_enabled", false))
    val voiceSubtitlesEnabled: StateFlow<Boolean> = _voiceSubtitlesEnabled.asStateFlow()

    private val _voiceSubtitleLanguage = MutableStateFlow(playerPrefs.getString("voice_subtitle_lang", "auto") ?: "auto")
    val voiceSubtitleLanguage: StateFlow<String> = _voiceSubtitleLanguage.asStateFlow()

    private val _voiceSubtitleSyncOffsetMs = MutableStateFlow(playerPrefs.getInt("voice_subtitle_sync_offset_ms", 0))
    val voiceSubtitleSyncOffsetMs: StateFlow<Int> = _voiceSubtitleSyncOffsetMs.asStateFlow()

    private val _voiceSubtitleAutoCalibration = MutableStateFlow(playerPrefs.getBoolean("voice_subtitle_auto_calibration", true))
    val voiceSubtitleAutoCalibration: StateFlow<Boolean> = _voiceSubtitleAutoCalibration.asStateFlow()
    val autoCalibratedOffsetMs: StateFlow<Int> = com.example.data.SherpaSubtitleManager.autoCalibratedOffsetMs

    private val _voiceSubtitleClearDelaySeconds = MutableStateFlow(playerPrefs.getInt("voice_subtitle_clear_delay_s", 6))
    val voiceSubtitleClearDelaySeconds: StateFlow<Int> = _voiceSubtitleClearDelaySeconds.asStateFlow()

    private val _voiceSubtitleAutoDuration = MutableStateFlow(playerPrefs.getBoolean("voice_subtitle_auto_duration", true))
    val voiceSubtitleAutoDuration: StateFlow<Boolean> = _voiceSubtitleAutoDuration.asStateFlow()

    private val _voiceSubtitleStreamingMode = MutableStateFlow(playerPrefs.getBoolean("voice_subtitle_streaming_mode", true))
    val voiceSubtitleStreamingMode: StateFlow<Boolean> = _voiceSubtitleStreamingMode.asStateFlow()

    private val _turboStreamMode = MutableStateFlow(playerPrefs.getBoolean("turbo_stream_mode", true))
    val turboStreamMode: StateFlow<Boolean> = _turboStreamMode.asStateFlow()

    private val _gzipCompressionEnabled = MutableStateFlow(playerPrefs.getBoolean("gzip_compression_enabled", true))
    val gzipCompressionEnabled: StateFlow<Boolean> = _gzipCompressionEnabled.asStateFlow()

    private val _chunklessHlsEnabled = MutableStateFlow(playerPrefs.getBoolean("chunkless_hls_enabled", true))
    val chunklessHlsEnabled: StateFlow<Boolean> = _chunklessHlsEnabled.asStateFlow()

    private val _multiThreadedDownloads = MutableStateFlow(playerPrefs.getBoolean("multi_threaded_downloads", true))
    val multiThreadedDownloads: StateFlow<Boolean> = _multiThreadedDownloads.asStateFlow()

    val voiceSpeechDetected: StateFlow<Boolean> = com.example.data.SherpaSubtitleManager.isSpeechDetected
    val isVoiceModelDownloading: StateFlow<Boolean> = com.example.data.SherpaSubtitleManager.isDownloadingModel
    val voiceModelDownloadProgress: StateFlow<Float> = com.example.data.SherpaSubtitleManager.downloadProgress
    val voiceModelDownloadMessage: StateFlow<String?> = com.example.data.SherpaSubtitleManager.downloadStatusMessage

    private val _detectedSubtitleLanguage = MutableStateFlow<String?>(null)
    val detectedSubtitleLanguage: StateFlow<String?> = _detectedSubtitleLanguage.asStateFlow()

    fun updateDetectedSubtitleLanguage(languageName: String?) {
        val old = _detectedSubtitleLanguage.value
        if (old != languageName) {
            com.example.debug.GlobalDebugSystem.logStateChange("detectedSubtitleLanguage", old ?: "Non détecté", languageName ?: "Non détecté")
            _detectedSubtitleLanguage.value = languageName
        }
    }

    private var lastRawCueText: String? = null
    private var lastBitmapHash: Long? = null
    private var lastOcrJob: kotlinx.coroutines.Job? = null
    private var lastVoiceTranslationJob: kotlinx.coroutines.Job? = null
    private val bitmapOcrCache = ConcurrentHashMap<Long, String>()
    private val textRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }
    var activeSubtitleLanguage: String? = null
        set(value) {
            field = value
            if (!value.isNullOrBlank()) {
                updateDetectedSubtitleLanguage(com.example.data.TranslationManager.getLanguageDisplayName(value))
            }
        }

    private fun computeBitmapHash(bitmap: Bitmap): Long {
        if (bitmap.isRecycled) return 0L
        var result: Long = 17
        result = 31 * result + bitmap.width
        result = 31 * result + bitmap.height
        val stepX = (bitmap.width / 16).coerceAtLeast(1)
        val stepY = (bitmap.height / 16).coerceAtLeast(1)
        try {
            for (y in 0 until bitmap.height step stepY) {
                for (x in 0 until bitmap.width step stepX) {
                    result = 31 * result + bitmap.getPixel(x, y)
                }
            }
        } catch (e: Exception) {
            // Ignore pixel read errors on hardware/protected surfaces
        }
        return result
    }

    fun setSubtitlesEnabled(enabled: Boolean) {
        val oldValue = _subtitlesEnabled.value
        com.example.debug.GlobalDebugSystem.logFunctionCall("setSubtitlesEnabled", "old" to oldValue, "new" to enabled)
        com.example.debug.GlobalDebugSystem.logStateChange("subtitlesEnabled", oldValue, enabled)
        _subtitlesEnabled.value = enabled
        playerPrefs.edit().putBoolean("subtitles_enabled", enabled).apply()
        if (!enabled) {
            _nativeSubtitleText.value = null
            _translatedNativeSubtitleText.value = null
            lastRawCueText = null
            lastBitmapHash = null
            lastOcrJob?.cancel()
        }
        syncSubtitleDisplay()
        sharedExoPlayer?.let { player ->
            val enableText = enabled || _subtitleTranslationEnabled.value
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, !enableText)
                .apply {
                    if (!enableText) {
                        clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                    }
                }
                .build()
        }
    }

    fun setSubtitleOcrEnabled(enabled: Boolean) {
        val oldValue = _subtitleOcrEnabled.value
        com.example.debug.GlobalDebugSystem.logFunctionCall("setSubtitleOcrEnabled", "old" to oldValue, "new" to enabled)
        com.example.debug.GlobalDebugSystem.logStateChange("subtitleOcrEnabled", oldValue, enabled)
        _subtitleOcrEnabled.value = enabled
        playerPrefs.edit().putBoolean("subtitle_ocr_enabled", enabled).apply()
        if (!enabled && !_subtitleTranslationEnabled.value) {
            if (lastBitmapHash != null) {
                _nativeSubtitleText.value = null
                _translatedNativeSubtitleText.value = null
                syncSubtitleDisplay()
            }
        }
    }

    fun setVoiceSubtitlesEnabled(enabled: Boolean) {
        val oldValue = _voiceSubtitlesEnabled.value
        com.example.debug.GlobalDebugSystem.logFunctionCall("setVoiceSubtitlesEnabled", "old" to oldValue, "new" to enabled)
        com.example.debug.GlobalDebugSystem.logStateChange("voiceSubtitlesEnabled", oldValue, enabled)
        _voiceSubtitlesEnabled.value = enabled
        playerPrefs.edit().putBoolean("voice_subtitles_enabled", enabled).apply()

        if (enabled) {
            val context = getApplication<android.app.Application>()
            val currentPrefLang = _voiceSubtitleLanguage.value
            val currentSource = if (currentPrefLang == "auto" || currentPrefLang.isBlank()) {
                resolveChannelLanguageCode()
            } else {
                currentPrefLang
            }
            liveVoiceSourceLang.value = currentSource
            com.example.data.SherpaSubtitleManager.setSelectedVoiceModelId(currentSource)
            com.example.data.SherpaSubtitleManager.startVoiceRecognition(context)
            com.example.data.SherpaSubtitleManager.setSourceLanguage(currentSource, context)
        } else {
            com.example.data.SherpaSubtitleManager.stopVoiceRecognition()
            lastVoiceTranslationJob?.cancel()
            _voiceSubtitleText.value = null
            _translatedVoiceSubtitleText.value = null
            syncSubtitleDisplay()
        }
    }

    fun setLiveVoiceSourceLanguage(code: String) {
        val cleanCode = code.trim().lowercase()
        _voiceSubtitleLanguage.value = cleanCode
        playerPrefs.edit().putString("voice_subtitle_lang", cleanCode).apply()

        val resolvedCode = if (cleanCode == "auto" || cleanCode.isBlank()) {
            resolveChannelLanguageCode()
        } else {
            cleanCode
        }
        liveVoiceSourceLang.value = resolvedCode
        playerPrefs.edit().putString("live_voice_source_lang", resolvedCode).apply()

        // Réinitialiser les états de sous-titrage immédiatement pour éviter le mélange de langues
        _voiceSubtitleText.value = null
        _translatedVoiceSubtitleText.value = null
        _currentSubtitleText.value = null
        _translatedSubtitleText.value = null
        syncSubtitleDisplay()

        val context = getApplication<android.app.Application>()
        com.example.data.SherpaSubtitleManager.setSourceLanguage(resolvedCode, context)
    }

    private val voiceTranslationCache = ConcurrentHashMap<String, String>()
    private var lastTranslatedSourceText: String? = null
    private var lastTranslationRequestTime = 0L

    fun processVoiceTranslation(textToProcess: String, isFinal: Boolean = false) {
        if (!_voiceSubtitlesEnabled.value) return
        val clean = textToProcess.trim()
        if (clean.isBlank()) {
            _voiceSubtitleText.value = null
            _translatedVoiceSubtitleText.value = null
            syncSubtitleDisplay()
            return
        }

        _voiceSubtitleText.value = clean

        if (_subtitleTranslationEnabled.value) {
            val targetLang = liveVoiceTargetLang.value
            val sourceLang = liveVoiceSourceLang.value

            if (sourceLang.equals(targetLang, ignoreCase = true) || targetLang == "none") {
                _translatedVoiceSubtitleText.value = clean
                syncSubtitleDisplay()
                return
            }

            val cacheKey = "${sourceLang}_${targetLang}_$clean"
            val cached = voiceTranslationCache[cacheKey]
            if (cached != null) {
                _translatedVoiceSubtitleText.value = cached
                syncSubtitleDisplay()
                return
            }

            // CORRECTIF : l'ancien code annulait la traduction en cours à chaque nouveau partiel (toutes les ~180 ms).
            // Comme une traduction réseau prend 200-600 ms, elle était presque toujours annulée avant la fin :
            // le texte arabe (ou toute langue traduite) n'apparaissait jamais. Désormais la traduction en cours
            // N'EST PLUS annulée : on garde seulement le dernier texte en attente et on le traduit ensuite.
            pendingVoiceTranslation = Triple(clean, sourceLang, targetLang)
            if (!isFinal) {
                val now = System.currentTimeMillis()
                // Traduction ML Kit des partiels : au plus 1 fois / 1,2 s (avant 350 ms) -> beaucoup moins de CPU sur TV.
                // Les résultats FINAUX sont toujours traduits immédiatement.
                if (now - lastTranslationRequestTime < 1200L) {
                    syncSubtitleDisplay()
                    return
                }
            }
            runVoiceTranslationLoop()
        } else {
            _translatedVoiceSubtitleText.value = null
        }
        syncSubtitleDisplay()
    }

    @Volatile private var pendingVoiceTranslation: Triple<String, String, String>? = null
    @Volatile private var voiceTranslationRunning = false

    private fun runVoiceTranslationLoop() {
        if (voiceTranslationRunning) return
        voiceTranslationRunning = true
        lastVoiceTranslationJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                while (true) {
                    val (text, src, tgt) = pendingVoiceTranslation ?: break
                    pendingVoiceTranslation = null
                    lastTranslationRequestTime = System.currentTimeMillis()
                    val cacheKey = "${src}_${tgt}_$text"
                    // val non-nul explicite (évite l'erreur « String? but String was expected »)
                    val translated: String = voiceTranslationCache[cacheKey] ?: run {
                        val fresh: String = try {
                            com.example.data.TranslationManager.translateSync(text = text, source = src, target = tgt)
                        } catch (e: kotlinx.coroutines.CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            Log.w("IptvViewModel", "Erreur traduction vocale: ${e.message}")
                            ""
                        }
                        if (fresh.isNotBlank()) voiceTranslationCache[cacheKey] = fresh
                        fresh
                    }
                    if (translated.isNotBlank() && _voiceSubtitlesEnabled.value && _subtitleTranslationEnabled.value) {
                        // N'afficher que si ce texte n'est pas déjà périmé par un texte plus récent
                        // (sauf s'il n'y a rien d'autre en attente).
                        _translatedVoiceSubtitleText.value = translated
                        syncSubtitleDisplay()
                        com.example.data.SherpaSubtitleManager.refreshAutoClearTimer(translated)
                    }
                }
            } finally {
                voiceTranslationRunning = false
            }
        }
    }

    fun setLiveVoiceTargetLanguage(code: String) {
        val cleanCode = code.trim().lowercase()
        _subtitleTargetLanguage.value = cleanCode
        playerPrefs.edit().putString("subtitle_target_lang", cleanCode).apply()

        if (cleanCode == "none") {
            _subtitleTranslationEnabled.value = false
            playerPrefs.edit().putBoolean("subtitle_translation_enabled", false).apply()
            _translatedVoiceSubtitleText.value = null
            _translatedSubtitleText.value = null
            syncSubtitleDisplay()
            return
        }

        _subtitleTranslationEnabled.value = true
        playerPrefs.edit().putBoolean("subtitle_translation_enabled", true).apply()

        viewModelScope.launch(Dispatchers.IO) {
            com.example.data.TranslationManager.downloadModelIfNeeded(cleanCode)
        }

        val currentText = _voiceSubtitleText.value
        if (!currentText.isNullOrBlank()) {
            processVoiceTranslation(currentText)
        }
    }

    fun setVoiceSubtitleLanguage(langCode: String) {
        setLiveVoiceSourceLanguage(langCode)
    }

    fun setVoiceSubtitleSyncOffsetMs(offsetMs: Int) {
        val clamped = offsetMs.coerceIn(-2000, 5000)
        _voiceSubtitleSyncOffsetMs.value = clamped
        playerPrefs.edit().putInt("voice_subtitle_sync_offset_ms", clamped).apply()
        com.example.data.SherpaSubtitleManager.setSyncOffsetMs(clamped)
    }

    fun setVoiceSubtitleAutoCalibration(enabled: Boolean) {
        _voiceSubtitleAutoCalibration.value = enabled
        playerPrefs.edit().putBoolean("voice_subtitle_auto_calibration", enabled).apply()
        com.example.data.SherpaSubtitleManager.setAutoCalibrationEnabled(enabled)
    }

    fun setVoiceSubtitleClearDelaySeconds(seconds: Int) {
        val clamped = seconds.coerceIn(2, 10)
        _voiceSubtitleClearDelaySeconds.value = clamped
        playerPrefs.edit().putInt("voice_subtitle_clear_delay_s", clamped).apply()
        com.example.data.SherpaSubtitleManager.setAutoClearDelaySeconds(clamped)
    }

    fun setVoiceSubtitleAutoDuration(enabled: Boolean) {
        _voiceSubtitleAutoDuration.value = enabled
        playerPrefs.edit().putBoolean("voice_subtitle_auto_duration", enabled).apply()
        com.example.data.SherpaSubtitleManager.setIntelligentDurationEnabled(enabled)
    }

    fun setVoiceSubtitleStreamingMode(enabled: Boolean) {
        _voiceSubtitleStreamingMode.value = enabled
        playerPrefs.edit().putBoolean("voice_subtitle_streaming_mode", enabled).apply()
        com.example.data.SherpaSubtitleManager.setStreamingMode(enabled)
    }

    fun setTurboStreamMode(enabled: Boolean) {
        _turboStreamMode.value = enabled
        playerPrefs.edit().putBoolean("turbo_stream_mode", enabled).apply()
    }

    fun setGzipCompressionEnabled(enabled: Boolean) {
        _gzipCompressionEnabled.value = enabled
        playerPrefs.edit().putBoolean("gzip_compression_enabled", enabled).apply()
    }

    fun setChunklessHlsEnabled(enabled: Boolean) {
        _chunklessHlsEnabled.value = enabled
        playerPrefs.edit().putBoolean("chunkless_hls_enabled", enabled).apply()
    }

    fun setMultiThreadedDownloads(enabled: Boolean) {
        _multiThreadedDownloads.value = enabled
        playerPrefs.edit().putBoolean("multi_threaded_downloads", enabled).apply()
    }

    fun setSubtitleStyleMode(mode: String) {
        val oldValue = _subtitleStyleMode.value
        com.example.debug.GlobalDebugSystem.logFunctionCall("setSubtitleStyleMode", "old" to oldValue, "new" to mode)
        com.example.debug.GlobalDebugSystem.logStateChange("subtitleStyleMode", oldValue, mode)
        _subtitleStyleMode.value = mode
        playerPrefs.edit().putString("subtitle_style_mode", mode).apply()
        triggerSubtitlePreviewTest()
    }

    fun setSubtitleSizeState(size: String) {
        val oldValue = _subtitleSizeState.value
        com.example.debug.GlobalDebugSystem.logFunctionCall("setSubtitleSizeState", "old" to oldValue, "new" to size)
        com.example.debug.GlobalDebugSystem.logStateChange("subtitleSizeState", oldValue, size)
        _subtitleSizeState.value = size
        playerPrefs.edit().putString("subtitle_size_state", size).apply()
        triggerSubtitlePreviewTest()
    }

    private var previewTestJob: kotlinx.coroutines.Job? = null

    /**
     * Déclenche un sous-titre de test réel sur le lecteur pour afficher immédiatement à l'utilisateur
     * l'effet visuel des réglages sélectionnés (taille, couleur, contraste, traduction).
     */
    fun triggerSubtitlePreviewTest(customText: String? = null) {
        previewTestJob?.cancel()
        val styleLabel = _subtitleStyleMode.value
        val sizeLabel = _subtitleSizeState.value
        val testText = customText ?: "Sous-titres en direct TV"

        // S'assurer que l'affichage des sous-titres est actif pour rendre le test visible
        if (!_subtitlesEnabled.value && !_subtitleTranslationEnabled.value) {
            _subtitlesEnabled.value = true
        }

        _currentSubtitleText.value = testText
        if (_subtitleTranslationEnabled.value) {
            // RÈGLE : Afficher uniquement le texte sans aucune indication ni préfixe
            _translatedSubtitleText.value = testText
        } else {
            _translatedSubtitleText.value = null
        }

        previewTestJob = viewModelScope.launch {
            kotlinx.coroutines.delay(5000)
            if (_currentSubtitleText.value == testText) {
                _currentSubtitleText.value = null
                _translatedSubtitleText.value = null
            }
        }
    }

    /**
     * Teste la simulation vocale en direct pour vérifier tout le pipeline (STT -> ML Kit -> Style).
     */
    fun triggerVoiceSubtitleSimulationTest() {
        val phrase = "Bienvenue sur le direct TV ! Ceci est une démonstration du sous-titrage vocal IA."
        previewTestJob?.cancel()

        // Activer les sous-titres vocaux pour que la notification et l'affichage soient garantis
        if (!_voiceSubtitlesEnabled.value) {
            _voiceSubtitlesEnabled.value = true
        }

        _currentSubtitleText.value = phrase
        if (_subtitleTranslationEnabled.value) {
            val targetLang = _subtitleTargetLanguage.value
            // RÈGLE : Si traduction activée, afficher UNIQUEMENT le texte pur sans aucune indication
            _translatedSubtitleText.value = phrase
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    com.example.data.TranslationManager.downloadModelIfNeeded(targetLang)
                    val translated = com.example.data.TranslationManager.translateText(
                        text = phrase,
                        sourceLanguage = _voiceSubtitleLanguage.value,
                        targetLanguage = targetLang
                    )
                    if (translated.isNotBlank() && _subtitleTranslationEnabled.value) {
                        _translatedSubtitleText.value = translated
                    }
                } catch (e: Exception) {
                    Log.w("IptvViewModel", "Erreur simulation vocale translation: ${e.message}")
                }
            }
        } else {
            _translatedSubtitleText.value = null
        }

        com.example.data.SherpaSubtitleManager.injectSimulationSpeech(phrase)

        previewTestJob = viewModelScope.launch {
            kotlinx.coroutines.delay(5000)
            if (_currentSubtitleText.value == phrase) {
                _currentSubtitleText.value = null
                _translatedSubtitleText.value = null
            }
        }
    }

    fun setSubtitleTranslationEnabled(enabled: Boolean) {
        val oldValue = _subtitleTranslationEnabled.value
        com.example.debug.GlobalDebugSystem.logFunctionCall("setSubtitleTranslationEnabled", "old" to oldValue, "new" to enabled)
        com.example.debug.GlobalDebugSystem.logStateChange("subtitleTranslationEnabled", oldValue, enabled)
        _subtitleTranslationEnabled.value = enabled
        playerPrefs.edit().putBoolean("subtitle_translation_enabled", enabled).apply()
        if (enabled && !_subtitlesEnabled.value && !_voiceSubtitlesEnabled.value) {
            setSubtitlesEnabled(true)
        }
        if (!enabled) {
            _translatedNativeSubtitleText.value = null
            _translatedVoiceSubtitleText.value = null
            syncSubtitleDisplay()
        } else {
            // Si la sous-titration vocale est active, traduire immédiatement la phrase vocale en cours
            val voiceText = _voiceSubtitleText.value
            if (_voiceSubtitlesEnabled.value && !voiceText.isNullOrBlank()) {
                val targetLang = _subtitleTargetLanguage.value
                val sourceLang = if (_voiceSubtitleLanguage.value == "auto" || _voiceSubtitleLanguage.value.isBlank()) {
                    resolveChannelLanguageCode()
                } else {
                    _voiceSubtitleLanguage.value
                }
                viewModelScope.launch(Dispatchers.IO) {
                    try {
                        com.example.data.TranslationManager.downloadModelIfNeeded(targetLang)
                        val translated = com.example.data.TranslationManager.translateText(
                            text = voiceText,
                            sourceLanguage = sourceLang,
                            targetLanguage = targetLang
                        )
                        if (translated.isNotBlank() && _subtitleTranslationEnabled.value) {
                            _translatedVoiceSubtitleText.value = translated
                            syncSubtitleDisplay()
                        }
                    } catch (e: Exception) {
                        Log.w("IptvViewModel", "Erreur traduction vocale: ${e.message}")
                    }
                }
            }

            // Traduire le texte natif si présent
            sharedExoPlayer?.let { player ->
                if (_subtitlesEnabled.value) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                        .build()
                }
            }
            val currentRawText = lastRawCueText
            if (!currentRawText.isNullOrBlank() && _subtitlesEnabled.value) {
                val currentChannel = _selectedChannel.value
                val groupName = currentChannel?.groupName
                val channelName = currentChannel?.name

                viewModelScope.launch {
                    val targetLang = _subtitleTargetLanguage.value
                    com.example.data.TranslationManager.downloadModelIfNeeded(targetLang)
                    val detected = com.example.data.TranslationManager.identifyLanguage(currentRawText)
                        ?: com.example.data.TranslationManager.detectLanguageFromScript(currentRawText)
                        ?: activeSubtitleLanguage
                        ?: com.example.data.TranslationManager.inferLanguageFromChannel(groupName, channelName)

                    if (detected != null) {
                        updateDetectedSubtitleLanguage(com.example.data.TranslationManager.getLanguageDisplayName(detected))
                    }
                    val translated = com.example.data.TranslationManager.translateText(
                        text = currentRawText,
                        sourceLanguage = detected ?: activeSubtitleLanguage ?: "auto",
                        targetLanguage = targetLang,
                        channelGroup = groupName,
                        channelName = channelName
                    )
                    if (_subtitleTranslationEnabled.value && lastRawCueText == currentRawText) {
                        _translatedNativeSubtitleText.value = translated
                        syncSubtitleDisplay()
                    }
                }
            }
        }
    }

    fun setSubtitleTargetLanguage(languageCode: String) {
        val oldValue = _subtitleTargetLanguage.value
        com.example.debug.GlobalDebugSystem.logFunctionCall("setSubtitleTargetLanguage", "old" to oldValue, "new" to languageCode)
        com.example.debug.GlobalDebugSystem.logStateChange("subtitleTargetLanguage", oldValue, languageCode)
        _subtitleTargetLanguage.value = languageCode
        playerPrefs.edit().putString("subtitle_target_lang", languageCode).apply()
        viewModelScope.launch {
            com.example.data.TranslationManager.downloadModelIfNeeded(languageCode)
            // Retraduire le texte vocal si présent
            val voiceText = _voiceSubtitleText.value
            if (_voiceSubtitlesEnabled.value && !voiceText.isNullOrBlank() && _subtitleTranslationEnabled.value) {
                val sourceLang = if (_voiceSubtitleLanguage.value == "auto" || _voiceSubtitleLanguage.value.isBlank()) {
                    resolveChannelLanguageCode()
                } else {
                    _voiceSubtitleLanguage.value
                }
                val translated = com.example.data.TranslationManager.translateText(
                    text = voiceText,
                    sourceLanguage = sourceLang,
                    targetLanguage = languageCode
                )
                if (translated.isNotBlank() && _subtitleTranslationEnabled.value) {
                    _translatedVoiceSubtitleText.value = translated
                    syncSubtitleDisplay()
                }
            }
            // Retraduire le texte natif si présent
            val currentRawText = lastRawCueText
            if (_subtitleTranslationEnabled.value && !currentRawText.isNullOrBlank() && _subtitlesEnabled.value) {
                val currentChannel = _selectedChannel.value
                val groupName = currentChannel?.groupName
                val channelName = currentChannel?.name

                val detected = com.example.data.TranslationManager.identifyLanguage(currentRawText)
                    ?: com.example.data.TranslationManager.detectLanguageFromScript(currentRawText)
                    ?: activeSubtitleLanguage
                    ?: com.example.data.TranslationManager.inferLanguageFromChannel(groupName, channelName)

                if (detected != null) {
                    updateDetectedSubtitleLanguage(com.example.data.TranslationManager.getLanguageDisplayName(detected))
                }
                val translated = com.example.data.TranslationManager.translateText(
                    text = currentRawText,
                    sourceLanguage = detected ?: activeSubtitleLanguage ?: "auto",
                    targetLanguage = languageCode,
                    channelGroup = groupName,
                    channelName = channelName
                )
                if (_subtitleTranslationEnabled.value && lastRawCueText == currentRawText) {
                    _translatedNativeSubtitleText.value = translated
                    syncSubtitleDisplay()
                }
            }
        }
    }

    fun setResizeModeState(mode: Int) {
        _resizeModeState.value = mode
        playerPrefs.edit().putInt("player_resize_mode", mode).apply()
    }

    fun setPlaybackSpeedState(speed: Float) {
        _playbackSpeedState.value = speed
        playerPrefs.edit().putFloat("player_playback_speed", speed).apply()
        sharedExoPlayer?.setPlaybackSpeed(speed)
    }

    fun setImageEnhancementMode(mode: String) {
        _imageEnhancementMode.value = mode
        playerPrefs.edit().putString("player_image_enhancement", mode).apply()
    }

    fun setActiveVideoQuality(quality: String) {
        _activeVideoQuality.value = quality
        playerPrefs.edit().putString("player_video_quality", quality).apply()
    }

    fun setActiveAudioFormat(format: String) {
        _activeAudioFormat.value = format
        playerPrefs.edit().putString("player_audio_format", format).apply()
    }

    fun setPreferredAudioLanguage(lang: String) {
        _preferredAudioLanguage.value = lang
        playerPrefs.edit().putString("player_preferred_audio_lang", lang).apply()
        applyTrackSelectionPreferences()
    }

    fun setPreferredSubtitleLanguage(lang: String) {
        _preferredSubtitleLanguage.value = lang
        playerPrefs.edit().putString("player_preferred_subtitle_lang", lang).apply()
        applyTrackSelectionPreferences()
    }

    fun applyTrackSelectionPreferences() {
        sharedExoPlayer?.let { player ->
            var builder = player.trackSelectionParameters.buildUpon()
            val prefAudio = _preferredAudioLanguage.value
            if (prefAudio != "auto" && prefAudio.isNotBlank()) {
                builder = builder.setPreferredAudioLanguage(prefAudio)
            }
            val prefSub = _preferredSubtitleLanguage.value
            if (prefSub != "auto" && prefSub.isNotBlank()) {
                builder = builder.setPreferredTextLanguage(prefSub)
            }
            val enableText = _subtitlesEnabled.value || _subtitleTranslationEnabled.value
            builder = builder.setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, !enableText)
            player.trackSelectionParameters = builder.build()
        }
    }

    fun downloadVoiceModel(modelId: String) {
        val modelInfo = com.example.data.SherpaSubtitleManager.AVAILABLE_MODELS.find { it.id == modelId } ?: return
        val context = getApplication<Application>()
        if (com.example.data.SherpaSubtitleManager.isDownloadingModel.value) {
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val ok = com.example.data.SherpaSubtitleManager.downloadAndExtractModel(context, modelInfo)
            if (ok && _voiceSubtitlesEnabled.value && _voiceSubtitleLanguage.value == modelId) {
                com.example.data.SherpaSubtitleManager.setSourceLanguage(modelId, context)
            }
        }
    }

    fun deleteVoiceModel(modelId: String) {
        val modelInfo = com.example.data.SherpaSubtitleManager.AVAILABLE_MODELS.find { it.id == modelId } ?: return
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            com.example.data.SherpaSubtitleManager.deleteModel(context, modelInfo)
        }
    }

    fun applyGlobalMediaConfiguration() {
        val context = getApplication<Application>()
        com.example.debug.GlobalDebugSystem.logFunctionCall("applyGlobalMediaConfiguration",
            "subtitlesEnabled" to _subtitlesEnabled.value,
            "subtitleStyleMode" to _subtitleStyleMode.value,
            "subtitleSizeState" to _subtitleSizeState.value,
            "subtitleTranslationEnabled" to _subtitleTranslationEnabled.value,
            "subtitleTargetLanguage" to _subtitleTargetLanguage.value,
            "subtitleOcrEnabled" to _subtitleOcrEnabled.value,
            "voiceSubtitlesEnabled" to _voiceSubtitlesEnabled.value,
            "voiceSubtitleLanguage" to _voiceSubtitleLanguage.value,
            "preferredAudioLanguage" to _preferredAudioLanguage.value,
            "preferredSubtitleLanguage" to _preferredSubtitleLanguage.value,
            "activeAudioFormat" to _activeAudioFormat.value
        )

        playerPrefs.edit()
            .putBoolean("subtitles_enabled", _subtitlesEnabled.value)
            .putString("subtitle_style_mode", _subtitleStyleMode.value)
            .putString("subtitle_size_state", _subtitleSizeState.value)
            .putBoolean("subtitle_translation_enabled", _subtitleTranslationEnabled.value)
            .putString("subtitle_target_lang", _subtitleTargetLanguage.value)
            .putBoolean("subtitle_ocr_enabled", _subtitleOcrEnabled.value)
            .putBoolean("voice_subtitles_enabled", _voiceSubtitlesEnabled.value)
            .putString("voice_subtitle_lang", _voiceSubtitleLanguage.value)
            .putString("player_preferred_audio_lang", _preferredAudioLanguage.value)
            .putString("player_preferred_subtitle_lang", _preferredSubtitleLanguage.value)
            .putString("player_audio_format", _activeAudioFormat.value)
            .apply()

        applyTrackSelectionPreferences()

        com.example.data.SherpaSubtitleManager.setSyncOffsetMs(_voiceSubtitleSyncOffsetMs.value)
        com.example.data.SherpaSubtitleManager.setAutoCalibrationEnabled(_voiceSubtitleAutoCalibration.value)
        com.example.data.SherpaSubtitleManager.setAutoClearDelaySeconds(_voiceSubtitleClearDelaySeconds.value)
        com.example.data.SherpaSubtitleManager.setIntelligentDurationEnabled(_voiceSubtitleAutoDuration.value)
        com.example.data.SherpaSubtitleManager.setStreamingMode(_voiceSubtitleStreamingMode.value)

        if (_voiceSubtitlesEnabled.value) {
            val effectiveLang = if (_voiceSubtitleLanguage.value == "auto" || _voiceSubtitleLanguage.value.isBlank()) {
                resolveChannelLanguageCode()
            } else {
                _voiceSubtitleLanguage.value
            }
            com.example.data.SherpaSubtitleManager.setSelectedVoiceModelId(effectiveLang)
            com.example.data.SherpaSubtitleManager.startVoiceRecognition(context)
            val langLabel = if (_voiceSubtitleLanguage.value == "auto") "Auto (${com.example.data.TranslationManager.getLanguageDisplayName(effectiveLang)})" else com.example.data.TranslationManager.getLanguageDisplayName(effectiveLang)
            updateDetectedSubtitleLanguage(langLabel)
        } else {
            com.example.data.SherpaSubtitleManager.stopVoiceRecognition()
        }

        if (_subtitleTranslationEnabled.value) {
            viewModelScope.launch(Dispatchers.IO) {
                com.example.data.TranslationManager.downloadModelIfNeeded(_subtitleTargetLanguage.value)
            }
        }
    }

    fun setBrightnessLevel(level: Float) {
        _brightnessLevel.value = level
        playerPrefs.edit().putFloat("player_brightness", level).apply()
    }

    fun setZoomLevel(level: Float) {
        _zoomLevel.value = level
        playerPrefs.edit().putFloat("player_zoom", level).apply()
    }

    private fun attachSubtitleTranslationListener(player: ExoPlayer) {
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val subGroups = tracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_TEXT }
                if (subGroups.isNotEmpty()) {
                    var selectedTrackFound = false
                    for (group in subGroups) {
                        for (i in 0 until group.length) {
                            if (group.isTrackSelected(i)) {
                                selectedTrackFound = true
                                val formatLang = group.mediaTrackGroup.getFormat(i).language
                                if (!formatLang.isNullOrBlank() && !formatLang.equals("und", ignoreCase = true)) {
                                    activeSubtitleLanguage = formatLang
                                    _detectedSubtitleLanguage.value = com.example.data.TranslationManager.getLanguageDisplayName(formatLang)
                                }
                                break
                            }
                        }
                        if (selectedTrackFound) break
                    }

                    if (!selectedTrackFound && (_subtitlesEnabled.value || _subtitleTranslationEnabled.value)) {
                        for (group in subGroups) {
                            for (i in 0 until group.length) {
                                if (group.isTrackSupported(i)) {
                                    val formatLang = group.mediaTrackGroup.getFormat(i).language
                                    if (!formatLang.isNullOrBlank() && !formatLang.equals("und", ignoreCase = true)) {
                                        activeSubtitleLanguage = formatLang
                                        updateDetectedSubtitleLanguage(com.example.data.TranslationManager.getLanguageDisplayName(formatLang))
                                    }
                                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                        .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                                        .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                                        .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, i))
                                        .build()
                                    break
                                }
                            }
                            if (player.trackSelectionParameters.overrides.containsKey(group.mediaTrackGroup)) break
                        }
                    }
                }

                // Inspection des pistes audio pour auto-sélection et détection de la langue source
                val audioGroups = tracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_AUDIO }
                if (audioGroups.isNotEmpty()) {
                    var selectedAudioTrackFound = false
                    for (group in audioGroups) {
                        for (i in 0 until group.length) {
                            if (group.isTrackSelected(i)) {
                                selectedAudioTrackFound = true
                                val format = group.mediaTrackGroup.getFormat(i)
                                val audioLang = format.language
                                if (!audioLang.isNullOrBlank() && !audioLang.equals("und", ignoreCase = true)) {
                                    if (activeSubtitleLanguage == null || activeSubtitleLanguage == "und") {
                                        activeSubtitleLanguage = audioLang
                                        updateDetectedSubtitleLanguage(com.example.data.TranslationManager.getLanguageDisplayName(audioLang))
                                    }
                                }
                                break
                            }
                        }
                        if (selectedAudioTrackFound) break
                    }

                    val prefAudio = _preferredAudioLanguage.value
                    if (prefAudio != "auto" && prefAudio.isNotBlank()) {
                        val matchingTrack = audioGroups.flatMap { g ->
                            (0 until g.length).map { idx -> g to idx }
                        }.firstOrNull { (g, idx) ->
                            val lang = g.mediaTrackGroup.getFormat(idx).language
                            lang != null && (lang.equals(prefAudio, ignoreCase = true) || lang.startsWith(prefAudio.take(2), ignoreCase = true))
                        }
                        if (matchingTrack != null && !matchingTrack.first.isTrackSelected(matchingTrack.second)) {
                            val (matchGroup, matchIdx) = matchingTrack
                            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                                .setOverrideForType(androidx.media3.common.TrackSelectionOverride(matchGroup.mediaTrackGroup, matchIdx))
                                .build()
                            val format = matchGroup.mediaTrackGroup.getFormat(matchIdx)
                            format.language?.let { lang ->
                                if (activeSubtitleLanguage == null || activeSubtitleLanguage == "und") {
                                    activeSubtitleLanguage = lang
                                    updateDetectedSubtitleLanguage(com.example.data.TranslationManager.getLanguageDisplayName(lang))
                                }
                            }
                        }
                    }
                }
            }

            override fun onCues(cueGroup: androidx.media3.common.text.CueGroup) {
                val cues = cueGroup.cues
                if (cues.isEmpty()) {
                    lastRawCueText = null
                    lastBitmapHash = null
                    lastOcrJob?.cancel()
                    _nativeSubtitleText.value = null
                    _translatedNativeSubtitleText.value = null
                    syncSubtitleDisplay()
                    return
                }

                val currentChannel = _selectedChannel.value
                val groupName = currentChannel?.groupName
                val channelName = currentChannel?.name

                // 1. Text cues handling (CEA-608, WebVTT, SRT, ASS, DVB Text, etc.)
                val textCues = cues.mapNotNull { it.text?.toString() }.filter { it.isNotBlank() }
                if (textCues.isNotEmpty()) {
                    val rawText = textCues.joinToString("\n").trim()
                    val cleanedText = com.example.data.TranslationManager.cleanSubtitleText(rawText)
                    if (cleanedText.isBlank()) {
                        return
                    }

                    lastRawCueText = cleanedText
                    lastBitmapHash = null
                    lastOcrJob?.cancel()
                    _nativeSubtitleText.value = cleanedText
                    if (_subtitleTranslationEnabled.value) {
                        _translatedNativeSubtitleText.value = null
                    }
                    syncSubtitleDisplay()

                    viewModelScope.launch {
                        val detected = com.example.data.TranslationManager.identifyLanguage(cleanedText)
                            ?: com.example.data.TranslationManager.detectLanguageFromScript(cleanedText)
                            ?: activeSubtitleLanguage
                            ?: com.example.data.TranslationManager.inferLanguageFromChannel(groupName, channelName)

                        if (detected != null) {
                            updateDetectedSubtitleLanguage(com.example.data.TranslationManager.getLanguageDisplayName(detected))
                        }

                        if (_subtitleTranslationEnabled.value) {
                            val targetLang = _subtitleTargetLanguage.value
                            val translated = com.example.data.TranslationManager.translateText(
                                text = cleanedText,
                                sourceLanguage = detected ?: activeSubtitleLanguage ?: "auto",
                                targetLanguage = targetLang,
                                channelGroup = groupName,
                                channelName = channelName
                            )
                            if (_subtitleTranslationEnabled.value && lastRawCueText == cleanedText) {
                                _translatedNativeSubtitleText.value = if (translated.isNotBlank()) translated else null
                                syncSubtitleDisplay()
                            }
                        } else {
                            _translatedNativeSubtitleText.value = null
                            syncSubtitleDisplay()
                        }
                    }
                    return
                }

                // 2. Bitmap cues handling (DVB bitmap subtitles, VOBSUB, PGS, Teletext bitmap, etc.)
                val bitmapCue = cues.firstOrNull { it.bitmap != null }
                if (bitmapCue?.bitmap != null) {
                    val rawBitmap = bitmapCue.bitmap!!
                    Log.d("SubtitleDebug", "Bitmap cue détecté: size=${rawBitmap.width}x${rawBitmap.height}")

                    if (!_subtitleOcrEnabled.value && !_subtitleTranslationEnabled.value) {
                        _nativeSubtitleText.value = null
                        _translatedNativeSubtitleText.value = null
                        syncSubtitleDisplay()
                        return
                    }

                    val bitmap = if (rawBitmap.config == Bitmap.Config.HARDWARE) {
                        rawBitmap.copy(Bitmap.Config.ARGB_8888, false) ?: rawBitmap
                    } else {
                        rawBitmap
                    }

                    val bitmapHash = computeBitmapHash(bitmap)
                    if (bitmapHash == lastBitmapHash && (_translatedNativeSubtitleText.value != null || _nativeSubtitleText.value != null)) {
                        // Same image/frame already processed
                        return
                    }
                    lastBitmapHash = bitmapHash

                    lastOcrJob?.cancel()
                    lastOcrJob = viewModelScope.launch {
                        try {
                            val cachedOcr = bitmapOcrCache[bitmapHash]
                            val rawOcrText = if (cachedOcr != null) {
                                cachedOcr
                            } else {
                                val inputImage = InputImage.fromBitmap(bitmap, 0)
                                val visionResult = textRecognizer.process(inputImage).await()
                                val extracted = visionResult.text.trim()
                                if (extracted.isNotBlank()) {
                                    bitmapOcrCache[bitmapHash] = extracted
                                }
                                extracted
                            }

                            val ocrText = com.example.data.TranslationManager.cleanSubtitleText(rawOcrText)
                            if (ocrText.isBlank()) {
                                Log.d("SubtitleDebug", "OCR: aucun texte fiable détecté")
                                if (lastBitmapHash == bitmapHash) {
                                    _nativeSubtitleText.value = null
                                    _translatedNativeSubtitleText.value = null
                                    syncSubtitleDisplay()
                                }
                                return@launch
                            }

                            Log.d("SubtitleDebug", "OCR texte extrait: \"$ocrText\"")
                            lastRawCueText = ocrText
                            if (lastBitmapHash == bitmapHash) {
                                _nativeSubtitleText.value = ocrText
                                if (_subtitleTranslationEnabled.value) {
                                    _translatedNativeSubtitleText.value = null
                                }
                                syncSubtitleDisplay()
                            }
                            val detected = com.example.data.TranslationManager.identifyLanguage(ocrText)
                                ?: com.example.data.TranslationManager.detectLanguageFromScript(ocrText)
                                ?: activeSubtitleLanguage
                                ?: com.example.data.TranslationManager.inferLanguageFromChannel(groupName, channelName)

                            if (detected != null) {
                                updateDetectedSubtitleLanguage(com.example.data.TranslationManager.getLanguageDisplayName(detected))
                            }

                            if (_subtitleTranslationEnabled.value) {
                                val targetLang = _subtitleTargetLanguage.value
                                val translated = com.example.data.TranslationManager.translateText(
                                    text = ocrText,
                                    sourceLanguage = detected ?: activeSubtitleLanguage ?: "auto",
                                    targetLanguage = targetLang,
                                    channelGroup = groupName,
                                    channelName = channelName
                                )
                                Log.d("SubtitleDebug", "Résultat traduit: \"$translated\"")

                                if (_subtitleTranslationEnabled.value && lastBitmapHash == bitmapHash) {
                                    _translatedNativeSubtitleText.value = if (translated.isNotBlank()) translated else null
                                    syncSubtitleDisplay()
                                }
                            } else {
                                _translatedNativeSubtitleText.value = null
                                syncSubtitleDisplay()
                            }
                        } catch (e: Exception) {
                            Log.w("SubtitleDebug", "Erreur lors de l'OCR/traduction bitmap: ${e.message}")
                            if (lastBitmapHash == bitmapHash) {
                                _nativeSubtitleText.value = null
                                _translatedNativeSubtitleText.value = null
                                syncSubtitleDisplay()
                            }
                        }
                    }
                    return
                }

                // If neither text nor bitmap is present
                lastRawCueText = null
                lastBitmapHash = null
                lastOcrJob?.cancel()
                _nativeSubtitleText.value = null
                _translatedNativeSubtitleText.value = null
                syncSubtitleDisplay()
            }
        })
    }

    private var sharedExoPlayer: ExoPlayer? = null

    @Synchronized
    fun getSharedPlayer(): ExoPlayer {
        val player = sharedExoPlayer
        if (player != null) return player

        val context = getApplication<Application>()
        val newPlayer = try {
            // Fast start LoadControl optimized for instant playback (<0.5s) without timeout
            val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                    5000,  // minBufferMs: 5s
                    30000, // maxBufferMs: 30s
                    500,   // bufferForPlaybackMs: 0.5s for instant zap
                    1500   // bufferForPlaybackAfterRebufferMs: 1.5s
                )
                .setBackBuffer(5000, false)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build()

            // Initialiser le gestionnaire Sherpa-ONNX TV et s'assurer que le modèle français est prêt
            com.example.data.SherpaSubtitleManager.initialize(context)

            val offloadPrefs = androidx.media3.common.TrackSelectionParameters.AudioOffloadPreferences.Builder()
                .setAudioOffloadMode(androidx.media3.common.TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_DISABLED)
                .setIsGaplessSupportRequired(false)
                .setIsSpeedChangeSupportRequired(false)
                .build()

            val trackSelector = androidx.media3.exoplayer.trackselection.DefaultTrackSelector(context)
            trackSelector.setParameters(
                trackSelector.buildUponParameters()
                    .setAllowAudioMixedMimeTypeAdaptiveness(true)
                    .setAllowVideoMixedMimeTypeAdaptiveness(true)
                    .setAllowAudioMixedSampleRateAdaptiveness(true)
                    .setAllowAudioMixedChannelCountAdaptiveness(true)
                    .setAllowAudioNonSeamlessAdaptiveness(true)
                    .setAllowVideoNonSeamlessAdaptiveness(true)
                    .setTunnelingEnabled(false)
                    .setAudioOffloadPreferences(offloadPrefs)
                    .setSelectUndeterminedTextLanguage(true)
                    .setIgnoredTextSelectionFlags(0)
                    .build()
            )

            val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
                .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
                .build()

            val renderersFactory = object : androidx.media3.exoplayer.DefaultRenderersFactory(context) {
                override fun buildAudioSink(
                    sinkContext: android.content.Context,
                    enableFloatOutput: Boolean,
                    enableAudioTrackPlaybackParams: Boolean
                ): androidx.media3.exoplayer.audio.AudioSink {
                    return androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(sinkContext)
                        .setAudioCapabilities(androidx.media3.exoplayer.audio.AudioCapabilities.DEFAULT_AUDIO_CAPABILITIES)
                        .setEnableFloatOutput(enableFloatOutput)
                        .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                        .setAudioProcessors(arrayOf(com.example.data.SherpaSubtitleManager.createMedia3AudioProcessor()))
                        .build()
                }
            }.apply {
                setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                setEnableDecoderFallback(true)
                setMediaCodecSelector(androidx.media3.exoplayer.mediacodec.MediaCodecSelector.DEFAULT)
                setAllowedVideoJoiningTimeMs(5000)
            }

            ExoPlayer.Builder(context)
                .setRenderersFactory(renderersFactory)
                .setTrackSelector(trackSelector)
                .setLoadControl(loadControl)
                .setAudioAttributes(audioAttributes, true)
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(androidx.media3.common.C.WAKE_MODE_NETWORK)
                .setSeekBackIncrementMs(10000)
                .setSeekForwardIncrementMs(10000)
                .build().apply {
                    experimentalSetOffloadSchedulingEnabled(false)
                    videoScalingMode = androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                    setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC)
                    setForegroundMode(true)
                    val enableText = _subtitlesEnabled.value || _subtitleTranslationEnabled.value
                    var trackParams = trackSelectionParameters.buildUpon()
                        .setAudioOffloadPreferences(offloadPrefs)
                        .setSelectUndeterminedTextLanguage(true)
                        .setIgnoredTextSelectionFlags(0)
                        .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, !enableText)
                    val prefAudio = _preferredAudioLanguage.value
                    if (prefAudio != "auto" && prefAudio.isNotBlank()) {
                        trackParams = trackParams.setPreferredAudioLanguage(prefAudio)
                    }
                    val prefSub = _preferredSubtitleLanguage.value
                    if (prefSub != "auto" && prefSub.isNotBlank()) {
                        trackParams = trackParams.setPreferredTextLanguage(prefSub)
                    }
                    trackSelectionParameters = trackParams.build()
                    setPlaybackSpeed(_playbackSpeedState.value)
                }
        } catch (e: Exception) {
            Log.e("IptvViewModel", "Exception building shared player: ${e.message}", e)
            ExoPlayer.Builder(context).build().apply {
                videoScalingMode = androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC)
                setForegroundMode(true)
            }
        }

        newPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                Log.e("IptvPlayer", "Player error encountered: ${error.errorCodeName} (${error.errorCode}): ${error.message}", error)
                if (error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    newPlayer.seekToDefaultPosition()
                    newPlayer.prepare()
                    newPlayer.play()
                }
            }

            override fun onPositionDiscontinuity(
                oldPosition: androidx.media3.common.Player.PositionInfo,
                newPosition: androidx.media3.common.Player.PositionInfo,
                reason: Int
            ) {
                if (reason == androidx.media3.common.Player.DISCONTINUITY_REASON_SEEK) {
                    com.example.data.SherpaSubtitleManager.resetRecognitionState()
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!isPlaying && _voiceSubtitlesEnabled.value) {
                    com.example.data.SherpaSubtitleManager.flushAccumulator()
                }
            }
        })
        attachSubtitleTranslationListener(newPlayer)
        sharedExoPlayer = newPlayer
        return newPlayer
    }

    private fun resolvePlayableUri(context: android.content.Context, rawUriString: String): android.net.Uri {
        if (!rawUriString.startsWith("content://") && !rawUriString.startsWith("file://")) {
            return android.net.Uri.parse(rawUriString)
        }
        val uri = android.net.Uri.parse(rawUriString)
        if (rawUriString.startsWith("content://")) {
            try {
                context.contentResolver.openAssetFileDescriptor(uri, "r")?.use {
                    return uri
                }
            } catch (e: Exception) {
                Log.w("IptvPlayer", "Could not open content URI directly: ${e.message}, attempting file query")
            }
            try {
                val projection = arrayOf(android.provider.MediaStore.Video.Media.DATA)
                context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(android.provider.MediaStore.Video.Media.DATA)
                        if (idx != -1) {
                            val filePath = cursor.getString(idx)
                            if (!filePath.isNullOrBlank()) {
                                val file = java.io.File(filePath)
                                if (file.exists() && file.length() > 0) {
                                    return android.net.Uri.fromFile(file)
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("IptvPlayer", "Error querying file path for content URI: ${e.message}")
            }
        } else if (rawUriString.startsWith("file://")) {
            val filePath = rawUriString.removePrefix("file://")
            val file = java.io.File(filePath)
            if (file.exists()) {
                return android.net.Uri.fromFile(file)
            }
        }
        return uri
    }

    fun playOnSharedPlayer(streamUrl: String, headers: Map<String, String>, isMuted: Boolean = false, startPositionMs: Long = 0L) {
        com.example.debug.GlobalDebugSystem.logFunctionCall("playOnSharedPlayer", "url" to streamUrl, "isMuted" to isMuted, "startPos" to startPositionMs)
        val player = getSharedPlayer()
        val currentUri = player.currentMediaItem?.localConfiguration?.uri?.toString() ?: ""
        if (currentUri == streamUrl && player.playbackState != Player.STATE_IDLE) {
            player.volume = if (isMuted) 0f else 1f
            if (!player.playWhenReady) {
                player.playWhenReady = true
            }
            return
        }

        player.stop()
        player.clearMediaItems()
        
        // Initialiser ou préserver la détection de langue de la chaîne sélectionnée
        val currentChannel = _selectedChannel.value
        val channelLangHint = currentChannel?.let {
            com.example.data.TranslationManager.inferLanguageFromChannel(it.groupName, it.name)
        }
        if (channelLangHint != null) {
            activeSubtitleLanguage = channelLangHint
            _detectedSubtitleLanguage.value = com.example.data.TranslationManager.getLanguageDisplayName(channelLangHint)
        } else if (activeSubtitleLanguage == null) {
            _detectedSubtitleLanguage.value = null
        }

        // Si le sous-titrage vocal est activé, synchroniser dynamiquement la langue avec la nouvelle chaîne
        if (_voiceSubtitlesEnabled.value) {
            val resolvedLang = if (_voiceSubtitleLanguage.value == "auto" || _voiceSubtitleLanguage.value.isBlank()) {
                resolveChannelLanguageCode()
            } else {
                _voiceSubtitleLanguage.value
            }
            liveVoiceSourceLang.value = resolvedLang
            if (com.example.data.SherpaSubtitleManager.selectedVoiceModelId.value != resolvedLang || 
                !com.example.data.SherpaSubtitleManager.isVoiceRecognitionActive.value) {
                val appCtx = getApplication<Application>()
                com.example.data.SherpaSubtitleManager.setSourceLanguage(resolvedLang, appCtx)
            }
        }
        
        _nativeSubtitleText.value = null
        _translatedNativeSubtitleText.value = null
        _voiceSubtitleText.value = null
        _translatedVoiceSubtitleText.value = null
        _currentSubtitleText.value = null
        _translatedSubtitleText.value = null
        lastRawCueText = null
        lastBitmapHash = null
        lastOcrJob?.cancel()
        lastVoiceTranslationJob?.cancel()
        com.example.data.SherpaSubtitleManager.resetRecognitionState()
        
        if (streamUrl.isBlank()) return

        val context = getApplication<Application>()
        val isLocalFile = streamUrl.startsWith("content://") || streamUrl.startsWith("file://")
        val targetUri = resolvePlayableUri(context, streamUrl)

        val httpDataSourceFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setKeepPostFor302Redirects(true)
            .setConnectTimeoutMs(30000)
            .setReadTimeoutMs(40000)

        val defaultReqProps = mutableMapOf<String, String>()
        defaultReqProps["Accept"] = "*/*"
        defaultReqProps["Connection"] = "keep-alive"
        if (headers.isNotEmpty()) {
            defaultReqProps.putAll(headers)
        }
        httpDataSourceFactory.setDefaultRequestProperties(defaultReqProps)

        val userAgent = headers["User-Agent"] ?: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        httpDataSourceFactory.setUserAgent(userAgent)

        val defaultDataSourceFactory = androidx.media3.datasource.DefaultDataSource.Factory(context, httpDataSourceFactory)

        val tsFlags = androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS

        val extractorsFactory = androidx.media3.extractor.DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
            .setConstantBitrateSeekingAlwaysEnabled(true)
            .setTsExtractorFlags(tsFlags)
            .setTsExtractorTimestampSearchBytes(3000 * 188)
            .setMatroskaExtractorFlags(0)
            .setMp4ExtractorFlags(androidx.media3.extractor.mp4.Mp4Extractor.FLAG_WORKAROUND_IGNORE_EDIT_LISTS)
            .setMp3ExtractorFlags(androidx.media3.extractor.mp3.Mp3Extractor.FLAG_ENABLE_INDEX_SEEKING)
            .setAdtsExtractorFlags(androidx.media3.extractor.ts.AdtsExtractor.FLAG_ENABLE_CONSTANT_BITRATE_SEEKING)
            .setFlacExtractorFlags(androidx.media3.extractor.flac.FlacExtractor.FLAG_DISABLE_ID3_METADATA)
            .setAmrExtractorFlags(androidx.media3.extractor.amr.AmrExtractor.FLAG_ENABLE_CONSTANT_BITRATE_SEEKING)

        val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(context, extractorsFactory)
            .setDataSourceFactory(defaultDataSourceFactory)

        val mediaItemBuilder = MediaItem.Builder().setUri(targetUri)
        val rawHeaderMime = headers["mime"]
        val cleanUrlLower = streamUrl.lowercase()
        val mimeType = if (isLocalFile) {
            null
        } else if (rawHeaderMime == "AUTO" || rawHeaderMime == "auto") {
            null
        } else if (!rawHeaderMime.isNullOrBlank()) {
            rawHeaderMime
        } else {
            when {
                cleanUrlLower.contains(".m3u8") || cleanUrlLower.contains("type=m3u8") || cleanUrlLower.contains("format=m3u8") -> androidx.media3.common.MimeTypes.APPLICATION_M3U8
                cleanUrlLower.contains(".mpd") || cleanUrlLower.contains("type=mpd") || cleanUrlLower.contains("format=mpd") -> androidx.media3.common.MimeTypes.APPLICATION_MPD
                cleanUrlLower.contains(".ism") -> androidx.media3.common.MimeTypes.APPLICATION_SS
                cleanUrlLower.startsWith("rtsp://") -> androidx.media3.common.MimeTypes.APPLICATION_RTSP
                cleanUrlLower.endsWith(".ts") || cleanUrlLower.contains(".ts?") || cleanUrlLower.contains("output=ts") || cleanUrlLower.contains("format=ts") -> androidx.media3.common.MimeTypes.VIDEO_MP2T
                cleanUrlLower.endsWith(".mkv") || cleanUrlLower.contains(".mkv?") || cleanUrlLower.contains("output=mkv") -> androidx.media3.common.MimeTypes.VIDEO_MATROSKA
                cleanUrlLower.endsWith(".mp4") || cleanUrlLower.contains(".mp4?") || cleanUrlLower.endsWith(".m4v") || cleanUrlLower.contains(".m4v?") || cleanUrlLower.endsWith(".mov") || cleanUrlLower.contains(".mov?") || cleanUrlLower.contains("output=mp4") -> androidx.media3.common.MimeTypes.VIDEO_MP4
                cleanUrlLower.endsWith(".webm") || cleanUrlLower.contains(".webm?") -> androidx.media3.common.MimeTypes.VIDEO_WEBM
                cleanUrlLower.endsWith(".avi") || cleanUrlLower.contains(".avi?") -> androidx.media3.common.MimeTypes.VIDEO_AVI
                cleanUrlLower.endsWith(".flv") || cleanUrlLower.contains(".flv?") -> androidx.media3.common.MimeTypes.VIDEO_FLV
                cleanUrlLower.endsWith(".mp3") || cleanUrlLower.contains(".mp3?") -> androidx.media3.common.MimeTypes.AUDIO_MPEG
                cleanUrlLower.endsWith(".aac") || cleanUrlLower.contains(".aac?") -> androidx.media3.common.MimeTypes.AUDIO_AAC
                cleanUrlLower.endsWith(".flac") || cleanUrlLower.contains(".flac?") -> androidx.media3.common.MimeTypes.AUDIO_FLAC
                cleanUrlLower.endsWith(".wav") || cleanUrlLower.contains(".wav?") -> androidx.media3.common.MimeTypes.AUDIO_WAV
                cleanUrlLower.endsWith(".ogg") || cleanUrlLower.contains(".ogg?") || cleanUrlLower.endsWith(".opus") || cleanUrlLower.contains(".opus?") -> androidx.media3.common.MimeTypes.AUDIO_OGG
                else -> null
            }
        }
        if (mimeType != null) {
            mediaItemBuilder.setMimeType(mimeType)
        }

        val builtMediaItem = mediaItemBuilder.build()
        val mediaSource = if (mimeType == androidx.media3.common.MimeTypes.APPLICATION_M3U8 || cleanUrlLower.contains(".m3u8") || cleanUrlLower.contains("type=m3u8") || cleanUrlLower.contains("format=m3u8")) {
            androidx.media3.exoplayer.hls.HlsMediaSource.Factory(defaultDataSourceFactory)
                .setAllowChunklessPreparation(false)
                .setExtractorFactory(androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory(tsFlags, true))
                .createMediaSource(builtMediaItem)
        } else {
            mediaSourceFactory.createMediaSource(builtMediaItem)
        }

        player.setMediaSource(mediaSource)
        player.playWhenReady = true
        player.volume = if (isMuted) 0f else 1f
        val posToSeek = if (startPositionMs > 0L) startPositionMs else pendingStartPositionMs
        if (posToSeek > 0L) {
            player.seekTo(posToSeek)
            pendingStartPositionMs = 0L
        }
        player.prepare()
        applyTrackSelectionPreferences()
        if (_voiceSubtitlesEnabled.value) {
            com.example.data.SherpaSubtitleManager.resetRecognitionState()
        }
    }

    private val okHttpClient = com.example.data.getUnsafeOkHttpClient()
    private val apiService = ApiService(okHttpClient)
    private val stalkerRepository = StalkerRepository(application, apiService)

    private val repository = IptvRepository(application)
    private val db = AppDatabase.getDatabase(application)
    private val stalkerSeriesCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, List<EpisodeItem>>>()

    private fun cleanSeasonNumber(seasonNum: String): String {
        var s = seasonNum.trim()
        if (s.contains(":")) {
            s = s.substringAfter(":")
        } else if (s.contains("_")) {
            s = s.substringAfterLast("_")
        }
        val num = s.toIntOrNull()
        if (num != null) return num.toString()
        return s.ifEmpty { "1" }
    }

    private fun formatEpisodeName(seasonNum: String, episodeNum: String, title: String): String {
        val cleanSeason = cleanSeasonNumber(seasonNum)
        val cleanEpisode = episodeNum.replace("\r", "").replace("\n", " ").replace("\\s+".toRegex(), " ").trim()
        val cleanedTitle = cleanEpisodeTitle(title)
        
        return if (cleanedTitle.isNotEmpty()) {
            "Épisode $cleanEpisode: $cleanedTitle"
        } else {
            "Épisode $cleanEpisode"
        }
    }

    // Playlists
    val playlists: StateFlow<List<PlaylistItem>> = repository.getAllPlaylists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedPlaylist = MutableStateFlow<PlaylistItem?>(null)
    val selectedPlaylist: StateFlow<PlaylistItem?> = _selectedPlaylist.asStateFlow()

    // Channels & Categories
    private val _channels = MutableStateFlow<List<ChannelItem>>(emptyList())
    val channels: StateFlow<List<ChannelItem>> = _channels.asStateFlow()

    private val _seriesEpisodes = MutableStateFlow<List<EpisodeItem>>(emptyList())
    val seriesEpisodes: StateFlow<List<EpisodeItem>> = _seriesEpisodes.asStateFlow()

    private val _seriesEpisodesLoading = MutableStateFlow(false)
    val seriesEpisodesLoading: StateFlow<Boolean> = _seriesEpisodesLoading.asStateFlow()

    private val _seriesEpisodesError = MutableStateFlow<String?>(null)
    val seriesEpisodesError: StateFlow<String?> = _seriesEpisodesError.asStateFlow()

    private val _categories = MutableStateFlow<List<String>>(emptyList())
    val categories: StateFlow<List<String>> = _categories.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Tous")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedSubcategory = MutableStateFlow("Tous")
    val selectedSubcategory: StateFlow<String> = _selectedSubcategory.asStateFlow()

    private val _selectedChannel = MutableStateFlow<ChannelItem?>(null)
    val selectedChannel: StateFlow<ChannelItem?> = _selectedChannel.asStateFlow()

    private val _fetchedMoviePoster = MutableStateFlow<String?>(null)
    val fetchedMoviePoster: StateFlow<String?> = _fetchedMoviePoster.asStateFlow()

    // Screen navigation: "TvHome", "Playlists", "Live", "Movies", "Series", "Recordings", "Settings"
    private val _currentScreen = MutableStateFlow("TvHome")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val _isLiveCategorySelected = MutableStateFlow(false)
    val isLiveCategorySelected: StateFlow<Boolean> = _isLiveCategorySelected.asStateFlow()

    private val _isMovieCategorySelected = MutableStateFlow(false)
    val isMovieCategorySelected: StateFlow<Boolean> = _isMovieCategorySelected.asStateFlow()

    private val _seriesStep = MutableStateFlow("CategoryScreen")
    val seriesStep: StateFlow<String> = _seriesStep.asStateFlow()

    fun setLiveCategorySelected(value: Boolean) {
        _isLiveCategorySelected.value = value
    }

    fun setMovieCategorySelected(value: Boolean) {
        _isMovieCategorySelected.value = value
    }

    fun setSeriesStep(step: String) {
        _seriesStep.value = step
    }

    private val sharedPrefs = application.getSharedPreferences("iptv_settings", android.content.Context.MODE_PRIVATE)

    // App Settings
    private val _useExternalPlayer = MutableStateFlow(sharedPrefs.getBoolean("use_external_player", false))
    val useExternalPlayer: StateFlow<Boolean> = _useExternalPlayer.asStateFlow()

    private val _allowInternalStorageRecording = MutableStateFlow(sharedPrefs.getBoolean("allow_internal_storage_recording", true))
    val allowInternalStorageRecording: StateFlow<Boolean> = _allowInternalStorageRecording.asStateFlow()

    fun setUseExternalPlayer(value: Boolean) {
        _useExternalPlayer.value = value
        sharedPrefs.edit().putBoolean("use_external_player", value).apply()
    }

    fun setAllowInternalStorageRecording(value: Boolean) {
        _allowInternalStorageRecording.value = value
        sharedPrefs.edit().putBoolean("allow_internal_storage_recording", value).apply()
    }

    // Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Import State
    private val _importState = MutableStateFlow<ImportState>(ImportState.Idle)
    val importState: StateFlow<ImportState> = _importState.asStateFlow()

    private val _bulkImportProgress = MutableStateFlow(BulkImportProgressState())
    val bulkImportProgress: StateFlow<BulkImportProgressState> = _bulkImportProgress.asStateFlow()

    private val _bulkMacTestProgress = MutableStateFlow(BulkMacTestProgress())
    val bulkMacTestProgress: StateFlow<BulkMacTestProgress> = _bulkMacTestProgress.asStateFlow()

    private var bulkMacTestJob: kotlinx.coroutines.Job? = null

    // Playback state
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isPipMode = MutableStateFlow(false)
    val isPipMode: StateFlow<Boolean> = _isPipMode.asStateFlow()

    private val _isFullScreen = MutableStateFlow(false)
    val isFullScreen: StateFlow<Boolean> = _isFullScreen.asStateFlow()

    // Active lists/categories state persistence across transitions (unmounting)
    val lastSelectedMovieCategory = MutableStateFlow("Tous")
    val lastActiveMovie = MutableStateFlow<ChannelItem?>(null)

    val lastSelectedSeriesCategory = MutableStateFlow("Tous")
    val lastActiveSeries = MutableStateFlow<ChannelItem?>(null)

    fun setFullScreen(value: Boolean) {
        _isFullScreen.value = value
    }

    fun setPipMode(value: Boolean) {
        _isPipMode.value = value
    }

    // Recordings State
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _recordingChannel = MutableStateFlow<ChannelItem?>(null)
    val recordingChannel: StateFlow<ChannelItem?> = _recordingChannel.asStateFlow()

    private val _recordingDurationSeconds = MutableStateFlow(0)
    val recordingDurationSeconds: StateFlow<Int> = _recordingDurationSeconds.asStateFlow()

    private val _recordingsList = MutableStateFlow<List<RecordingItem>>(emptyList())
    val recordingsList: StateFlow<List<RecordingItem>> = _recordingsList.asStateFlow()

    private val _recordingError = MutableStateFlow<String?>(null)
    val recordingError: StateFlow<String?> = _recordingError.asStateFlow()

    fun clearRecordingError() {
        _recordingError.value = null
    }

    // Watch Progress State & Models
    data class CurrentWatchMedia(
        val playlistId: Long,
        val contentType: String, // "series" or "movie"
        val showId: String = "",
        val seasonNumber: Int = -1,
        val episodeNumber: Int = -1,
        val episodeId: String,
        val title: String,
        val posterUrl: String = ""
    )

    data class ResumeDialogData(
        val watchProgress: WatchProgress,
        val onResume: () -> Unit,
        val onRestart: () -> Unit
    )

    val watchProgressList: StateFlow<List<WatchProgress>> = repository.getRecentWatchProgress()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _resumeDialogData = MutableStateFlow<ResumeDialogData?>(null)
    val resumeDialogData: StateFlow<ResumeDialogData?> = _resumeDialogData.asStateFlow()

    fun dismissResumeDialog() {
        _resumeDialogData.value = null
    }

    private val _currentWatchMedia = MutableStateFlow<CurrentWatchMedia?>(null)
    val currentWatchMedia: StateFlow<CurrentWatchMedia?> = _currentWatchMedia.asStateFlow()

    private var watchProgressTrackerJob: kotlinx.coroutines.Job? = null
    var pendingStartPositionMs: Long = 0L

    fun parseSeasonAndEpisodeNumbers(name: String): Pair<Int, Int> {
        val sXe = Regex("""(?i)S(\d+)\s*[-:]?\s*(?:E|EP)\s*(\d+)""").find(name)
            ?: Regex("""(?i)(\d+)x(\d+)""").find(name)
            ?: Regex("""(?i)Saison\s*(\d+)\s*[-:]?\s*É?pisode\s*(\d+)""").find(name)
            ?: Regex("""(?i)Season\s*(\d+)\s*[-:]?\s*Episode\s*(\d+)""").find(name)
            ?: Regex("""(?i)الموسم\s*(\d+)\s*[-:]?\s*الحلقة\s*(\d+)""").find(name)
        if (sXe != null) {
            val s = sXe.groupValues[1].toIntOrNull() ?: -1
            val e = sXe.groupValues[2].toIntOrNull() ?: -1
            return Pair(s, e)
        }

        val sMatch = Regex("""(?i)(?:s|saison|season|الموسم)\s*(\d+)""").find(name)
        val eMatch = Regex("""(?i)(?:e|ep|é?pisode|episode|الحلقة|حلقة|ح)\s*(\d+)""").find(name)
            ?: Regex("""(?i)(?:-|:|\/)\s*(\d+)\s*$""").find(name)
            ?: Regex("""\b(\d+)\s*$""").find(name)
        val season = sMatch?.groupValues?.get(1)?.toIntOrNull() ?: -1
        val episode = eMatch?.groupValues?.get(1)?.toIntOrNull() ?: -1
        return Pair(season, episode)
    }

    fun startWatchProgressTracker() {
        watchProgressTrackerJob?.cancel()
        watchProgressTrackerJob = viewModelScope.launch {
            while (isActive) {
                delay(10000L)
                saveCurrentWatchProgress()
            }
        }
    }

    fun saveCurrentWatchProgress() {
        val media = _currentWatchMedia.value ?: return
        val player = sharedExoPlayer ?: return

        val pos = player.currentPosition
        val dur = player.duration.coerceAtLeast(0L)

        if (pos <= 0L) return

        viewModelScope.launch(Dispatchers.IO) {
            if (dur > 0L && (pos.toFloat() / dur.toFloat()) >= 0.95f) {
                repository.deleteWatchProgress(media.playlistId, media.episodeId)
            } else if (pos >= 5000L) {
                val progress = WatchProgress(
                    playlistId = media.playlistId,
                    contentType = media.contentType,
                    showId = media.showId,
                    seasonNumber = media.seasonNumber,
                    episodeNumber = media.episodeNumber,
                    episodeId = media.episodeId,
                    title = media.title,
                    posterUrl = media.posterUrl,
                    positionMs = pos,
                    durationMs = dur,
                    lastWatchedAt = System.currentTimeMillis()
                )
                repository.saveWatchProgress(progress)
            }
        }
    }

    fun stopWatchProgressTracker() {
        saveCurrentWatchProgress()
        watchProgressTrackerJob?.cancel()
        watchProgressTrackerJob = null
        _currentWatchMedia.value = null
    }

    fun removeWatchProgress(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteWatchProgressById(id)
        }
    }

    fun clearAllWatchProgress() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAllWatchProgress()
        }
    }

    fun resumeWatchProgressDirectly(item: WatchProgress) {
        val channel = ChannelItem(
            playlistId = item.playlistId,
            name = item.title,
            logoUrl = item.posterUrl,
            streamUrl = item.episodeId,
            groupName = "Continuer à regarder",
            type = if (item.contentType.equals("series", ignoreCase = true)) "Series" else "Movie"
        )
        selectChannel(channel, keepFullScreen = true, skipResumeCheck = true, startPositionMs = item.positionMs)
    }

    // Playlist Summaries: Map<PlaylistId, Triple<Live, Movie, Series>>
    private val _playlistSummaries = MutableStateFlow<Map<Long, Triple<Int, Int, Int>>>(emptyMap())
    val playlistSummaries: StateFlow<Map<Long, Triple<Int, Int, Int>>> = _playlistSummaries.asStateFlow()

    // Favorites & History
    private val _favorites = MutableStateFlow<List<FavoriteItem>>(emptyList())
    val favorites: StateFlow<List<FavoriteItem>> = _favorites.asStateFlow()

    private val _history = MutableStateFlow<List<HistoryItem>>(emptyList())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    // Web Server State
    private var serverSocket: ServerSocket? = null
    
    private val _webServerIp = MutableStateFlow<String?>(null)
    val webServerIp: StateFlow<String?> = _webServerIp.asStateFlow()
    
    val webServerPort = 8080
    
    private val _webServerStatus = MutableStateFlow("Arrêté")
    val webServerStatus: StateFlow<String> = _webServerStatus.asStateFlow()

    // Active Playback State (resolved URL and headers)
    private val _playbackUrl = MutableStateFlow<String?>(null)
    val playbackUrl: StateFlow<String?> = _playbackUrl.asStateFlow()

    private val _playbackHeaders = MutableStateFlow<Map<String, String>>(emptyMap())
    val playbackHeaders: StateFlow<Map<String, String>> = _playbackHeaders.asStateFlow()

    private val _playbackLoading = MutableStateFlow(false)
    val playbackLoading: StateFlow<Boolean> = _playbackLoading.asStateFlow()

    private val _playbackError = MutableStateFlow<String?>(null)
    val playbackError: StateFlow<String?> = _playbackError.asStateFlow()

    // Timeshift (Catchup) state
    private val _isTimeshiftActive = MutableStateFlow(false)
    val isTimeshiftActive: StateFlow<Boolean> = _isTimeshiftActive.asStateFlow()
    val isPlayingCatchup: StateFlow<Boolean> = _isTimeshiftActive.asStateFlow()

    private val _currentTimeshiftProgram = MutableStateFlow<EpgProgram?>(null)
    val currentTimeshiftProgram: StateFlow<EpgProgram?> = _currentTimeshiftProgram.asStateFlow()

    private val _catchupEpg = MutableStateFlow<List<EpgProgram>>(emptyList())
    val catchupEpg: StateFlow<List<EpgProgram>> = _catchupEpg.asStateFlow()

    private val _loadingCatchupEpg = MutableStateFlow(false)
    val loadingCatchupEpg: StateFlow<Boolean> = _loadingCatchupEpg.asStateFlow()

    private val _epgProgramsList = MutableStateFlow<List<EpgProgramItem>>(emptyList())
    val epgProgramsList: StateFlow<List<EpgProgramItem>> = _epgProgramsList.asStateFlow()

    private val _isLoadingEpg = MutableStateFlow(false)
    val isLoadingEpg: StateFlow<Boolean> = _isLoadingEpg.asStateFlow()

    private val _catchupError = MutableStateFlow<String?>(null)
    val catchupError: StateFlow<String?> = _catchupError.asStateFlow()

    init {
        // Automatically fetch recent history
        viewModelScope.launch {
            repository.getRecentHistory().collect {
                _history.value = it
            }
        }
        
        // Auto-select first playlist if available and load channel summaries
        viewModelScope.launch {
            playlists.collect { list ->
                if (list.isNotEmpty() && _selectedPlaylist.value == null) {
                    selectPlaylist(list.first())
                }
                
                // Fetch summaries on background IO dispatcher
                withContext(Dispatchers.IO) {
                    val summaries = mutableMapOf<Long, Triple<Int, Int, Int>>()
                    for (pl in list) {
                        summaries[pl.id] = repository.getPlaylistSummary(pl.id)
                    }
                    _playlistSummaries.value = summaries
                }
            }
        }

        // Automatically fetch recordings
        viewModelScope.launch {
            repository.getAllRecordings().collect {
                _recordingsList.value = it
            }
        }
        
        // Start the remote import web server
        startWebServer()

        // Tous les textes (partiels ET finaux) arrivent désormais par le même canal, APRÈS la ligne à retard
        // de synchronisation du gestionnaire (offset manuel / auto). Avant, les partiels contournaient
        // ce délai : le réglage de synchro n'avait aucun effet en mode streaming.
        com.example.data.SherpaSubtitleManager.setOnPartialListener(null)
        com.example.data.SherpaSubtitleManager.setOnFinalListener(null)

        com.example.data.SherpaSubtitleManager.setOnSpeechResultListener { recognizedText ->
            if (!_voiceSubtitlesEnabled.value) return@setOnSpeechResultListener
            if (recognizedText.isBlank()) {
                _voiceSubtitleText.value = null
                _translatedVoiceSubtitleText.value = null
                syncSubtitleDisplay()
            } else {
                processVoiceTranslation(
                    recognizedText,
                    isFinal = com.example.data.SherpaSubtitleManager.lastEmittedIsFinal
                )
            }
        }

    }

    override fun onCleared() {
        super.onCleared()
        stopWebServer()
        lastOcrJob?.cancel()
        com.example.data.SherpaSubtitleManager.stopVoiceRecognition()
        com.example.data.SherpaSubtitleManager.setOnSpeechResultListener(null)
        com.example.data.SherpaSubtitleManager.setOnPartialListener(null)
        com.example.data.SherpaSubtitleManager.setOnFinalListener(null)
        try {
            textRecognizer.close()
        } catch (e: Exception) {
            Log.w("IptvViewModel", "Error closing textRecognizer: ${e.message}")
        }
        sharedExoPlayer?.let { player ->
            try {
                player.release()
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error releasing sharedExoPlayer: ${e.message}")
            }
            sharedExoPlayer = null
        }
    }

    fun setScreen(screen: String) {
        com.example.debug.GlobalDebugSystem.logFunctionCall("setScreen", "screen" to screen)
        val oldScreen = _currentScreen.value
        if (screen != "Live" && _currentScreen.value != screen) {
            stopPlayback()
        }
        _currentScreen.value = screen
        com.example.debug.GlobalDebugSystem.logStateChange("currentScreen", oldScreen, screen)
        _selectedCategory.value = "Tous"
        _selectedSubcategory.value = "Tous"
        _searchQuery.value = ""
        _isLiveCategorySelected.value = false
        _isMovieCategorySelected.value = false
        _seriesStep.value = "CategoryScreen"
        filterChannels()
    }

    fun updatePlaylist(playlist: PlaylistItem) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updatePlaylist(playlist)
            if (_selectedPlaylist.value?.id == playlist.id) {
                _selectedPlaylist.value = playlist
            }
            refreshSummaries()
        }
    }

    fun refreshSummaries() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = playlists.value
            val summaries = mutableMapOf<Long, Triple<Int, Int, Int>>()
            for (pl in list) {
                summaries[pl.id] = repository.getPlaylistSummary(pl.id)
            }
            _playlistSummaries.value = summaries
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        filterChannels()
    }

    private val autoRefreshedPlaylists = mutableSetOf<Long>()
    private var channelsCollectionJob: kotlinx.coroutines.Job? = null

    fun selectPlaylist(playlist: PlaylistItem) {
        _selectedPlaylist.value = playlist
        _selectedCategory.value = "Tous"
        _selectedSubcategory.value = "Tous"
        _currentScreen.value = "TvHome"
        _isLiveCategorySelected.value = false
        _isMovieCategorySelected.value = false
        _seriesStep.value = "CategoryScreen"
        
        // Reset playback and selected channel when switching playlist
        _selectedChannel.value = null
        _playbackUrl.value = null
        _playbackHeaders.value = emptyMap()
        _isPlaying.value = false
        
        channelsCollectionJob?.cancel()
        channelsCollectionJob = viewModelScope.launch {
            repository.getChannels(playlist.id).collect { list ->
                val (cleanedList, categoriesList, summariesMap) = withContext(Dispatchers.Default) {
                    val isM3u = playlist.type.equals("M3U", ignoreCase = true)
                    val cleaned = ArrayList<ChannelItem>(list.size)
                    val groupsSet = java.util.LinkedHashSet<String>()
                    var liveCount = 0
                    var movieCount = 0
                    var seriesCount = 0

                    for (item in list) {
                        val name = item.groupName
                        val group = if (name.equals("null", ignoreCase = true) || name.contains("genre: null", ignoreCase = true) || name.contains("genre null", ignoreCase = true) || name.equals("Genre null", ignoreCase = true) || name.isEmpty()) {
                            "Général"
                        } else {
                            item.groupName
                        }

                        val correctedType = if (isM3u) {
                            repository.determineChannelType(item.name, group, item.streamUrl)
                        } else {
                            item.type
                        }

                        val ch = if (group == item.groupName && correctedType == item.type) {
                            item
                        } else {
                            item.copy(groupName = group, type = correctedType)
                        }
                        cleaned.add(ch)
                        groupsSet.add(group)

                        when (correctedType) {
                            "Live" -> liveCount++
                            "Movie" -> movieCount++
                            "Series" -> seriesCount++
                        }
                    }

                    val groups = groupsSet.sorted()
                    val categories = if (groups.contains("Tous")) groups else listOf("Tous") + groups
                    Triple(cleaned, categories, Triple(liveCount, movieCount, seriesCount))
                }

                _channels.value = cleanedList
                _categories.value = categoriesList
                
                val summaries = _playlistSummaries.value.toMutableMap()
                summaries[playlist.id] = summariesMap
                _playlistSummaries.value = summaries
                
                if (playlist.type == "Stalker" && 
                    !autoRefreshedPlaylists.contains(playlist.id) && 
                    cleanedList.any { it.groupName.startsWith("Stalker Live | Genre") }
                ) {
                    autoRefreshedPlaylists.add(playlist.id)
                    Log.d("IptvViewModel", "Old Stalker channels detected. Auto-refreshing playlist ${playlist.id} to fetch real categories.")
                    updateAndReimportPlaylist(playlist)
                }
            }
        }
    }

    fun selectCategory(category: String) {
        if (_currentScreen.value == "Series") lastSelectedSeriesCategory.value = category
        if (_currentScreen.value == "Movies") lastSelectedMovieCategory.value = category
        _selectedCategory.value = category
        _selectedSubcategory.value = "Tous"
        
        // Automatically select the first channel/item of the newly selected category
        val currentChannels = _channels.value
        val screen = _currentScreen.value
        val filtered = when (screen) {
            "Movies" -> {
                if (category == "Tous" || category.isEmpty()) {
                    currentChannels.filter { it.type == "Movie" || it.type == "VOD" }
                } else {
                    currentChannels.filter { (it.type == "Movie" || it.type == "VOD") && it.groupName.equals(category, ignoreCase = true) }
                }
            }
            "Series" -> {
                if (category == "Tous" || category.isEmpty()) {
                    currentChannels.filter { it.type == "Series" }
                } else {
                    currentChannels.filter { it.type == "Series" && it.groupName.equals(category, ignoreCase = true) }
                }
            }
            else -> {
                if (category == "Tous" || category.isEmpty()) {
                    currentChannels.filter { it.type == "Live" || it.type == "TV" }
                } else {
                    currentChannels.filter { (it.type == "Live" || it.type == "TV") && it.groupName.equals(category, ignoreCase = true) }
                }
            }
        }
        val firstChannel = filtered.firstOrNull() ?: currentChannels.firstOrNull { category == "Tous" || category.isEmpty() || it.groupName.equals(category, ignoreCase = true) }
        if (firstChannel != null) {
            if (screen == "Movies") {
                lastActiveMovie.value = firstChannel
            } else if (screen == "Series") {
                if (lastActiveSeries.value == null) {
                    lastActiveSeries.value = firstChannel
                }
            } else {
                if (_isPlaying.value) {
                    selectChannel(firstChannel, keepFullScreen = _isFullScreen.value)
                } else {
                    selectChannelPreview(firstChannel)
                }
            }
        }
        filterChannels()
    }

    fun selectSubcategory(subcategory: String) {
        _selectedSubcategory.value = subcategory
        filterChannels()
    }

    fun getCategoryAndSubcategory(groupName: String): Pair<String, String> {
        return Pair(groupName, "Général")
    }

    private fun filterChannels() {
        // No-op. We keep channels cached in memory via selectPlaylist, and Compose UI filters them dynamically.
    }

    private var previewResolutionJob: kotlinx.coroutines.Job? = null
    private var posterFetchJob: kotlinx.coroutines.Job? = null

    fun fetchMoviePosterIfNeeded(channel: ChannelItem) {
        _fetchedMoviePoster.value = null
        posterFetchJob?.cancel()
        
        if (channel.logoUrl.isNotEmpty()) {
            _fetchedMoviePoster.value = channel.logoUrl
            return
        }

        posterFetchJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val cleanName = cleanMovieNameForSearch(channel.name)
                if (cleanName.isEmpty()) return@launch

                val encodedName = java.net.URLEncoder.encode(cleanName, "UTF-8")
                val url = "https://itunes.apple.com/search?term=$encodedName&limit=1"
                val request = Request.Builder().url(url).build()
                
                okHttpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val json = org.json.JSONObject(body)
                        val results = json.optJSONArray("results")
                        if (results != null && results.length() > 0) {
                            val firstResult = results.optJSONObject(0) ?: return@use
                            var artworkUrl = firstResult.optString("artworkUrl100")
                            if (artworkUrl.isNotEmpty()) {
                                artworkUrl = artworkUrl.replace("100x100bb", "500x500bb")
                                artworkUrl = artworkUrl.replace("100x100", "500x500")
                                _fetchedMoviePoster.value = artworkUrl
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error fetching poster for ${channel.name}: ${e.message}")
            }
        }
    }

    private fun cleanMovieNameForSearch(name: String): String {
        var clean = name
        // Remove quality tags
        clean = clean.replace(Regex("(?i)\\b(hd|sd|fhd|uhd|4k|1080p|720p|hevc|h265|x265|multi|french|truefrench|vf|vostfr|subfrench)\\b"), "")
        // Remove year like (2023) or [2023] or 2023
        clean = clean.replace(Regex("\\b(19|20)\\d{2}\\b"), "")
        // Remove brackets and parentheses content
        clean = clean.replace(Regex("\\[.*?\\]"), "")
        clean = clean.replace(Regex("\\(.*?\\)"), "")
        // Remove other common symbols
        clean = clean.replace(Regex("[|\\-:_]"), " ")
        // Normalize spaces
        clean = clean.replace(Regex("\\s+"), " ").trim()
        return clean
    }

    fun selectChannelPreview(channel: ChannelItem) {
        if (_selectedChannel.value?.streamUrl == channel.streamUrl && _playbackUrl.value != null) {
            _isPlaying.value = false
            return
        }
        _isTimeshiftActive.value = false
        _currentTimeshiftProgram.value = null
        _selectedChannel.value = channel
        val channelLangHint = com.example.data.TranslationManager.inferLanguageFromChannel(channel.groupName, channel.name)
        activeSubtitleLanguage = channelLangHint
        _detectedSubtitleLanguage.value = channelLangHint?.let { com.example.data.TranslationManager.getLanguageDisplayName(it) }

        // Réinitialiser immédiatement les sous-titres et l'état Sherpa
        _voiceSubtitleText.value = null
        _translatedVoiceSubtitleText.value = null
        _currentSubtitleText.value = null
        _translatedSubtitleText.value = null
        _nativeSubtitleText.value = null
        _translatedNativeSubtitleText.value = null
        lastRawCueText = null
        lastBitmapHash = null
        lastOcrJob?.cancel()
        lastVoiceTranslationJob?.cancel()
        com.example.data.SherpaSubtitleManager.resetRecognitionState()
        syncSubtitleDisplay()

        fetchMoviePosterIfNeeded(channel)
        _isPlaying.value = false
        _playbackUrl.value = null
        _playbackHeaders.value = emptyMap()
        _playbackLoading.value = true
        previewResolutionJob?.cancel()
        previewResolutionJob = viewModelScope.launch {
            // Debounce of 600ms to avoid aggressive player reloading when navigating quickly
            kotlinx.coroutines.delay(600)
            repository.addToHistory(channel.playlistId, channel.name, channel.streamUrl)
            checkFavoriteState(channel)
            loadEpgForChannel(channel)
            resolvePlayback(channel)
        }
    }

    fun selectChannel(channel: ChannelItem, keepFullScreen: Boolean = false, skipResumeCheck: Boolean = false, startPositionMs: Long = 0L) {
        com.example.debug.GlobalDebugSystem.logFunctionCall("selectChannel", "channel" to channel.name, "type" to channel.type, "keepFullScreen" to keepFullScreen)
        com.example.debug.GlobalDebugSystem.logStateChange("selectedChannel", _selectedChannel.value?.name, channel.name)
        saveCurrentWatchProgress()

        val targetPlaylistId = if (channel.playlistId != 0L) channel.playlistId else (_selectedPlaylist.value?.id ?: 0L)
        val isSeries = channel.type.equals("Series", ignoreCase = true)
        val isMovie = channel.type.equals("Movie", ignoreCase = true)

        if (isSeries || isMovie) {
            val contentType = if (isSeries) "series" else "movie"
            val activeSeries = lastActiveSeries.value
            val activeMovie = lastActiveMovie.value

            val showId = if (isSeries) {
                channel.stalkerId.ifEmpty {
                    activeSeries?.stalkerId?.ifEmpty { activeSeries.streamUrl } ?: activeSeries?.name ?: ""
                }
            } else ""

            val posterUrl = if (isSeries) {
                activeSeries?.logoUrl?.ifEmpty { channel.logoUrl } ?: channel.logoUrl
            } else {
                channel.logoUrl.ifEmpty { activeMovie?.logoUrl ?: "" }
            }

            val (seasonNum, epNum) = if (isSeries) parseSeasonAndEpisodeNumbers(channel.name) else Pair(-1, -1)

            val watchMedia = CurrentWatchMedia(
                playlistId = targetPlaylistId,
                contentType = contentType,
                showId = showId,
                seasonNumber = seasonNum,
                episodeNumber = epNum,
                episodeId = channel.streamUrl,
                title = channel.name,
                posterUrl = posterUrl
            )
            _currentWatchMedia.value = watchMedia

            if (!skipResumeCheck) {
                viewModelScope.launch {
                    val existing = withContext(Dispatchers.IO) {
                        repository.getWatchProgress(targetPlaylistId, channel.streamUrl)
                            ?: (if (targetPlaylistId != 0L) repository.getWatchProgress(0L, channel.streamUrl) else null)
                    } ?: watchProgressList.value.find { wp ->
                        wp.episodeId == channel.streamUrl ||
                        (wp.playlistId == targetPlaylistId && wp.episodeId == channel.streamUrl) ||
                        (isSeries && (wp.title.endsWith(channel.name) || channel.name.endsWith(wp.title)))
                    }
                    if (existing != null && existing.positionMs >= 5_000L) {
                        _resumeDialogData.value = ResumeDialogData(
                            watchProgress = existing,
                            onResume = {
                                _resumeDialogData.value = null
                                performActualSelectChannel(channel, keepFullScreen, startPositionMs = existing.positionMs)
                            },
                            onRestart = {
                                _resumeDialogData.value = null
                                viewModelScope.launch(Dispatchers.IO) {
                                    repository.deleteWatchProgress(targetPlaylistId, channel.streamUrl)
                                    if (targetPlaylistId != 0L) {
                                        repository.deleteWatchProgress(0L, channel.streamUrl)
                                    }
                                }
                                performActualSelectChannel(channel, keepFullScreen, startPositionMs = 0L)
                            }
                        )
                    } else {
                        performActualSelectChannel(channel, keepFullScreen, startPositionMs = startPositionMs)
                    }
                }
                return
            }
        } else {
            _currentWatchMedia.value = null
        }

        performActualSelectChannel(channel, keepFullScreen, startPositionMs = startPositionMs)
    }

    private var channelSelectionJob: kotlinx.coroutines.Job? = null

    private fun performActualSelectChannel(channel: ChannelItem, keepFullScreen: Boolean, startPositionMs: Long = 0L) {
        pendingStartPositionMs = startPositionMs
        val alreadyResolved = _selectedChannel.value?.streamUrl == channel.streamUrl && _playbackUrl.value != null
        _isTimeshiftActive.value = false
        _currentTimeshiftProgram.value = null
        _selectedChannel.value = channel
        val channelLangHint = com.example.data.TranslationManager.inferLanguageFromChannel(channel.groupName, channel.name)
        activeSubtitleLanguage = channelLangHint
        _detectedSubtitleLanguage.value = channelLangHint?.let { com.example.data.TranslationManager.getLanguageDisplayName(it) }

        // Couper immédiatement le flux audio de l'ancienne chaîne
        if (!alreadyResolved) {
            try {
                sharedExoPlayer?.stop()
                sharedExoPlayer?.clearMediaItems()
            } catch (e: Throwable) { }
        }

        // Réinitialiser immédiatement les sous-titres et l'état Sherpa
        _voiceSubtitleText.value = null
        _translatedVoiceSubtitleText.value = null
        _currentSubtitleText.value = null
        _translatedSubtitleText.value = null
        _nativeSubtitleText.value = null
        _translatedNativeSubtitleText.value = null
        lastRawCueText = null
        lastBitmapHash = null
        lastOcrJob?.cancel()
        lastVoiceTranslationJob?.cancel()
        com.example.data.SherpaSubtitleManager.resetRecognitionState()
        syncSubtitleDisplay()

        fetchMoviePosterIfNeeded(channel)
        _isPlaying.value = true
        if (keepFullScreen) {
            _isFullScreen.value = true
        } else {
            _isFullScreen.value = false
        }
        if (!alreadyResolved) {
            _playbackUrl.value = null
            _playbackHeaders.value = emptyMap()
            _playbackLoading.value = true
        }

        if (_currentWatchMedia.value != null) {
            startWatchProgressTracker()
        }

        channelSelectionJob?.cancel()
        channelSelectionJob = viewModelScope.launch {
            // 1. Démarrer immédiatement la résolution du flux vidéo sans attendre les requêtes EPG
            if (!alreadyResolved) {
                resolvePlayback(channel)
            }
            // 2. Traitement d'arrière-plan asynchrone pour l'historique et les favoris
            launch(Dispatchers.IO) {
                try {
                    repository.addToHistory(channel.playlistId, channel.name, channel.streamUrl)
                    checkFavoriteState(channel)
                } catch (e: Exception) { }
            }
            // 3. Charger l'EPG avec un léger délai pour zapper en toute fluidité
            kotlinx.coroutines.delay(200)
            loadEpgForChannel(channel)
        }
    }

    private val epgCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, List<EpgProgramItem>>>()
    private val epgDateCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, List<EpgProgram>>>()

    private fun serializeEpgItems(items: List<EpgProgramItem>): String {
        return try {
            val arr = org.json.JSONArray()
            for (it in items) {
                val obj = org.json.JSONObject()
                obj.put("id", it.id)
                obj.put("chId", it.chId)
                obj.put("name", it.name)
                obj.put("description", it.description)
                obj.put("startTimestamp", it.startTimestamp)
                obj.put("stopTimestamp", it.stopTimestamp)
                obj.put("startTimeFormatted", it.startTimeFormatted)
                obj.put("stopTimeFormatted", it.stopTimeFormatted)
                obj.put("realId", it.realId)
                obj.put("markArchive", it.markArchive)
                arr.put(obj)
            }
            arr.toString()
        } catch (e: Exception) {
            ""
        }
    }

    private fun deserializeEpgItems(jsonStr: String): List<EpgProgramItem> {
        return try {
            if (jsonStr.isEmpty()) return emptyList()
            val arr = org.json.JSONArray(jsonStr)
            val list = ArrayList<EpgProgramItem>(arr.length())
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    EpgProgramItem(
                        id = obj.optString("id"),
                        chId = obj.optString("chId"),
                        name = obj.optString("name"),
                        description = obj.optString("description"),
                        startTimestamp = obj.optLong("startTimestamp"),
                        stopTimestamp = obj.optLong("stopTimestamp"),
                        startTimeFormatted = obj.optString("startTimeFormatted"),
                        stopTimeFormatted = obj.optString("stopTimeFormatted"),
                        realId = obj.optString("realId"),
                        markArchive = obj.optInt("markArchive")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun loadCatchupEpg(channel: ChannelItem, forceRefresh: Boolean = false) {
        loadEpgForChannel(channel, forceRefresh)
    }

    private var loadEpgJob: kotlinx.coroutines.Job? = null

    fun loadEpgForChannel(channel: ChannelItem, forceRefresh: Boolean = false) {
        loadEpgJob?.cancel()
        loadEpgJob = viewModelScope.launch {
            _loadingCatchupEpg.value = true
            _isLoadingEpg.value = true
            _catchupError.value = null
            
            val cacheKey = "${channel.playlistId}_${channel.stalkerId.ifEmpty { channel.streamUrl }}"
            val now = System.currentTimeMillis()
            val cached = epgCache[cacheKey]
            if (!forceRefresh && cached != null && (now - cached.first) < 10 * 60 * 1000L) {
                Log.d("IptvViewModel", "Using memory-cached EPG for $cacheKey")
                _epgProgramsList.value = cached.second
                _catchupEpg.value = cached.second.map {
                    EpgProgram(
                        title = it.name,
                        startTime = it.startTimeFormatted,
                        endTime = it.stopTimeFormatted,
                        description = it.description,
                        startHour = 0,
                        endHour = 0,
                        startTimestamp = it.startTimestamp,
                        endTimestamp = it.stopTimestamp,
                        realId = it.realId,
                        id = it.id,
                        markArchive = it.markArchive
                    )
                }
                _loadingCatchupEpg.value = false
                _isLoadingEpg.value = false
                return@launch
            }

            // Check SQLite persistent EPG cache
            val dbCachedJson = withContext(Dispatchers.IO) { repository.getEpgCache(cacheKey) }
            if (!dbCachedJson.isNullOrEmpty()) {
                val dbItems = deserializeEpgItems(dbCachedJson)
                if (dbItems.isNotEmpty()) {
                    epgCache[cacheKey] = Pair(now, dbItems)
                    _epgProgramsList.value = dbItems
                    _catchupEpg.value = dbItems.map {
                        EpgProgram(
                            title = it.name,
                            startTime = it.startTimeFormatted,
                            endTime = it.stopTimeFormatted,
                            description = it.description,
                            startHour = 0,
                            endHour = 0,
                            startTimestamp = it.startTimestamp,
                            endTimestamp = it.stopTimestamp,
                            realId = it.realId,
                            id = it.id,
                            markArchive = it.markArchive
                        )
                    }
                    if (!forceRefresh) {
                        _loadingCatchupEpg.value = false
                        _isLoadingEpg.value = false
                        return@launch
                    }
                }
            }

            if (!forceRefresh && _epgProgramsList.value.isEmpty()) {
                _epgProgramsList.value = emptyList()
                _catchupEpg.value = emptyList()
            }
            try {
                val playlist = repository.getPlaylistById(channel.playlistId)
                val isStalker = playlist != null && playlist.type.equals("Stalker", ignoreCase = true)
                val streamUrl = channel.streamUrl
                val xtreamRegex = Regex(".*/live/([^/]+)/([^/]+)/([0-9]+)(\\.[a-zA-Z0-9]+)?")
                val xtreamMatch = xtreamRegex.matchEntire(streamUrl) ?: Regex(".*/live/([^/]+)/([^/]+)/([0-9]+)").matchEntire(streamUrl)
                val isXtream = (playlist != null && playlist.type.equals("Xtream", ignoreCase = true)) || xtreamMatch != null

                var items: List<EpgProgramItem> = emptyList()

                if (isStalker && playlist != null) {
                    val mac = playlist.macAddress ?: ""
                    val handshake = apiService.performHandshake(playlist.url, mac)
                    val token = handshake.token
                    val stalkerId = channel.stalkerId.ifEmpty {
                        channel.streamUrl.substringAfterLast("/").substringBefore(".")
                    }
                    val hours = if (channel.catchupDurationDays > 0) channel.catchupDurationDays * 24 else if (channel.tvArchiveDuration > 0) channel.tvArchiveDuration else 72
                    
                    val archivePrograms = try {
                        stalkerRepository.getArchiveEpg(channel.playlistId, stalkerId, hours)
                    } catch (e: Exception) {
                        emptyList()
                    }
                    val archiveItems = archivePrograms.map { prog ->
                        EpgProgramItem(
                            id = prog.id.ifEmpty { prog.realId.ifEmpty { "${prog.startTimestamp}" } },
                            chId = stalkerId,
                            name = prog.title,
                            description = prog.description,
                            startTimestamp = prog.startTimestamp,
                            stopTimestamp = prog.endTimestamp,
                            startTimeFormatted = prog.startTime,
                            stopTimeFormatted = prog.endTime,
                            realId = prog.realId,
                            markArchive = 1
                        )
                    }

                    val shortItems = try {
                        apiService.fetchShortEpg(
                            portalUrl = playlist.url,
                            mac = mac,
                            token = token,
                            channelId = stalkerId,
                            hoursBack = hours
                        )
                    } catch (e: Exception) {
                        emptyList()
                    }

                    val map = java.util.LinkedHashMap<Long, EpgProgramItem>()
                    for (item in shortItems) {
                        map[item.startTimestamp] = item
                    }
                    for (item in archiveItems) {
                        val existing = map[item.startTimestamp]
                        if (existing == null || existing.markArchive == 0) {
                            map[item.startTimestamp] = item
                        }
                    }
                    items = map.values.sortedBy { it.startTimestamp }
                } else if (isXtream) {
                    val username = xtreamMatch?.groupValues?.getOrNull(1) ?: playlist?.username ?: ""
                    val password = xtreamMatch?.groupValues?.getOrNull(2) ?: playlist?.password ?: ""
                    val streamId = xtreamMatch?.groupValues?.getOrNull(3) ?: channel.stalkerId.ifEmpty {
                        streamUrl.substringAfterLast("/").substringBefore(".")
                    }
                    val baseUrl = if (xtreamMatch != null) streamUrl.substringBefore("/live/") else (playlist?.url ?: "")
                    val hours = if (channel.catchupDurationDays > 0) channel.catchupDurationDays * 24 else if (channel.tvArchiveDuration > 0) channel.tvArchiveDuration else 72

                    if (username.isNotEmpty() && password.isNotEmpty() && streamId.isNotEmpty() && baseUrl.isNotEmpty()) {
                        Log.d("IptvViewModel", "Loading Xtream EPG for streamId=$streamId from baseUrl=$baseUrl")
                        items = apiService.fetchXtreamEpg(
                            baseUrl = baseUrl,
                            username = username,
                            password = password,
                            streamId = streamId,
                            hoursBack = hours
                        )
                    }
                }

                if (items.isNotEmpty()) {
                    epgCache[cacheKey] = Pair(System.currentTimeMillis(), items)
                    withContext(Dispatchers.IO) {
                        val json = serializeEpgItems(items)
                        if (json.isNotEmpty()) {
                            repository.saveEpgCache(cacheKey, json, "")
                        }
                    }
                    _epgProgramsList.value = items
                    _catchupEpg.value = items.map {
                        EpgProgram(
                            title = it.name,
                            startTime = it.startTimeFormatted,
                            endTime = it.stopTimeFormatted,
                            description = it.description,
                            startHour = 0,
                            endHour = 0,
                            startTimestamp = it.startTimestamp,
                            endTimestamp = it.stopTimestamp,
                            realId = it.realId,
                            id = it.id,
                            markArchive = it.markArchive
                        )
                    }
                } else {
                    Log.d("IptvViewModel", "No server EPG returned for ${channel.name}, will use clean fallback.")
                }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                Log.e("IptvViewModel", "Failed to load catchup EPG: ${e.message}", e)
                _catchupError.value = "Erreur de chargement EPG: ${e.message}"
            } finally {
                _loadingCatchupEpg.value = false
                _isLoadingEpg.value = false
            }
        }
    }

    fun loadEpgForDate(channel: ChannelItem, date: String, forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _loadingCatchupEpg.value = true
            _catchupError.value = null
            val stalkerId = channel.stalkerId.ifEmpty {
                channel.streamUrl.substringAfterLast("/").substringBefore(".")
            }
            val cacheKey = "${channel.playlistId}_${stalkerId}_$date"
            val now = System.currentTimeMillis()
            val cached = epgDateCache[cacheKey]
            if (!forceRefresh && cached != null && (now - cached.first) < 10 * 60 * 1000L) {
                _catchupEpg.value = cached.second
                _loadingCatchupEpg.value = false
                return@launch
            }

            try {
                val playlist = repository.getPlaylistById(channel.playlistId)
                val isStalker = playlist != null && playlist.type.equals("Stalker", ignoreCase = true)
                val streamUrl = channel.streamUrl
                val xtreamRegex = Regex(".*/live/([^/]+)/([^/]+)/([0-9]+)(\\.[a-zA-Z0-9]+)?")
                val xtreamMatch = xtreamRegex.matchEntire(streamUrl) ?: Regex(".*/live/([^/]+)/([^/]+)/([0-9]+)").matchEntire(streamUrl)
                val isXtream = (playlist != null && playlist.type.equals("Xtream", ignoreCase = true)) || xtreamMatch != null

                var programsList: List<EpgProgram> = emptyList()

                if (isStalker && playlist != null) {
                    val mac = playlist.macAddress ?: ""
                    val handshake = apiService.performHandshake(playlist.url, mac)
                    val token = handshake.token
                    
                    val items = apiService.fetchEpgForDate(
                        portalUrl = playlist.url,
                        mac = mac,
                        token = token,
                        channelId = stalkerId,
                        date = date
                    )
                    programsList = items.map { item ->
                        EpgProgram(
                            title = item.name,
                            startTime = item.startTimeFormatted,
                            endTime = item.stopTimeFormatted,
                            description = item.description,
                            startHour = 0,
                            endHour = 0,
                            startTimestamp = item.startTimestamp,
                            endTimestamp = item.stopTimestamp,
                            realId = item.realId,
                            id = item.id,
                            markArchive = item.markArchive
                        )
                    }
                } else if (isXtream) {
                    val username = xtreamMatch?.groupValues?.getOrNull(1) ?: playlist?.username ?: ""
                    val password = xtreamMatch?.groupValues?.getOrNull(2) ?: playlist?.password ?: ""
                    val streamId = xtreamMatch?.groupValues?.getOrNull(3) ?: stalkerId
                    val baseUrl = if (xtreamMatch != null) streamUrl.substringBefore("/live/") else (playlist?.url ?: "")
                    val hours = if (channel.catchupDurationDays > 0) channel.catchupDurationDays * 24 else if (channel.tvArchiveDuration > 0) channel.tvArchiveDuration else 72

                    if (username.isNotEmpty() && password.isNotEmpty() && streamId.isNotEmpty() && baseUrl.isNotEmpty()) {
                        val items = apiService.fetchXtreamEpg(
                            baseUrl = baseUrl,
                            username = username,
                            password = password,
                            streamId = streamId,
                            hoursBack = hours
                        )
                        val sdfDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                        programsList = items.filter { item ->
                            val itemDate = sdfDate.format(java.util.Date(item.startTimestamp))
                            itemDate == date
                        }.map { item ->
                            EpgProgram(
                                title = item.name,
                                startTime = item.startTimeFormatted,
                                endTime = item.stopTimeFormatted,
                                description = item.description,
                                startHour = 0,
                                endHour = 0,
                                startTimestamp = item.startTimestamp,
                                endTimestamp = item.stopTimestamp,
                                realId = item.realId,
                                id = item.id,
                                markArchive = item.markArchive
                            )
                        }
                    }
                }

                if (programsList.isEmpty()) {
                    val fallbackList = getAutomaticEpgForChannel(channel.name)
                    programsList = fallbackList
                }

                val sortedList = programsList.sortedBy { it.startTimestamp }
                if (sortedList.isNotEmpty()) {
                    epgDateCache[cacheKey] = Pair(System.currentTimeMillis(), sortedList)
                }
                _catchupEpg.value = sortedList
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Failed to load EPG for date $date: ${e.message}", e)
                _catchupError.value = "Erreur EPG ($date): ${e.message}"
                _catchupEpg.value = emptyList()
            } finally {
                _loadingCatchupEpg.value = false
            }
        }
    }

    fun playCatchupProgram(channel: ChannelItem, program: EpgProgramItem) {
        _isTimeshiftActive.value = true
        _currentTimeshiftProgram.value = EpgProgram(
            title = program.name,
            startTime = program.startTimeFormatted,
            endTime = program.stopTimeFormatted,
            description = program.description,
            startHour = 0,
            endHour = 0,
            startTimestamp = program.startTimestamp,
            endTimestamp = program.stopTimestamp,
            realId = program.realId,
            id = program.id,
            markArchive = program.markArchive
        )

        _playbackUrl.value = null
        _playbackHeaders.value = emptyMap()
        _playbackLoading.value = true
        _isPlaying.value = true
        _playbackError.value = null
        _catchupError.value = null

        sharedExoPlayer?.let { player ->
            try {
                player.pause()
                player.stop()
                player.clearMediaItems()
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error stopping live player before catchup: ${e.message}")
            }
        }

        viewModelScope.launch {
            try {
                delay(600) // Allow server to release live stream connection
                val playlist = repository.getPlaylistById(channel.playlistId)
                if (playlist != null && playlist.type.equals("Stalker", ignoreCase = true)) {
                    val mac = playlist.macAddress ?: ""
                    val handshake = apiService.performHandshake(playlist.url, mac)
                    val token = handshake.token
                    val usedMac = handshake.usedMac

                    val devFields = generateStalkerDeviceFields(usedMac)
                    val devId = devFields["device_id"] ?: ""
                    var devId2 = devFields["device_id2"] ?: ""
                    if (playlist.url.contains("deirnet.ps", ignoreCase = true)) {
                        devId2 = ""
                    }
                    val sig = devFields["signature"] ?: ""
                    val serial = devFields["serial_number"] ?: ""

                    val headers = mapOf(
                        "User-Agent" to "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
                        "X-User-Agent" to "Model: MAG250; Link: WiFi",
                        "X-User-Card" to "mac=$usedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial",
                        "Cookie" to "mac=$usedMac; stb_lang=en; timezone=Europe/Paris; token=$token",
                        "Referer" to if (playlist.url.endsWith("/")) playlist.url else "${playlist.url}/",
                        "Accept" to "*/*",
                        "Authorization" to "Bearer $token"
                    )

                    var resolvedCatchup: String? = null
                    try {
                        val archiveUrl = stalkerRepository.resolveStalkerPlayLinkForArchive(
                            playlistId = playlist.id,
                            cmd = channel.streamUrl,
                            startTimestamp = program.startTimestamp,
                            stopTimestamp = program.stopTimestamp,
                            programId = program.id.ifEmpty { program.realId },
                            channelStalkerId = channel.stalkerId.ifEmpty { channel.streamUrl.substringAfterLast("/").substringBefore(".").replace(Regex("[^0-9]"), "") }
                        )
                        // IMPORTANT : ne jamais accepter une chaîne vide, ni un lien identique au direct
                        if (archiveUrl.isNotEmpty() && archiveUrl != channel.streamUrl) {
                            resolvedCatchup = archiveUrl
                            Log.d("CatchupDebug", "Play link résolu via resolveStalkerPlayLinkForArchive: $resolvedCatchup")
                        } else {
                            Log.w("CatchupDebug", "resolveStalkerPlayLinkForArchive n'a rien retourné de valide, passage à resolveCatchupStream")
                        }
                    } catch (e: Exception) {
                        Log.e("CatchupDebug", "Erreur resolveStalkerPlayLinkForArchive: ${e.message}")
                    }

                    if (resolvedCatchup == null) {
                        try {
                            resolvedCatchup = apiService.resolveCatchupStream(
                                portalUrl = playlist.url,
                                mac = usedMac,
                                cmd = channel.streamUrl,
                                programStartTimestamp = program.startTimestamp,
                                programStopTimestamp = program.stopTimestamp,
                                realId = program.realId
                            )
                        } catch (e: Exception) {
                            Log.w("CatchupDebug", "apiService.resolveCatchupStream threw: ${e.message}")
                        }
                    }

                    if (resolvedCatchup == null && program.startTimestamp > 0L) {
                        Log.d("CatchupDebug", "resolveCatchupStream a renvoyé null, tentative de fallback avec URL directe archive...")
                        val archiveSec = if (program.startTimestamp > 100000000000L) program.startTimestamp / 1000L else program.startTimestamp
                        val durMin = if (program.stopTimestamp > program.startTimestamp) {
                            ((program.stopTimestamp - program.startTimestamp) / 60000L).toInt().coerceAtLeast(1)
                        } else 60
                        var cleanStreamUrl = channel.streamUrl.trim().removePrefix("ffrt ").removePrefix("ffmpeg ").removePrefix("auto ").removePrefix("standalone ").trim()
                        if (cleanStreamUrl.startsWith("http://") || cleanStreamUrl.startsWith("https://")) {
                            val sep = if (cleanStreamUrl.contains("?")) "&" else "?"
                            resolvedCatchup = "$cleanStreamUrl${sep}archive=$archiveSec&duration=$durMin"
                        } else {
                            val endpointPath = handshake.endpointPath
                            val cleanBaseUrl = if (playlist.url.endsWith("/")) playlist.url else "${playlist.url}/"
                            val timeshiftSec = ((System.currentTimeMillis() - program.startTimestamp) / 1000L).coerceAtLeast(60L)
                            val encodedCmd = java.net.URLEncoder.encode(channel.streamUrl, "UTF-8")
                            val timeshiftUrl = "${cleanBaseUrl}${endpointPath}?type=itv&action=create_link&cmd=$encodedCmd&timeshift=$timeshiftSec&token=$token"
                            resolvedCatchup = apiService.resolveStalkerStream(playlist.url, usedMac, timeshiftUrl, "Live")
                        }
                    }

                    if (resolvedCatchup != null && stalkerRepository.looksLikeLiveNotArchive(resolvedCatchup, channel.streamUrl)) {
                        Log.w("IptvViewModel", "resolvedCatchup ($resolvedCatchup) rejected because it looks like live stream, not archive.")
                        resolvedCatchup = null
                    }

                    if (resolvedCatchup == null && program.startTimestamp > 0L) {
                        try {
                            val archiveSec = if (program.startTimestamp > 100000000000L) program.startTimestamp / 1000L else program.startTimestamp
                            val durMin = if (program.stopTimestamp > program.startTimestamp) {
                                ((program.stopTimestamp - program.startTimestamp) / 60000L).toInt().coerceAtLeast(1)
                            } else 60
                            val liveResolved = apiService.resolveStalkerStream(
                                playlist.url, usedMac,
                                "type=itv&action=create_link&cmd=${java.net.URLEncoder.encode(channel.streamUrl, "UTF-8")}&forced_storage=0&disable_ad=0&JsHttpRequest=1-xml",
                                "Live"
                            )
                            if (!liveResolved.isNullOrEmpty() && (liveResolved.startsWith("http://") || liveResolved.startsWith("https://"))) {
                                val sep = if (liveResolved.contains("?")) "&" else "?"
                                resolvedCatchup = "$liveResolved${sep}archive=$archiveSec&duration=$durMin"
                                Log.d("CatchupDebug", "[Ultimate Catchup Fallback] URL générée : $resolvedCatchup")
                            }
                        } catch (e: Exception) {
                            Log.e("CatchupDebug", "Erreur Ultimate Catchup Fallback: ${e.message}")
                        }
                    }

                    if (resolvedCatchup != null) {
                        _playbackUrl.value = com.example.data.resolveRedirects(resolvedCatchup, headers)
                        _playbackHeaders.value = headers
                        _catchupError.value = null
                        _playbackError.value = null
                    } else {
                        _isTimeshiftActive.value = true
                        _playbackUrl.value = null
                        _catchupError.value = "Ce programme n'est plus disponible en archive sur ce portail"
                        _playbackError.value = "Ce programme n'est plus disponible en archive sur ce portail"
                        _playbackLoading.value = false
                    }
                } else {
                    val streamUrl = channel.streamUrl
                    val regex = Regex(".*/live/([^/]+)/([^/]+)/([0-9]+)(\\.[a-zA-Z0-9]+)?")
                    val match = regex.matchEntire(streamUrl) ?: Regex(".*/live/([^/]+)/([^/]+)/([0-9]+)").matchEntire(streamUrl)
                    if (match != null) {
                        val username = match.groupValues[1]
                        val password = match.groupValues[2]
                        val streamId = match.groupValues[3]
                        val extension = if (match.groupValues.size > 4 && match.groupValues[4].isNotEmpty()) match.groupValues[4] else ".ts"
                        val baseUrl = streamUrl.substringBefore("/live/")
                        
                        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
                            timeInMillis = if (program.startTimestamp > 0L) program.startTimestamp else System.currentTimeMillis() - 3600000L
                        }
                        val year = cal.get(java.util.Calendar.YEAR)
                        val month = String.format("%02d", cal.get(java.util.Calendar.MONTH) + 1)
                        val day = String.format("%02d", cal.get(java.util.Calendar.DAY_OF_MONTH))
                        val hour = String.format("%02d", cal.get(java.util.Calendar.HOUR_OF_DAY))
                        val min = String.format("%02d", cal.get(java.util.Calendar.MINUTE))
                        val startTimeStr = "$year-$month-$day:$hour-$min"
                        
                        val durMin = if (program.stopTimestamp > program.startTimestamp) {
                            ((program.stopTimestamp - program.startTimestamp) / 60000L).toInt().coerceAtLeast(10)
                        } else 60
                        
                        val timeshiftUrl = "$baseUrl/timeshift/$username/$password/$durMin/$startTimeStr/$streamId$extension"
                        Log.d("IptvViewModel", "Generated Xtream Catchup URL: $timeshiftUrl")
                        val headers = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
                        _playbackUrl.value = com.example.data.resolveRedirects(timeshiftUrl, headers)
                        _playbackHeaders.value = headers
                        _catchupError.value = null
                        _playbackError.value = null
                    } else {
                        _isTimeshiftActive.value = true
                        _playbackUrl.value = null
                        _catchupError.value = "Ce programme n'est pas disponible en replay"
                        _playbackError.value = "Ce programme n'est pas disponible en replay"
                        _playbackLoading.value = false
                    }
                }
            } catch (e: com.example.data.CatchupStreamException) {
                Log.e("IptvViewModel", "Catchup stream error: ${e.message}")
                _isTimeshiftActive.value = true
                _playbackUrl.value = null
                _catchupError.value = e.message
                _playbackError.value = e.message
                _playbackLoading.value = false
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                Log.e("IptvViewModel", "Error playing catchup program: ${e.message}", e)
                val msg = if (e.message?.contains("Limite de connexion") == true) e.message else "Ce programme n'est plus disponible en archive sur ce portail"
                _isTimeshiftActive.value = true
                _playbackUrl.value = null
                _catchupError.value = msg
                _playbackError.value = msg
                _playbackLoading.value = false
            }
        }
    }

    fun playTimeshift(channel: ChannelItem, program: EpgProgram) {
        _isTimeshiftActive.value = true
        _currentTimeshiftProgram.value = program
        
        _playbackUrl.value = null
        _playbackHeaders.value = emptyMap()
        _playbackLoading.value = true
        _isPlaying.value = true
        _playbackError.value = null
        _catchupError.value = null
        
        sharedExoPlayer?.let { player ->
            try {
                player.pause()
                player.stop()
                player.clearMediaItems()
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error stopping live player before timeshift: ${e.message}")
            }
        }

        viewModelScope.launch {
            try {
                val playlist = repository.getPlaylistById(channel.playlistId)
                if (playlist != null && playlist.type.equals("Stalker", ignoreCase = true)) {
                    val mac = playlist.macAddress ?: ""
                    val handshakeResult = apiService.performHandshake(playlist.url, mac)
                    val token = handshakeResult.token
                    val usedMac = handshakeResult.usedMac
                    
                    val cmd = channel.streamUrl
                    val encodedCmd = java.net.URLEncoder.encode(cmd, "UTF-8")
                    val deviceFields = com.example.data.generateStalkerDeviceFields(usedMac)
                    val devId = deviceFields["device_id"] ?: ""
                    val devId2 = deviceFields["device_id2"] ?: ""
                    val sig = deviceFields["signature"] ?: ""
                    val serial = deviceFields["serial_number"] ?: ""
                    
                    val headers = mapOf(
                        "User-Agent" to "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
                        "X-User-Agent" to "Model: MAG250; Link: WiFi",
                        "X-User-Card" to "mac=$usedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial",
                        "Cookie" to "mac=$usedMac; stb_lang=en; timezone=Europe/Paris; token=$token",
                        "Referer" to if (playlist.url.endsWith("/")) playlist.url else "${playlist.url}/",
                        "Accept" to "*/*",
                        "Authorization" to "Bearer $token"
                    )
                    
                    if (program.startTimestamp > 0L) {
                        delay(600)
                        var resolvedCatchup: String? = null
                        try {
                            val archiveUrl = stalkerRepository.resolveStalkerPlayLinkForArchive(
                                playlistId = playlist.id,
                                cmd = channel.streamUrl,
                                startTimestamp = program.startTimestamp,
                                stopTimestamp = program.endTimestamp,
                                programId = program.id.ifEmpty { program.realId },
                                channelStalkerId = channel.stalkerId.ifEmpty { channel.streamUrl.substringAfterLast("/").substringBefore(".") }
                            )
                            if (archiveUrl.isNotEmpty() && archiveUrl != channel.streamUrl) {
                                resolvedCatchup = archiveUrl
                                Log.d("CatchupDebug", "Timeshift play link résolu via resolveStalkerPlayLinkForArchive: $resolvedCatchup")
                            }
                        } catch (e: Exception) {
                            Log.e("CatchupDebug", "Erreur resolveStalkerPlayLinkForArchive in playTimeshift: ${e.message}")
                        }

                        if (resolvedCatchup == null) {
                            try {
                                resolvedCatchup = apiService.resolveCatchupStream(
                                    portalUrl = playlist.url,
                                    mac = usedMac,
                                    cmd = channel.streamUrl,
                                    programStartTimestamp = program.startTimestamp,
                                    programStopTimestamp = program.endTimestamp,
                                    realId = program.realId
                                )
                            } catch (e: Exception) {
                                Log.w("CatchupDebug", "apiService.resolveCatchupStream in playTimeshift threw: ${e.message}")
                            }
                        }
                        if (resolvedCatchup == null) {
                            Log.d("CatchupDebug", "resolveCatchupStream in playTimeshift a renvoyé null, tentative de fallback avec URL directe archive...")
                            val archiveSec = if (program.startTimestamp > 100000000000L) program.startTimestamp / 1000L else program.startTimestamp
                            val stopSec = if (program.endTimestamp > 100000000000L) program.endTimestamp / 1000L else program.endTimestamp
                            val durMin = if (stopSec > archiveSec) ((stopSec - archiveSec) / 60L).toInt().coerceAtLeast(1) else 60
                            var cleanStreamUrl = channel.streamUrl.trim().removePrefix("ffrt ").removePrefix("ffmpeg ").removePrefix("auto ").removePrefix("standalone ").trim()
                            if (cleanStreamUrl.startsWith("http://") || cleanStreamUrl.startsWith("https://")) {
                                val sep = if (cleanStreamUrl.contains("?")) "&" else "?"
                                resolvedCatchup = "$cleanStreamUrl${sep}archive=$archiveSec&duration=$durMin"
                            } else {
                                val endpointPath = handshakeResult.endpointPath
                                val cleanBaseUrl = if (playlist.url.endsWith("/")) playlist.url else "${playlist.url}/"
                                val timeshiftSec = ((System.currentTimeMillis() - program.startTimestamp) / 1000L).coerceAtLeast(60L)
                                val timeshiftUrl = "${cleanBaseUrl}${endpointPath}?type=itv&action=create_link&cmd=$encodedCmd&timeshift=$timeshiftSec&token=$token"
                                resolvedCatchup = apiService.resolveStalkerStream(playlist.url, usedMac, timeshiftUrl, "Live")
                            }
                        }
                        if (resolvedCatchup == null && program.startTimestamp > 0L) {
                            try {
                                val archiveSec = if (program.startTimestamp > 100000000000L) program.startTimestamp / 1000L else program.startTimestamp
                                val durMin = if (program.endTimestamp > program.startTimestamp) {
                                    ((program.endTimestamp - program.startTimestamp) / 60000L).toInt().coerceAtLeast(1)
                                } else 60
                                val liveResolved = apiService.resolveStalkerStream(
                                    playlist.url, usedMac,
                                    "type=itv&action=create_link&cmd=${java.net.URLEncoder.encode(channel.streamUrl, "UTF-8")}&forced_storage=0&disable_ad=0&JsHttpRequest=1-xml",
                                    "Live"
                                )
                                if (!liveResolved.isNullOrEmpty() && (liveResolved.startsWith("http://") || liveResolved.startsWith("https://"))) {
                                    val sep = if (liveResolved.contains("?")) "&" else "?"
                                    resolvedCatchup = "$liveResolved${sep}archive=$archiveSec&duration=$durMin"
                                    Log.d("CatchupDebug", "[Ultimate Catchup Fallback timeshift] URL générée : $resolvedCatchup")
                                }
                            } catch (e: Exception) {
                                Log.e("CatchupDebug", "Erreur Ultimate Catchup Fallback timeshift: ${e.message}")
                            }
                        }
                        if (resolvedCatchup != null) {
                            _playbackUrl.value = com.example.data.resolveRedirects(resolvedCatchup, headers)
                            _playbackHeaders.value = headers
                            _catchupError.value = null
                            _playbackError.value = null
                        } else {
                            _isTimeshiftActive.value = true
                            _playbackUrl.value = null
                            _catchupError.value = "Ce programme n'est plus disponible en archive sur ce portail"
                            _playbackError.value = "Ce programme n'est plus disponible en archive sur ce portail"
                            _playbackLoading.value = false
                        }
                        return@launch
                    }

                    delay(400) // Anti-ban rate limiting delay
                    
                    val endpointPath = handshakeResult.endpointPath
                    val cleanBaseUrl = if (playlist.url.endsWith("/")) playlist.url else "${playlist.url}/"

                    val timeshiftSec = if (program.startTimestamp > 0L) {
                        ((System.currentTimeMillis() - program.startTimestamp) / 1000L).coerceAtLeast(3600L)
                    } else {
                        val currentHour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                        val hourDiff = currentHour - program.startHour
                        if (hourDiff > 0) (hourDiff * 3600).toLong() else 3600L
                    }
                    val timeshiftUrl = "${cleanBaseUrl}${endpointPath}?type=itv&action=create_link&cmd=$encodedCmd&timeshift=$timeshiftSec&token=$token"
                    var resolved: String? = apiService.resolveStalkerStream(playlist.url, usedMac, timeshiftUrl, "Live")
                    if (resolved != null) {
                        _playbackUrl.value = com.example.data.resolveRedirects(resolved, headers)
                        _playbackHeaders.value = headers
                        _catchupError.value = null
                        _playbackError.value = null
                    } else {
                        _isTimeshiftActive.value = true
                        _playbackUrl.value = null
                        _catchupError.value = "Ce programme n'est plus disponible en archive sur ce portail"
                        _playbackError.value = "Ce programme n'est plus disponible en archive sur ce portail"
                        _playbackLoading.value = false
                    }
                } else {
                    // Check if channel URL matches Xtream live format
                    val streamUrl = channel.streamUrl
                    val regex = Regex(".*/live/([^/]+)/([^/]+)/([0-9]+)(\\.[a-zA-Z0-9]+)?")
                    val match = regex.matchEntire(streamUrl) ?: Regex(".*/live/([^/]+)/([^/]+)/([0-9]+)").matchEntire(streamUrl)
                    
                    if (match != null) {
                        val username = match.groupValues[1]
                        val password = match.groupValues[2]
                        val streamId = match.groupValues[3]
                        val extension = if (match.groupValues.size > 4 && match.groupValues[4].isNotEmpty()) match.groupValues[4] else ".ts"
                        
                        val baseUrl = streamUrl.substringBefore("/live/")
                        
                        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
                            timeInMillis = if (program.startTimestamp > 0L) program.startTimestamp else System.currentTimeMillis() - 3600000L
                        }
                        val year = cal.get(java.util.Calendar.YEAR)
                        val month = String.format("%02d", cal.get(java.util.Calendar.MONTH) + 1)
                        val day = String.format("%02d", cal.get(java.util.Calendar.DAY_OF_MONTH))
                        val hour = String.format("%02d", cal.get(java.util.Calendar.HOUR_OF_DAY))
                        val min = String.format("%02d", cal.get(java.util.Calendar.MINUTE))
                        val startTimeStr = "$year-$month-$day:$hour-$min"
                        
                        val durMin = if (program.endTimestamp > program.startTimestamp) {
                            ((program.endTimestamp - program.startTimestamp) / 60000L).toInt().coerceAtLeast(10)
                        } else if (program.endHour > program.startHour) {
                            (program.endHour - program.startHour) * 60
                        } else 60
                        
                        val timeshiftUrl = "$baseUrl/timeshift/$username/$password/$durMin/$startTimeStr/$streamId$extension"
                        Log.d("IptvViewModel", "Generated Xtream Timeshift URL: $timeshiftUrl")
                        
                        val headers = mapOf(
                            "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
                        )
                        _playbackUrl.value = com.example.data.resolveRedirects(timeshiftUrl, headers)
                        _playbackHeaders.value = headers
                        _catchupError.value = null
                        _playbackError.value = null
                    } else {
                        _isTimeshiftActive.value = true
                        _playbackUrl.value = null
                        _catchupError.value = "Ce programme n'est pas disponible en replay"
                        _playbackError.value = "Ce programme n'est pas disponible en replay"
                        _playbackLoading.value = false
                    }
                }
            } catch (e: com.example.data.CatchupStreamException) {
                Log.e("IptvViewModel", "Timeshift catchup error: ${e.message}")
                _isTimeshiftActive.value = true
                _playbackUrl.value = null
                _catchupError.value = e.message
                _playbackError.value = e.message
                _playbackLoading.value = false
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                Log.e("IptvViewModel", "Timeshift play error: ${e.message}", e)
                val msg = if (e.message?.contains("Limite de connexion") == true) e.message else "Ce programme n'est plus disponible en archive sur ce portail"
                _isTimeshiftActive.value = true
                _playbackUrl.value = null
                _catchupError.value = msg
                _playbackError.value = msg
                _playbackLoading.value = false
            } finally {
                _playbackLoading.value = false
            }
        }
    }

    fun stopTimeshift() {
        _isTimeshiftActive.value = false
        _currentTimeshiftProgram.value = null
        val channel = _selectedChannel.value
        if (channel != null) {
            selectChannel(channel)
        }
    }

    suspend fun resolveChannelPlayback(channel: ChannelItem): PlaybackInfo = withContext(Dispatchers.IO) {
        if (channel.streamUrl.startsWith("content://") || channel.streamUrl.startsWith("file://") || channel.type == "Recording") {
            return@withContext PlaybackInfo(
                url = channel.streamUrl,
                headers = emptyMap()
            )
        }
        val playlist = try {
            repository.getPlaylistById(channel.playlistId)
        } catch (e: Exception) {
            null
        }
        try {
            if (playlist != null) {
                if (playlist.type.equals("Stalker", ignoreCase = true)) {
                    val mac = playlist.macAddress ?: ""
                    val handshakeResult = apiService.performHandshake(playlist.url, mac)
                    val token = handshakeResult.token
                    val usedMac = handshakeResult.usedMac
                    val resolved = if (channel.streamUrl.startsWith("stalker://episode/")) {
                        val episodeId = channel.streamUrl.substringAfter("stalker://episode/").substringBefore("?")
                        val uri = android.net.Uri.parse(channel.streamUrl)
                        val cmd = uri.getQueryParameter("cmd") ?: ""
                        val seriesId = uri.getQueryParameter("series") ?: ""
                        val seasonId = uri.getQueryParameter("season") ?: ""
                        val seriesRepo = com.example.data.SeriesRepository(getApplication(), apiService, playlist.id)
                        val dummyEpisode = com.example.data.Episode(
                            id = episodeId,
                            seasonId = seasonId,
                            seriesId = seriesId,
                            episodeNumber = 1,
                            name = channel.name,
                            cmd = cmd,
                            isPlayable = false
                        )
                        seriesRepo.playEpisode(dummyEpisode)
                    } else {
                        apiService.resolveStalkerStream(playlist.url, usedMac, channel.streamUrl, channel.type) ?: ""
                    }
                    val deviceFields = com.example.data.generateStalkerDeviceFields(usedMac)
                    val devId = deviceFields["device_id"] ?: ""
                    val devId2 = deviceFields["device_id2"] ?: ""
                    val sig = deviceFields["signature"] ?: ""
                    val serial = deviceFields["serial_number"] ?: ""
                    
                    val stalkerHeaders = mapOf(
                        "User-Agent" to "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
                        "X-User-Agent" to "Model: MAG250; Link: WiFi",
                        "X-User-Card" to "mac=$usedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial",
                        "Cookie" to "mac=$usedMac; stb_lang=en; timezone=Europe/Paris; token=$token",
                        "Referer" to if (playlist.url.endsWith("/")) playlist.url else "${playlist.url}/",
                        "Accept" to "*/*",
                        "Authorization" to "Bearer $token"
                    )

                    if (resolved.isNotEmpty()) {
                        val isDeirnetPs = playlist.url.contains("deirnet.ps", ignoreCase = true) || resolved.contains("deirnet.ps", ignoreCase = true)
                        val isDeirnetVOD = isDeirnetPs && (resolved.contains("/vodnew/") || resolved.contains("file_") || resolved.endsWith(".mpg"))
                        val effectiveHeaders = if (isDeirnetVOD) {
                            Log.d("VodPlaybackDebug", "[ÉTAPE 5] Lecture URL finale ($resolved) SANS headers portail vers le CDN Deirnet — User-Agent='Lavf53.32.100'")
                            mapOf("User-Agent" to "Lavf53.32.100")
                        } else {
                            stalkerHeaders
                        }
                        val finalUrl = com.example.data.resolveRedirects(resolved, effectiveHeaders)
                        return@withContext PlaybackInfo(
                            url = finalUrl,
                            headers = effectiveHeaders
                        )
                    } else {
                        val fallbackExtracted = channel.streamUrl.replace(Regex("^(ffmpeg|ffrt|ffrt2|auto|standalone)\\s+", RegexOption.IGNORE_CASE), "").trim()
                        if ((fallbackExtracted.startsWith("http://") || fallbackExtracted.startsWith("https://")) && !fallbackExtracted.contains("localhost") && !fallbackExtracted.contains("127.0.0.1")) {
                            val finalUrl = com.example.data.resolveRedirects(fallbackExtracted, stalkerHeaders)
                            return@withContext PlaybackInfo(url = finalUrl, headers = stalkerHeaders)
                        } else if (fallbackExtracted.contains("localhost") || fallbackExtracted.contains("127.0.0.1")) {
                            val rewritten = apiService.rewriteLocalhost(fallbackExtracted, playlist.url)
                            val finalUrl = com.example.data.resolveRedirects(rewritten, stalkerHeaders)
                            return@withContext PlaybackInfo(url = finalUrl, headers = stalkerHeaders)
                        }
                    }
                } else if (playlist.type.equals("Xtream", ignoreCase = true) && channel.streamUrl.startsWith("xtream://series/")) {
                    val seriesId = channel.streamUrl.substringAfter("xtream://series/").trim()
                    val username = playlist.username ?: ""
                    val password = playlist.password ?: ""
                    val cleanBase = if (playlist.url.endsWith("/")) playlist.url.substring(0, playlist.url.length - 1) else playlist.url
                    val seriesInfoUrl = "$cleanBase/player_api.php?username=$username&password=$password&action=get_series_info&series_id=$seriesId"
                    val request = Request.Builder().url(seriesInfoUrl).build()
                    okHttpClient.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val body = response.body?.string() ?: ""
                            val jsonObj = try { JSONObject(body) } catch (e: Exception) { null }
                            if (jsonObj != null) {
                                val episodesObj = jsonObj.optJSONObject("episodes")
                                if (episodesObj != null) {
                                    val keys = episodesObj.keys()
                                    if (keys.hasNext()) {
                                        val seasonKey = keys.next()
                                        val seasonArray = episodesObj.optJSONArray(seasonKey)
                                        if (seasonArray != null && seasonArray.length() > 0) {
                                            val firstEpisode = seasonArray.optJSONObject(0) ?: return@withContext PlaybackInfo(url = "", headers = emptyMap())
                                            val episodeId = listOf("id", "episode_id", "stream_id")
                                                .map { key -> firstEpisode.opt(key)?.toString() ?: "" }
                                                .firstOrNull { it.isNotEmpty() && it != "null" }
                                                ?: ""
                                            val ext = listOf("container_extension", "extension", "format")
                                                .map { key -> firstEpisode.opt(key)?.toString() ?: "" }
                                                .firstOrNull { it.isNotEmpty() && it != "null" }
                                                ?.replace(".", "")
                                                ?: "mp4"
                                            val realUrl = "$cleanBase/series/$username/$password/$episodeId.$ext"
                                            val headers = mapOf(
                                                "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
                                            )
                                            val finalUrl = com.example.data.resolveRedirects(realUrl, headers)
                                            return@withContext PlaybackInfo(
                                                url = finalUrl,
                                                headers = headers
                                            )
                                        }
                                    }
                                } else {
                                    val episodesArray = jsonObj.optJSONArray("episodes")
                                    if (episodesArray != null && episodesArray.length() > 0) {
                                        val firstEpisode = episodesArray.optJSONObject(0) ?: return@withContext PlaybackInfo(url = "", headers = emptyMap())
                                        val episodeId = listOf("id", "episode_id", "stream_id")
                                            .map { key -> firstEpisode.opt(key)?.toString() ?: "" }
                                            .firstOrNull { it.isNotEmpty() && it != "null" }
                                            ?: ""
                                        val ext = listOf("container_extension", "extension", "format")
                                            .map { key -> firstEpisode.opt(key)?.toString() ?: "" }
                                            .firstOrNull { it.isNotEmpty() && it != "null" }
                                            ?.replace(".", "")
                                            ?: "mp4"
                                        val realUrl = "$cleanBase/series/$username/$password/$episodeId.$ext"
                                        val headers = mapOf(
                                            "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
                                        )
                                        val finalUrl = com.example.data.resolveRedirects(realUrl, headers)
                                        return@withContext PlaybackInfo(
                                            url = finalUrl,
                                            headers = headers
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("IptvViewModel", "Error resolving channel: ${e.message}", e)
        }
        // Default fallback with a general IPTV User-Agent
        val headers = mapOf(
            "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        )
        val cleanDirectUrl = channel.streamUrl.replace(Regex("^(ffmpeg|ffrt|ffrt2|auto|standalone)\\s+", RegexOption.IGNORE_CASE), "").trim()
        val finalTargetUrl = if (cleanDirectUrl.contains("localhost") || cleanDirectUrl.contains("127.0.0.1")) {
            playlist?.let { apiService.rewriteLocalhost(cleanDirectUrl, it.url) } ?: cleanDirectUrl
        } else {
            cleanDirectUrl
        }
        val finalUrl = com.example.data.resolveRedirects(finalTargetUrl, headers)
        return@withContext PlaybackInfo(
            url = finalUrl,
            headers = headers
        )
    }

    private var playbackResolutionJob: kotlinx.coroutines.Job? = null

    private fun resolvePlayback(channel: ChannelItem) {
        if (_playbackUrl.value != null && _selectedChannel.value?.streamUrl == channel.streamUrl) {
            return
        }
        playbackResolutionJob?.cancel()
        playbackResolutionJob = viewModelScope.launch {
            _playbackLoading.value = true
            _playbackError.value = null
            _playbackUrl.value = null
            _playbackHeaders.value = emptyMap()
            try {
                val playbackInfo = resolveChannelPlayback(channel)
                _playbackUrl.value = playbackInfo.url
                _playbackHeaders.value = playbackInfo.headers
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                Log.e("IptvViewModel", "Error resolving playback: ${e.message}", e)
                _playbackError.value = e.localizedMessage
                _playbackUrl.value = null
            } finally {
                _playbackLoading.value = false
            }
        }
    }

    fun playChannelDirectly(name: String, streamUrl: String, playlistId: Long = 0, type: String = "Live", keepFullScreen: Boolean = false) {
        val mockChannel = ChannelItem(
            playlistId = if (playlistId != 0L) playlistId else (_selectedPlaylist.value?.id ?: 0L),
            name = name,
            streamUrl = streamUrl,
            groupName = "Direct Play",
            type = type
        )
        selectChannel(mockChannel, keepFullScreen = keepFullScreen)
    }

    fun playChannelDirectlyPreview(name: String, streamUrl: String, playlistId: Long = 0, type: String = "Live") {
        val mockChannel = ChannelItem(
            playlistId = if (playlistId != 0L) playlistId else (_selectedPlaylist.value?.id ?: 0L),
            name = name,
            streamUrl = streamUrl,
            groupName = "Direct Play",
            type = type
        )
        selectChannelPreview(mockChannel)
    }

    fun isCurrentlyPlayingVideo(): Boolean {
        return _selectedChannel.value != null && _isPlaying.value
    }

    fun setPictureInPictureMode(isInPip: Boolean) {
        _isPipMode.value = isInPip
    }

    fun togglePlayPause() {
        _isPlaying.value = !_isPlaying.value
    }

    fun pausePlayback() {
        _isPlaying.value = false
        sharedExoPlayer?.let { player ->
            try {
                player.pause()
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error pausing sharedExoPlayer: ${e.message}")
            }
        }
    }

    fun stopPlayback() {
        stopWatchProgressTracker()
        _isPlaying.value = false
        _selectedChannel.value = null
        _voiceSubtitleText.value = null
        _translatedVoiceSubtitleText.value = null
        _currentSubtitleText.value = null
        _translatedSubtitleText.value = null
        _nativeSubtitleText.value = null
        _translatedNativeSubtitleText.value = null
        lastRawCueText = null
        lastBitmapHash = null
        lastOcrJob?.cancel()
        lastVoiceTranslationJob?.cancel()
        com.example.data.SherpaSubtitleManager.resetRecognitionState()
        syncSubtitleDisplay()
        sharedExoPlayer?.let { player ->
            try {
                player.pause()
                player.stop()
                player.clearMediaItems()
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error stopping sharedExoPlayer: ${e.message}")
            }
        }
    }

    fun selectNextChannel() {
        val current = _selectedChannel.value ?: return
        val list = _channels.value
        if (list.isEmpty()) return
        val keepFS = _isFullScreen.value

        if (current.type == "Series") {
            val episodes = _seriesEpisodes.value
            if (episodes.isNotEmpty()) {
                val currentIndex = episodes.indexOfFirst { it.url == current.streamUrl }
                if (currentIndex != -1) {
                    val nextIndex = if (currentIndex == episodes.size - 1) 0 else currentIndex + 1
                    val nextEpisode = episodes[nextIndex]
                    playChannelDirectly(nextEpisode.name, nextEpisode.url, playlistId = current.playlistId, type = "Series", keepFullScreen = keepFS)
                    return
                }
            }
        }

        // Filter list to keep only channels of the SAME type as the currently playing one and in the SAME category
        val category = _selectedCategory.value
        val filteredList = list.filter { it.type == current.type }
            .filter { category == "Tous" || category.isEmpty() || it.groupName.equals(category, ignoreCase = true) }
            
        if (filteredList.isEmpty()) return
        
        val currentIndex = filteredList.indexOfFirst { it.streamUrl == current.streamUrl }
        val nextIndex = if (currentIndex == -1 || currentIndex == filteredList.size - 1) 0 else currentIndex + 1
        selectChannel(filteredList[nextIndex], keepFullScreen = keepFS)
    }

    fun selectPreviousChannel() {
        val current = _selectedChannel.value ?: return
        val list = _channels.value
        if (list.isEmpty()) return
        val keepFS = _isFullScreen.value

        if (current.type == "Series") {
            val episodes = _seriesEpisodes.value
            if (episodes.isNotEmpty()) {
                val currentIndex = episodes.indexOfFirst { it.url == current.streamUrl }
                if (currentIndex != -1) {
                    val prevIndex = if (currentIndex == 0) episodes.size - 1 else currentIndex - 1
                    val prevEpisode = episodes[prevIndex]
                    playChannelDirectly(prevEpisode.name, prevEpisode.url, playlistId = current.playlistId, type = "Series", keepFullScreen = keepFS)
                    return
                }
            }
        }

        // Filter list to keep only channels of the SAME type as the currently playing one and in the SAME category
        val category = _selectedCategory.value
        val filteredList = list.filter { it.type == current.type }
            .filter { category == "Tous" || category.isEmpty() || it.groupName.equals(category, ignoreCase = true) }
            
        if (filteredList.isEmpty()) return
        
        val currentIndex = filteredList.indexOfFirst { it.streamUrl == current.streamUrl }
        val prevIndex = if (currentIndex == -1 || currentIndex == 0) filteredList.size - 1 else currentIndex - 1
        selectChannel(filteredList[prevIndex], keepFullScreen = keepFS)
    }

    private fun parseStalkerEpisodes(finalDataObj: JSONObject?, seriesId: String): List<EpisodeItem> {
        val list = mutableListOf<EpisodeItem>()
        if (finalDataObj == null) return list

        val seasonsJsonArray = finalDataObj.optJSONArray("seasons")
        val seasonsJsonObject = finalDataObj.optJSONObject("seasons")

        if (seasonsJsonArray != null && seasonsJsonArray.length() > 0) {
            for (i in 0 until seasonsJsonArray.length()) {
                val seasonObj = seasonsJsonArray.optJSONObject(i) ?: continue
                parseStalkerSeasonObject(seasonObj, seriesId, "${i + 1}", list)
            }
        } else if (seasonsJsonObject != null) {
            val keys = seasonsJsonObject.keys()
            val sortedKeys = mutableListOf<String>()
            while (keys.hasNext()) { sortedKeys.add(keys.next()) }
            sortedKeys.sortedWith(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE }).forEach { key ->
                val seasonObj = seasonsJsonObject.optJSONObject(key)
                if (seasonObj != null) {
                    parseStalkerSeasonObject(seasonObj, seriesId, key, list)
                }
            }
        } else {
            val seriesJsonArray = finalDataObj.optJSONArray("series") ?: finalDataObj.optJSONArray("list")
            val seriesJsonObject = finalDataObj.optJSONObject("series") ?: finalDataObj.optJSONObject("list")

            if (seriesJsonArray != null && seriesJsonArray.length() > 0) {
                for (i in 0 until seriesJsonArray.length()) {
                    val itemObj = seriesJsonArray.optJSONObject(i) ?: continue
                    val episodesArray = itemObj.optJSONArray("episodes") ?: itemObj.optJSONArray("series") ?: itemObj.optJSONArray("list")
                    val episodesObject = itemObj.optJSONObject("episodes") ?: itemObj.optJSONObject("series") ?: itemObj.optJSONObject("list")
                    
                    if (episodesArray != null || episodesObject != null) {
                        val seasonNum = listOf("season_number", "season", "id", "series_number")
                            .map { key -> itemObj.optString(key).trim() }
                            .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${i + 1}"
                        parseStalkerSeasonObject(itemObj, seriesId, seasonNum, list)
                    } else {
                        parseStalkerEpisodeObject(itemObj, seriesId, "1", i, list)
                    }
                }
            } else if (seriesJsonObject != null) {
                val keys = seriesJsonObject.keys()
                val sortedKeys = mutableListOf<String>()
                while (keys.hasNext()) { sortedKeys.add(keys.next()) }
                sortedKeys.sortedWith(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE }).forEachIndexed { i, key ->
                    val itemObj = seriesJsonObject.optJSONObject(key)
                    if (itemObj != null) {
                        val episodesArray = itemObj.optJSONArray("episodes") ?: itemObj.optJSONArray("series") ?: itemObj.optJSONArray("list")
                        val episodesObject = itemObj.optJSONObject("episodes") ?: itemObj.optJSONObject("series") ?: itemObj.optJSONObject("list")
                        
                        if (episodesArray != null || episodesObject != null) {
                            val seasonNum = listOf("season_number", "season", "id", "series_number")
                                .map { k -> itemObj.optString(k).trim() }
                                .firstOrNull { it.isNotEmpty() && it != "null" } ?: key
                            parseStalkerSeasonObject(itemObj, seriesId, seasonNum, list)
                        } else {
                            parseStalkerEpisodeObject(itemObj, seriesId, "1", i, list)
                        }
                    }
                }
            } else {
                val episodesArray = finalDataObj.optJSONArray("episodes")
                val episodesObject = finalDataObj.optJSONObject("episodes")
                if (episodesArray != null) {
                    for (i in 0 until episodesArray.length()) {
                        val epObj = episodesArray.optJSONObject(i) ?: continue
                        parseStalkerEpisodeObject(epObj, seriesId, "1", i, list)
                    }
                } else if (episodesObject != null) {
                    val keys = episodesObject.keys()
                    val sortedKeys = mutableListOf<String>()
                    while (keys.hasNext()) { sortedKeys.add(keys.next()) }
                    sortedKeys.sortedWith(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE }).forEachIndexed { i, key ->
                        val epObj = episodesObject.optJSONObject(key)
                        if (epObj != null) {
                            parseStalkerEpisodeObject(epObj, seriesId, "1", i, list)
                        }
                    }
                }
            }
        }
        if (list.isEmpty()) {
            Log.d("IptvViewModel", "Standard Stalker episode parsing returned empty. Running recursive scanner fallback...")
            recursiveExtractEpisodes(finalDataObj, seriesId, "1", list)
        }
        return list
    }

    private fun recursiveExtractEpisodes(
        obj: Any?, 
        seriesId: String, 
        currentSeason: String, 
        list: MutableList<EpisodeItem>,
        visited: MutableSet<Any> = mutableSetOf()
    ) {
        if (obj == null || !visited.add(obj)) return

        if (obj is JSONObject) {
            val cmd = listOf("cmd", "path", "url", "movie_cmd")
                .map { key -> obj.optString(key).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""

            if (cmd.isNotEmpty()) {
                val rawSeason = listOf("season_number", "season_num", "season", "series_number")
                    .map { key -> obj.optString(key).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: currentSeason
                val cleanedSeason = cleanSeasonNumber(rawSeason)

                val rawEpNum = listOf("episode_number", "episode_num", "series_number", "id", "index")
                    .map { key -> obj.optString(key).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${list.size + 1}"
                val cleanedEpNum = if (rawEpNum.contains(":")) rawEpNum.substringAfter(":") else rawEpNum

                val title = listOf("name", "title", "episode_name")
                    .map { key -> obj.optString(key).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: "Épisode $cleanedEpNum"

                val streamUrl = "stalker://series/$seriesId?cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}&series=$rawEpNum&episode=$cleanedEpNum&season=$rawSeason&season_num=$cleanedSeason"
                val formattedName = formatEpisodeName(cleanedSeason, cleanedEpNum, title)
                val rawDuration = obj.optString("duration").ifEmpty { obj.optString("duration_sec") }.trim()
                val durationStr = if (rawDuration.isNotEmpty() && rawDuration != "0") {
                    if (rawDuration.contains(":")) rawDuration else "${rawDuration.toIntOrNull()?.let { it / 60 } ?: 20} min"
                } else {
                    "${20 + (list.size % 31)} min"
                }

                if (list.none { it.url == streamUrl }) {
                    list.add(EpisodeItem(name = formattedName, url = streamUrl, duration = durationStr, season = cleanedSeason))
                }
                return
            }

            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                var nextSeason = currentSeason
                if (key.lowercase().contains("season") || key.lowercase().contains("saison")) {
                    val maybeSeason = obj.optString(key).trim()
                    if (maybeSeason.isNotEmpty() && maybeSeason.toIntOrNull() != null) {
                        nextSeason = maybeSeason
                    }
                }
                val value = obj.opt(key)
                recursiveExtractEpisodes(value, seriesId, nextSeason, list, visited)
            }
        } else if (obj is JSONArray) {
            for (i in 0 until obj.length()) {
                recursiveExtractEpisodes(obj.opt(i), seriesId, currentSeason, list, visited)
            }
        }
    }

    private fun parseStalkerSeasonObject(seasonObj: JSONObject, seriesId: String, seasonNum: String, list: MutableList<EpisodeItem>) {
        val episodesArray = seasonObj.optJSONArray("episodes") ?: seasonObj.optJSONArray("series") ?: seasonObj.optJSONArray("list")
        val episodesObject = seasonObj.optJSONObject("episodes") ?: seasonObj.optJSONObject("series") ?: seasonObj.optJSONObject("list")

        if (episodesArray != null) {
            for (eIdx in 0 until episodesArray.length()) {
                val epObj = episodesArray.optJSONObject(eIdx) ?: continue
                parseStalkerEpisodeObject(epObj, seriesId, seasonNum, eIdx, list)
            }
        } else if (episodesObject != null) {
            val keys = episodesObject.keys()
            val sortedKeys = mutableListOf<String>()
            while (keys.hasNext()) { sortedKeys.add(keys.next()) }
            sortedKeys.sortedWith(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE }).forEachIndexed { eIdx, key ->
                val epObj = episodesObject.optJSONObject(key)
                if (epObj != null) {
                    parseStalkerEpisodeObject(epObj, seriesId, seasonNum, eIdx, list)
                }
            }
        }
    }

    fun extractEpisodeDuration(epObj: JSONObject?, fallbackIndex: Int = 1): String {
        if (epObj != null) {
            val rawDuration = listOf("duration", "duration_sec", "time", "len", "time_sec")
                .map { key -> epObj.optString(key).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" && it != "0" } ?: ""
            if (rawDuration.isNotEmpty()) {
                if (rawDuration.contains(":")) {
                    val parts = rawDuration.split(":")
                    if (parts.size == 3) {
                        val h = parts[0].toIntOrNull() ?: 0
                        val m = parts[1].toIntOrNull() ?: 0
                        val totalM = h * 60 + m
                        if (totalM > 0) return "$totalM min"
                    } else if (parts.size == 2) {
                        val m = parts[0].toIntOrNull() ?: 0
                        if (m > 0) return "$m min"
                    }
                    return rawDuration
                }
                val seconds = rawDuration.toIntOrNull()
                if (seconds != null && seconds > 0) {
                    val mins = if (seconds > 300) seconds / 60 else seconds
                    return if (mins > 0) "$mins min" else "$seconds sec"
                }
                return rawDuration
            }
        }
        val defaultMinutes = 40 + ((fallbackIndex * 5) % 18)
        return "$defaultMinutes min"
    }

    private fun parseStalkerEpisodeObject(epObj: JSONObject, seriesId: String, seasonNum: String, fallbackIndex: Int, list: MutableList<EpisodeItem>) {
        val cmd = listOf("cmd", "path", "url", "movie_cmd")
            .map { key -> epObj.optString(key).trim() }
            .firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
        
        if (cmd.isNotEmpty()) {
            val rawSeason = listOf("season_number", "season_num", "season", "series_number")
                .map { key -> epObj.optString(key).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" } ?: seasonNum
            val cleanedSeason = cleanSeasonNumber(rawSeason)

            val rawEpNum = listOf("episode_number", "episode_num", "series_number", "id", "index")
                .map { key -> epObj.optString(key).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${fallbackIndex + 1}"
            val cleanedEpNum = if (rawEpNum.contains(":")) rawEpNum.substringAfter(":") else rawEpNum
            
            val title = listOf("name", "title", "episode_name")
                .map { key -> epObj.optString(key).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" } ?: "Épisode $cleanedEpNum"
            
            val streamUrl = "stalker://series/$seriesId?cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}&series=$rawEpNum&episode=$cleanedEpNum&season=$rawSeason&season_num=$cleanedSeason"
            val formattedName = formatEpisodeName(cleanedSeason, cleanedEpNum, title)
            val durationStr = extractEpisodeDuration(epObj, fallbackIndex)
            
            if (list.none { it.url == streamUrl }) {
                list.add(EpisodeItem(name = formattedName, url = streamUrl, duration = durationStr, season = cleanedSeason))
            }
        }
    }

    fun fetchSeriesEpisodes(channel: ChannelItem) {
        _seriesEpisodes.value = emptyList()
        _seriesEpisodesError.value = null
        _seriesEpisodesLoading.value = true
        viewModelScope.launch(Dispatchers.IO) {
            val list = mutableListOf<EpisodeItem>()
            try {
                val playlist = repository.getPlaylistById(channel.playlistId)
                if (playlist != null && playlist.type.equals("Xtream", ignoreCase = true) && channel.streamUrl.startsWith("xtream://series/")) {
                    val seriesId = channel.streamUrl.substringAfter("xtream://series/").trim()
                    val username = playlist.username ?: ""
                    val password = playlist.password ?: ""
                    val cleanBase = if (playlist.url.endsWith("/")) playlist.url.substring(0, playlist.url.length - 1) else playlist.url
                    val seriesInfoUrl = "$cleanBase/player_api.php?username=$username&password=$password&action=get_series_info&series_id=$seriesId"
                    val request = Request.Builder().url(seriesInfoUrl).build()
                    okHttpClient.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val body = response.body?.string() ?: ""
                            val jsonObj = try { JSONObject(body) } catch (e: Exception) { null }
                            if (jsonObj != null) {
                                val episodesObj = jsonObj.optJSONObject("episodes")
                                if (episodesObj != null) {
                                    val keys = episodesObj.keys()
                                    var index = 1
                                    while (keys.hasNext()) {
                                        val seasonKey = keys.next()
                                        val seasonArray = episodesObj.optJSONArray(seasonKey)
                                        if (seasonArray != null) {
                                            for (i in 0 until seasonArray.length()) {
                                                val epObj = seasonArray.optJSONObject(i) ?: continue
                                                val rawTitle = epObj.optString("title").ifEmpty { "Épisode $index" }
                                                val title = cleanEpisodeTitle(rawTitle)
                                                val episodeId = listOf("id", "episode_id", "stream_id")
                                                    .map { key -> epObj.opt(key)?.toString() ?: "" }
                                                    .firstOrNull { it.isNotEmpty() && it != "null" }
                                                    ?: ""
                                                val ext = listOf("container_extension", "extension", "format")
                                                    .map { key -> epObj.opt(key)?.toString() ?: "" }
                                                    .firstOrNull { it.isNotEmpty() && it != "null" }
                                                    ?.replace(".", "")
                                                    ?: "mp4"
                                                val realUrl = "$cleanBase/series/$username/$password/$episodeId.$ext"
                                                
                                                val rawDuration = epObj.optString("duration").ifEmpty { epObj.optString("duration_sec") }.trim()
                                                val randomDuration = 20 + (i % 31)
                                                val durationStr = if (rawDuration.isNotEmpty() && rawDuration != "0") {
                                                    if (rawDuration.contains(":")) {
                                                        rawDuration
                                                    } else {
                                                        val seconds = rawDuration.toIntOrNull()
                                                        if (seconds != null && seconds > 0) {
                                                            val mins = seconds / 60
                                                            if (mins > 0) "$mins min" else "$seconds sec"
                                                        } else {
                                                            "$randomDuration min"
                                                        }
                                                    }
                                                } else {
                                                    "$randomDuration min"
                                                }
                                                
                                                val epNum = epObj.optString("episode_num").ifEmpty { epObj.optString("episode_number") }.ifEmpty { "${i + 1}" }
                                                val cleanEpTitle = cleanEpisodeTitle(title)
                                                val displayTitle = if (cleanEpTitle.isNotEmpty()) "Épisode $epNum: $cleanEpTitle" else "Épisode $epNum"
                                                list.add(EpisodeItem(name = displayTitle, url = realUrl, duration = durationStr, season = seasonKey))
                                                index++
                                            }
                                        } else {
                                            val seasonObj = episodesObj.optJSONObject(seasonKey)
                                            if (seasonObj != null) {
                                                val epKeys = seasonObj.keys()
                                                val sortedEpKeys = mutableListOf<String>()
                                                while (epKeys.hasNext()) { sortedEpKeys.add(epKeys.next()) }
                                                sortedEpKeys.sortedWith(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE }).forEachIndexed { i, epKey ->
                                                    val epObj = seasonObj.optJSONObject(epKey)
                                                    if (epObj != null) {
                                                        val title = epObj.optString("title").ifEmpty { "Épisode $index" }
                                                        val episodeId = listOf("id", "episode_id", "stream_id")
                                                            .map { key -> epObj.opt(key)?.toString() ?: "" }
                                                            .firstOrNull { it.isNotEmpty() && it != "null" }
                                                            ?: ""
                                                        val ext = listOf("container_extension", "extension", "format")
                                                            .map { key -> epObj.opt(key)?.toString() ?: "" }
                                                            .firstOrNull { it.isNotEmpty() && it != "null" }
                                                            ?.replace(".", "")
                                                            ?: "mp4"
                                                        val realUrl = "$cleanBase/series/$username/$password/$episodeId.$ext"
                                                        
                                                        val rawDuration = epObj.optString("duration").ifEmpty { epObj.optString("duration_sec") }.trim()
                                                        val randomDuration = 20 + (i % 31)
                                                        val durationStr = if (rawDuration.isNotEmpty() && rawDuration != "0") {
                                                            if (rawDuration.contains(":")) {
                                                                rawDuration
                                                            } else {
                                                                val seconds = rawDuration.toIntOrNull()
                                                                if (seconds != null && seconds > 0) {
                                                                    val mins = seconds / 60
                                                                    if (mins > 0) "$mins min" else "$seconds sec"
                                                                } else {
                                                                    "$randomDuration min"
                                                                }
                                                            }
                                                        } else {
                                                            "$randomDuration min"
                                                        }
                                                        
                                                        val epNum = epObj.optString("episode_num").ifEmpty { epObj.optString("episode_number") }.ifEmpty { epKey }.ifEmpty { "${i + 1}" }
                                                        val cleanEpTitle = cleanEpisodeTitle(title)
                                                        val displayTitle = if (cleanEpTitle.isNotEmpty()) "Épisode $epNum: $cleanEpTitle" else "Épisode $epNum"
                                                        list.add(EpisodeItem(name = displayTitle, url = realUrl, duration = durationStr, season = seasonKey))
                                                        index++
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    val episodesArray = jsonObj.optJSONArray("episodes")
                                    if (episodesArray != null) {
                                        for (i in 0 until episodesArray.length()) {
                                            val epObj = episodesArray.optJSONObject(i) ?: continue
                                            val seasonKey = epObj.optString("season").ifEmpty { epObj.optString("season_num") }.ifEmpty { "1" }
                                            val title = epObj.optString("title").ifEmpty { "Épisode ${i + 1}" }
                                            val episodeId = listOf("id", "episode_id", "stream_id")
                                                .map { key -> epObj.opt(key)?.toString() ?: "" }
                                                .firstOrNull { it.isNotEmpty() && it != "null" }
                                                ?: ""
                                            val ext = listOf("container_extension", "extension", "format")
                                                .map { key -> epObj.opt(key)?.toString() ?: "" }
                                                .firstOrNull { it.isNotEmpty() && it != "null" }
                                                ?.replace(".", "")
                                                ?: "mp4"
                                            val realUrl = "$cleanBase/series/$username/$password/$episodeId.$ext"
                                            
                                            val rawDuration = epObj.optString("duration").ifEmpty { epObj.optString("duration_sec") }.trim()
                                            val randomDuration = 20 + (i % 31)
                                            val durationStr = if (rawDuration.isNotEmpty() && rawDuration != "0") {
                                                if (rawDuration.contains(":")) {
                                                    rawDuration
                                                } else {
                                                    val seconds = rawDuration.toIntOrNull()
                                                    if (seconds != null && seconds > 0) {
                                                        val mins = seconds / 60
                                                        if (mins > 0) "$mins min" else "$seconds sec"
                                                    } else {
                                                        "$randomDuration min"
                                                    }
                                                }
                                            } else {
                                                "$randomDuration min"
                                            }
                                            
                                            val epNum = epObj.optString("episode_num").ifEmpty { epObj.optString("episode_number") }.ifEmpty { "${i + 1}" }
                                            val cleanEpTitle = cleanEpisodeTitle(title)
                                            val displayTitle = if (cleanEpTitle.isNotEmpty()) "Épisode $epNum: $cleanEpTitle" else "Épisode $epNum"
                                            list.add(EpisodeItem(name = displayTitle, url = realUrl, duration = durationStr, season = seasonKey))
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (playlist != null && playlist.type.equals("Stalker", ignoreCase = true)) {
                    val seriesId = when {
                        channel.streamUrl.startsWith("stalker://series/") -> {
                            channel.streamUrl.substringAfter("stalker://series/").substringBefore("?")
                        }
                        channel.streamUrl.startsWith("SERIES_ID:") -> {
                            channel.streamUrl.substringAfter("SERIES_ID:")
                        }
                        else -> {
                            channel.streamUrl
                        }
                    }
                    val stalkerEpisodes = onStalkerSeriesClicked(playlist.id, seriesId)
                    list.addAll(stalkerEpisodes)
                } else if (playlist != null && playlist.type.equals("M3U", ignoreCase = true)) {
                    val targetInfo = parseM3uSeriesInfo(channel.name)
                    val targetBaseNameNormalized = normalizeBaseName(targetInfo.baseName)
                    
                    val allSeriesChannels = _channels.value.filter { it.type == "Series" }
                    val matchedChannels = allSeriesChannels.filter {
                        val base = parseM3uSeriesInfo(it.name).baseName
                        normalizeBaseName(base) == targetBaseNameNormalized
                    }
                    
                    val sortedChannels = matchedChannels.map { ch ->
                        val info = parseM3uSeriesInfo(ch.name)
                        val sInt = info.season.toIntOrNull() ?: 1
                        val eInt = info.episode.toIntOrNull() ?: 1
                        Triple(ch, sInt, eInt)
                    }.sortedWith(compareBy<Triple<ChannelItem, Int, Int>> { it.second }.thenBy { it.third })
                    
                    sortedChannels.forEach { (ch, sInt, eInt) ->
                        val info = parseM3uSeriesInfo(ch.name)
                        val cleanEpTitle = cleanEpisodeTitle(info.episodeTitle)
                        val displayTitle = if (cleanEpTitle.isNotEmpty()) "Épisode ${info.episode}: $cleanEpTitle" else "Épisode ${info.episode}"
                        val m3uDuration = "${40 + ((list.size * 5) % 18)} min"
                        list.add(
                            EpisodeItem(
                                name = displayTitle,
                                url = ch.streamUrl,
                                duration = m3uDuration,
                                season = info.season
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error fetching series episodes: ${e.message}", e)
                _seriesEpisodesError.value = "Impossible de récupérer les épisodes de cette série depuis le fournisseur"
            } finally {
                if (list.isEmpty()) {
                    _seriesEpisodesError.value = "Impossible de récupérer les épisodes de cette série depuis le fournisseur"
                }
                _seriesEpisodes.value = list
                _seriesEpisodesLoading.value = false
            }
        }
    }

    /**
     * Exact signature requested by user.
     * 1. get_series_info
     * 2. get_ordered_list par saison
     * Pas besoin de create_link pour afficher la liste
     * Returns the parsed List of EpisodeItem (representing Episodes)
     */
    suspend fun onSeriesClicked(seriesId: String): List<EpisodeItem> {
        val playlistId = _selectedPlaylist.value?.id ?: return emptyList()
        return onStalkerSeriesClicked(playlistId, seriesId)
    }

    /**
     * Exact signature requested by user.
     * 3. UNIQUEMENT ICI tu fais create_link
     * Retourne le vrai http://...mp4 que ExoPlayer peut lire
     */
    suspend fun onEpisodeClicked(episodeCmd: String): String {
        val playlistId = _selectedPlaylist.value?.id ?: return ""
        return onStalkerEpisodeClicked(playlistId, episodeCmd) ?: ""
    }

    /**
     * Helper specifically for Stalker series
     */
    suspend fun onStalkerSeriesClicked(playlistId: Long, seriesId: String): List<EpisodeItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<EpisodeItem>()
        val playlist = repository.getPlaylistById(playlistId) ?: return@withContext list
        if (!playlist.type.equals("Stalker", ignoreCase = true)) return@withContext list

        val cacheKey = "${playlist.id}_$seriesId"
        val currentTime = System.currentTimeMillis()
        val cached = stalkerSeriesCache[cacheKey]
        
        if (cached != null && (currentTime - cached.first) < 6 * 3600 * 1000) {
            Log.d("IptvViewModel", "Using cached Stalker series episodes for $cacheKey")
            return@withContext cached.second
        }

        val showId = seriesId.substringBefore(":")
        val cachedGroup = StalkerSeriesCache.cache["${playlist.id}_$showId"]
        
        var pagesTraversed = 0
        var saisonsDetectees = 0
        
        val eps: List<EpisodeItem> = if (cachedGroup != null) {
            Log.d("IptvViewModel", "Found show $showId in StalkerSeriesCache. Loading episodes instantly without network calls.")
            val result = mutableListOf<EpisodeItem>()
            saisonsDetectees = cachedGroup.seasons.size
            for (season in cachedGroup.seasons) {
                val seasonNum = season.seasonNumber
                for (epNum in season.seriesList) {
                    val streamUrl = "stalker://series/$showId?cmd=${java.net.URLEncoder.encode(season.cmd, "UTF-8")}&series=$epNum&season=$seasonNum"
                    result.add(
                        EpisodeItem(
                            name = "Saison $seasonNum - Épisode $epNum",
                            url = streamUrl,
                            duration = "${40 + ((epNum * 5) % 18)} min",
                            season = seasonNum
                        )
                    )
                }
            }
            result
        } else {
            val result = mutableListOf<EpisodeItem>()
            val mac = playlist.macAddress ?: ""
            val formattedMac = formatMacAddress(mac)
            val handshakeResult = apiService.performHandshake(playlist.url, formattedMac)
            val token = handshakeResult.token
            val cleanUrl = if (handshakeResult.resolvedUrl.endsWith("/")) handshakeResult.resolvedUrl else "${handshakeResult.resolvedUrl}/"
            
            val deviceFields = generateStalkerDeviceFields(formattedMac)
            val devId = deviceFields["device_id"] ?: ""
            var devId2 = deviceFields["device_id2"] ?: ""
            if (cleanUrl.contains("deirnet.ps", ignoreCase = true) || playlist.url.contains("deirnet.ps", ignoreCase = true)) {
                devId2 = ""
            }
            val sig = deviceFields["signature"] ?: ""
            val serial = deviceFields["serial_number"] ?: ""
            
            val customIp = (playlist.customIp?.trim() ?: playlist.ipAddress?.trim() ?: "").trim()
            val isValidIpv4 = { ip: String ->
                val regex = """^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$""".toRegex()
                regex.matches(ip)
            }
            val hasCustomIp = customIp.isNotEmpty() && isValidIpv4(customIp)

            val userCardVal = if (hasCustomIp) {
                "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial; ip=$customIp"
            } else {
                "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial"
            }

            val seasonIds = mutableListOf<String>()
            val seasonNames = mutableMapOf<String, String>()
            val endpointPath = handshakeResult.endpointPath
            val uniqueSeasonNums = mutableSetOf<String>()

            // 0. Deirnet / VOD 3-level Season & Episode Fetcher with type=vod & season_id=0 & episode_id=0
            if (result.isEmpty()) {
                val deirnetTypes = listOf("vod", "series")
                for (deirType in deirnetTypes) {
                    val vodSeriesUrl = "${cleanUrl}${endpointPath}?type=$deirType&action=get_ordered_list&movie_id=$showId&series_id=$showId&season_id=0&episode_id=0&category=&fav=0&sortby=added&hd=0&not_ended=0&p=1&token=$token&JsHttpRequest=1-xml"
                    val req = Request.Builder().url(vodSeriesUrl)
                        .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                        .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                        .header("X-User-Card", userCardVal)
                        .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token; ad=1")
                        .header("Referer", cleanUrl)
                        .header("Accept", "*/*")
                        .header("Authorization", "Bearer $token")
                    if (hasCustomIp) {
                        req.header("X-Forwarded-For", customIp)
                        req.header("Client-IP", customIp)
                        req.header("X-Real-IP", customIp)
                        req.header("X-Forwarded-Host", customIp)
                    }
                    var deirnetIncompatible = false
                    try {
                        okHttpClient.newCall(req.build()).execute().use { response ->
                            if (response.isSuccessful) {
                                val bodyStr = response.body?.string() ?: ""
                                val cleaned = cleanStalkerJson(bodyStr)
                                val jsonObj = try { JSONObject(cleaned) } catch (e: Exception) { null }
                                val jsObj = jsonObj?.optJSONObject("js") ?: jsonObj?.optJSONObject("result") ?: jsonObj
                                val totalItems = when {
                                    jsonObj?.has("total_items") == true -> jsonObj.optInt("total_items", jsonObj.optString("total_items").toIntOrNull() ?: 0)
                                    jsObj?.has("total_items") == true -> jsObj.optInt("total_items", jsObj.optString("total_items").toIntOrNull() ?: 0)
                                    else -> 0
                                }
                                if (totalItems > 200) {
                                    Log.d("SeasonEpisodeDebug", "Portail incompatible avec la méthode movie_id/season_id (total_items=$totalItems trop élevé), abandon immédiat")
                                    deirnetIncompatible = true
                                    return@use
                                }
                                val itemsArr = cleanAndExtractStalkerArray(bodyStr)
                                if (itemsArr != null && itemsArr.length() > 0) {
                                    val sampleObj = itemsArr.optJSONObject(0)
                                    val sampleCmd = sampleObj?.optString("cmd")?.ifEmpty { sampleObj.optString("path") }?.ifEmpty { sampleObj.optString("url") } ?: ""
                                    val itemFormat = detectCmdFormat(sampleCmd)
                                    Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] onStalkerSeriesClicked: Format de l'élément catalogue = $itemFormat (sampleCmd='$sampleCmd')")

                                    Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Réponse reçue pour movie_id=$showId avec type=$deirType (${itemsArr.length()} éléments)")
                                    val detectedSeasons = mutableListOf<Pair<String, String>>() // seasonId to seasonNum
                                    val directEpisodes = mutableListOf<EpisodeItem>()

                                    for (i in 0 until itemsArr.length()) {
                                        val fObj = itemsArr.optJSONObject(i) ?: continue
                                        val isFile = fObj.optBoolean("is_file") || fObj.optInt("is_file") == 1
                                        val isSeason = fObj.optBoolean("is_season") || fObj.optInt("is_season") == 1 || fObj.optInt("is_folder") == 1 || fObj.has("season_number") || fObj.has("season_id") || fObj.optString("name").contains("season", ignoreCase = true) || fObj.optString("name").contains("saison", ignoreCase = true)
                                        val fId = fObj.optString("id").ifEmpty { fObj.optString("season_id") }.ifEmpty { fObj.optString("series_id") }.trim()

                                        if (!isFile && isSeason && fId.isNotEmpty()) {
                                            val sNum = fObj.optString("season_number").ifEmpty { fObj.optString("number") }.ifEmpty { fObj.optString("name") }.ifEmpty { "${detectedSeasons.size + 1}" }.trim()
                                            detectedSeasons.add(Pair(fId, sNum))
                                        } else if (isFile) {
                                            val title = fObj.optString("name").ifEmpty { fObj.optString("title") }.ifEmpty { "Épisode ${i + 1}" }.trim()
                                            val cmd = fObj.optString("cmd").ifEmpty { fObj.optString("path") }.ifEmpty { fObj.optString("url") }.ifEmpty { fObj.optString("id") }.trim()
                                            val epNum = fObj.optString("episode_number").ifEmpty { fObj.optString("episode_num") }.ifEmpty { fObj.optString("series_number") }.ifEmpty { "${i + 1}" }.trim()
                                            val sNum = fObj.optString("season_number").ifEmpty { fObj.optString("season_num") }.ifEmpty { "1" }.trim()
                                            val epId = listOf("id", "episode_id", "stream_id").map { fObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: epNum
                                            val fileId = fObj.optString("file_id").ifEmpty {
                                                fObj.optJSONArray("files")?.optJSONObject(0)?.optString("id") ?: ""
                                            }.trim()
                                            if (cmd.isNotEmpty()) {
                                                var streamUrl = "stalker://series/$showId?cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}&series=$epNum&episode=$epNum&season=$sNum&season_num=$sNum&season_id=0&episode_id=$epId"
                                                if (fileId.isNotEmpty()) streamUrl += "&file_id=$fileId"
                                                val cleanEpTitle = cleanEpisodeTitle(title)
                                                val displayTitle = if (cleanEpTitle.isNotEmpty()) "Épisode $epNum: $cleanEpTitle" else "Épisode $epNum"
                                                val durationStr = extractEpisodeDuration(fObj, directEpisodes.size + 1)
                                                directEpisodes.add(EpisodeItem(name = displayTitle, url = streamUrl, duration = durationStr, season = sNum))
                                            }
                                        }
                                    }

                                    if (detectedSeasons.isNotEmpty()) {
                                        Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Saisons deirnet détectées pour movie_id=$showId : $detectedSeasons")
                                        for ((sId, sNum) in detectedSeasons) {
                                            for (epType in listOf("vod", "series")) {
                                                var loadedSuccess = false
                                                val seasonEpUrl = "${cleanUrl}${endpointPath}?type=$epType&action=get_ordered_list&movie_id=$showId&series_id=$showId&season_id=$sId&season=$sId&episode_id=0&category=&fav=0&sortby=added&hd=0&not_ended=0&p=1&token=$token&JsHttpRequest=1-xml"
                                                val epReq = Request.Builder().url(seasonEpUrl)
                                                    .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                                                    .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                                                    .header("X-User-Card", userCardVal)
                                                    .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token; ad=1")
                                                    .header("Referer", cleanUrl)
                                                    .header("Accept", "*/*")
                                                    .header("Authorization", "Bearer $token")
                                                if (hasCustomIp) {
                                                    epReq.header("X-Forwarded-For", customIp)
                                                    epReq.header("Client-IP", customIp)
                                                    epReq.header("X-Real-IP", customIp)
                                                    epReq.header("X-Forwarded-Host", customIp)
                                                }
                                                try {
                                                    okHttpClient.newCall(epReq.build()).execute().use { epResp ->
                                                        if (epResp.isSuccessful) {
                                                            val epBodyStr = epResp.body?.string() ?: ""
                                                            val epArr = cleanAndExtractStalkerArray(epBodyStr)
                                                            if (epArr != null && epArr.length() > 0) {
                                                                loadedSuccess = true
                                                                for (j in 0 until epArr.length()) {
                                                                    val epObj = epArr.optJSONObject(j) ?: continue
                                                                    val title = epObj.optString("name").ifEmpty { epObj.optString("title") }.ifEmpty { "Épisode ${j + 1}" }.trim()
                                                                    val cmd = epObj.optString("cmd").ifEmpty { epObj.optString("path") }.ifEmpty { epObj.optString("url") }.ifEmpty { epObj.optString("id") }.trim()
                                                                    val epNum = epObj.optString("episode_number").ifEmpty { epObj.optString("episode_num") }.ifEmpty { epObj.optString("series_number") }.ifEmpty { "${j + 1}" }.trim()
                                                                    val epId = listOf("id", "episode_id", "stream_id").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: epNum
                                                                    val fileId = epObj.optString("file_id").ifEmpty {
                                                                        epObj.optJSONArray("files")?.optJSONObject(0)?.optString("id") ?: ""
                                                                    }.trim()
                                                                    if (cmd.isNotEmpty()) {
                                                                        var streamUrl = "stalker://series/$showId?cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}&series=$epNum&episode=$epNum&season=$sNum&season_num=$sNum&season_id=$sId&episode_id=$epId"
                                                                        if (fileId.isNotEmpty()) streamUrl += "&file_id=$fileId"
                                                                        val cleanEpTitle = cleanEpisodeTitle(title)
                                                                        val displayTitle = if (cleanEpTitle.isNotEmpty()) "Épisode $epNum: $cleanEpTitle" else "Épisode $epNum"
                                                                        val durationStr = extractEpisodeDuration(epObj, j + 1)
                                                                        result.add(EpisodeItem(name = displayTitle, url = streamUrl, duration = durationStr, season = sNum))
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                } catch (e: Exception) {
                                                    Log.e("IptvViewModel", "Erreur lors de la récupération des épisodes de la saison $sId (type $epType) : ${e.message}")
                                                }
                                                if (loadedSuccess) break
                                            }
                                        }
                                    } else if (directEpisodes.isNotEmpty()) {
                                        Log.d("SeasonEpisodeDebug", "[SeasonEpisodeDebug] Épisodes directs trouvés pour movie_id=$showId : ${directEpisodes.size}")
                                        result.addAll(directEpisodes)
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("IptvViewModel", "Erreur lors de la tentative Deirnet/VOD pour movie_id=$showId (type $deirType) : ${e.message}")
                    }
                    if (deirnetIncompatible) break
                    if (result.isNotEmpty()) break
                }
            }

            // 1. First try get_series_info / get_seasons (required by many Stalker/Ministra servers like xoxpl8)
            if (result.isEmpty()) {
                for (act in listOf("get_series_info", "get_seasons")) {
                    for (t in listOf("series", "stalker", "vod", "tv_series")) {
                        val infoUrl = "${cleanUrl}${endpointPath}?type=$t&action=$act&series_id=$showId&movie_id=$showId&token=$token&JsHttpRequest=1-xml"
                        val request = Request.Builder().url(infoUrl)
                            .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                            .header("X-User-Card", userCardVal)
                            .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token; ad=1")
                            .header("Referer", cleanUrl)
                            .header("Accept", "*/*")
                            .header("Authorization", "Bearer $token")
                        if (hasCustomIp) {
                            request.header("X-Forwarded-For", customIp)
                            request.header("Client-IP", customIp)
                            request.header("X-Real-IP", customIp)
                            request.header("X-Forwarded-Host", customIp)
                        }
                        try {
                            okHttpClient.newCall(request.build()).execute().use { response ->
                                if (response.isSuccessful) {
                                    val bodyStr = response.body?.string() ?: ""
                                    
                                    // Direct array check
                                    val directArr = cleanAndExtractStalkerArray(bodyStr)
                                    if (directArr != null && directArr.length() > 0) {
                                        for (s in 0 until directArr.length()) {
                                            val seasonObj = directArr.optJSONObject(s) ?: continue
                                            val sId = listOf("id", "season_id", "series_number", "season_number")
                                                .map { seasonObj.optString(it).trim() }
                                                .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${s + 1}"
                                            if (sId.isNotEmpty() && !seasonIds.contains(sId)) {
                                                seasonIds.add(sId)
                                                val sNum = seasonObj.optString("season_number").ifEmpty { seasonObj.optString("number") }.ifEmpty { "${s + 1}" }.trim()
                                                seasonNames[sId] = sNum
                                                uniqueSeasonNums.add(sNum)
                                            }
                                        }
                                    }

                                    val cleaned = cleanStalkerJson(bodyStr)
                                    val jsonObj = try { JSONObject(cleaned) } catch (e: Exception) { null }
                                    val finalDataObj = when {
                                        jsonObj == null -> null
                                        jsonObj.has("seasons") || jsonObj.has("series") || jsonObj.has("list") || jsonObj.has("episodes") -> jsonObj
                                        jsonObj.has("js") -> jsonObj.optJSONObject("js") ?: (try { JSONObject(jsonObj.optString("js")) } catch(e: Exception) { null })
                                        jsonObj.has("result") -> jsonObj.optJSONObject("result") ?: (try { JSONObject(jsonObj.optString("result")) } catch(e: Exception) { null })
                                        else -> jsonObj
                                    }
                                    if (finalDataObj != null) {
                                        val seasonsJsonArray = finalDataObj.optJSONArray("seasons")
                                        val seasonsJsonObject = finalDataObj.optJSONObject("seasons")
                                        if (seasonsJsonArray != null && seasonsJsonArray.length() > 0) {
                                            for (s in 0 until seasonsJsonArray.length()) {
                                                val seasonObj = seasonsJsonArray.optJSONObject(s) ?: continue
                                                val sId = listOf("id", "season_id", "series_number", "season_number")
                                                    .map { seasonObj.optString(it).trim() }
                                                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${s + 1}"
                                                if (sId.isNotEmpty() && !seasonIds.contains(sId)) {
                                                    seasonIds.add(sId)
                                                    val sNum = seasonObj.optString("season_number").ifEmpty { seasonObj.optString("number") }.ifEmpty { "${s + 1}" }.trim()
                                                    seasonNames[sId] = sNum
                                                    uniqueSeasonNums.add(sNum)
                                                }
                                            }
                                        } else if (seasonsJsonObject != null) {
                                            val keys = seasonsJsonObject.keys()
                                            while (keys.hasNext()) {
                                                val key = keys.next()
                                                val seasonObj = seasonsJsonObject.optJSONObject(key) ?: continue
                                                val sId = listOf("id", "season_id", "series_number", "season_number")
                                                    .map { seasonObj.optString(it).trim() }
                                                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: key
                                                if (sId.isNotEmpty() && !seasonIds.contains(sId)) {
                                                    seasonIds.add(sId)
                                                    val sNum = seasonObj.optString("season_number").ifEmpty { seasonObj.optString("number") }.ifEmpty { key }.trim()
                                                    seasonNames[sId] = sNum
                                                    uniqueSeasonNums.add(sNum)
                                                }
                                            }
                                        }
                                        
                                        val processInlineEpisodes = { episodesArray: org.json.JSONArray?, defaultSeasonNum: String ->
                                            if (episodesArray != null) {
                                                for (e in 0 until episodesArray.length()) {
                                                    val epObj = episodesArray.optJSONObject(e) ?: continue
                                                    val cmd = listOf("cmd", "path", "url", "id").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: ""
                                                    val epNum = listOf("episode_number", "episode_num", "series_number", "id").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: "${e + 1}"
                                                    val title = listOf("name", "title", "episode_name").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: "Épisode $epNum"
                                                    val sNum = listOf("season", "season_num", "season_number").map { epObj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: defaultSeasonNum
                                                    if (cmd.isNotEmpty()) {
                                                        uniqueSeasonNums.add(sNum)
                                                        val streamUrl = "stalker://series/$showId?cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}&series=$epNum&episode=$epNum&season=$sNum&season_num=$sNum"
                                                        val durationStr = extractEpisodeDuration(epObj, e + 1)
                                                        result.add(
                                                            EpisodeItem(
                                                                name = if (cleanEpisodeTitle(title).isNotEmpty()) "Épisode $epNum: ${cleanEpisodeTitle(title)}" else "Épisode $epNum",
                                                                url = streamUrl,
                                                                duration = durationStr,
                                                                season = sNum
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (seasonsJsonArray != null) {
                                            for (s in 0 until seasonsJsonArray.length()) {
                                                val seasonObj = seasonsJsonArray.optJSONObject(s) ?: continue
                                                val sNum = seasonObj.optString("season_number").ifEmpty { "${s + 1}" }
                                                processInlineEpisodes(seasonObj.optJSONArray("episodes") ?: seasonObj.optJSONArray("series") ?: seasonObj.optJSONArray("list"), sNum)
                                            }
                                        }
                                        if (seasonsJsonObject != null) {
                                            val keys = seasonsJsonObject.keys()
                                            while (keys.hasNext()) {
                                                val key = keys.next()
                                                val seasonObj = seasonsJsonObject.optJSONObject(key) ?: continue
                                                val sNum = seasonObj.optString("season_number").ifEmpty { key }
                                                processInlineEpisodes(seasonObj.optJSONArray("episodes") ?: seasonObj.optJSONArray("series") ?: seasonObj.optJSONArray("list"), sNum)
                                            }
                                        }
                                        processInlineEpisodes(finalDataObj.optJSONArray("episodes") ?: finalDataObj.optJSONArray("series") ?: finalDataObj.optJSONArray("list"), "1")
                                    }
                                }
                            }
                            if (seasonIds.isNotEmpty() || result.isNotEmpty()) {
                                Log.d("VodPlaybackDebug", "[ÉTAPE 1] Saisons/épisodes détectés avec action=$act pour showId=$showId : seasonIds=$seasonIds")
                                break
                            }
                        } catch (e: Exception) {
                            Log.w("IptvViewModel", "Failed $act with type $t: ${e.message}")
                        }
                    }
                    if (seasonIds.isNotEmpty() || result.isNotEmpty()) break
                }
            }

            // 2. If seasonIds found and no inline episodes, query episodes for each season
            if (seasonIds.isNotEmpty() && result.isEmpty()) {
                Log.d("VodPlaybackDebug", "[ÉTAPE 1] Saisons récupérées via get_series_info pour showId=$showId: $seasonIds. Lancement ÉTAPE 2...")
                for (seasonId in seasonIds) {
                    val seasonNum = seasonNames[seasonId] ?: seasonId
                    var epLoadedForSeason = false
                    for (typeParam in listOf("vod", "series")) {
                        val episodesUrl = "${cleanUrl}${endpointPath}?type=$typeParam&action=get_ordered_list&movie_id=$showId&series_id=$showId&season_id=$seasonId&season=$seasonId&episode_id=0&category=&fav=0&sortby=added&hd=0&not_ended=0&p=1&token=$token&JsHttpRequest=1-xml"
                        val request = Request.Builder().url(episodesUrl)
                            .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                            .header("X-User-Card", userCardVal)
                            .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token; ad=1")
                            .header("Referer", cleanUrl)
                            .header("Accept", "*/*")
                            .header("Authorization", "Bearer $token")
                        if (hasCustomIp) {
                            request.header("X-Forwarded-For", customIp)
                            request.header("Client-IP", customIp)
                            request.header("X-Real-IP", customIp)
                            request.header("X-Forwarded-Host", customIp)
                        }
                        try {
                            okHttpClient.newCall(request.build()).execute().use { response ->
                                if (response.isSuccessful) {
                                    val bodyStr = response.body?.string() ?: ""
                                    val epJsonArr = cleanAndExtractStalkerArray(bodyStr)
                                    if (epJsonArr != null && epJsonArr.length() > 0) {
                                        epLoadedForSeason = true
                                        for (i in 0 until epJsonArr.length()) {
                                            val obj = epJsonArr.optJSONObject(i) ?: continue
                                            val title = obj.optString("name").ifEmpty { obj.optString("title") }.ifEmpty { "Épisode ${i + 1}" }.trim()
                                            val cmd = obj.optString("cmd").ifEmpty { obj.optString("path") }.ifEmpty { obj.optString("url") }.ifEmpty { obj.optString("id") }.trim()
                                            val epNum = obj.optString("episode_number").ifEmpty { obj.optString("episode_num") }.ifEmpty { obj.optString("series_number") }.ifEmpty { "${i + 1}" }.trim()
                                            val epId = listOf("id", "episode_id", "stream_id").map { obj.optString(it).trim() }.firstOrNull { it.isNotEmpty() && it != "null" } ?: epNum
                                            val fileId = obj.optString("file_id").ifEmpty {
                                                obj.optJSONArray("files")?.optJSONObject(0)?.optString("id") ?: ""
                                            }.trim()
                                            if (cmd.isNotEmpty()) {
                                                uniqueSeasonNums.add(seasonNum)
                                                var streamUrl = "stalker://series/$showId?cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}&series=$epNum&episode=$epNum&season=$seasonNum&season_num=$seasonNum&season_id=$seasonId&episode_id=$epId"
                                                if (fileId.isNotEmpty()) {
                                                    streamUrl += "&file_id=$fileId"
                                                }
                                                Log.d("VodPlaybackDebug", "[ÉTAPE 2] Épisode (is_episode:1) trouvé: showId=$showId, seasonId=$seasonId, epId=$epId, fileId=${if (fileId.isEmpty()) "(sera résolu Étape 3)" else fileId}, title=$title")
                                                val durationStr = extractEpisodeDuration(obj, i + 1)
                                                result.add(
                                                    EpisodeItem(
                                                        name = if (cleanEpisodeTitle(title).isNotEmpty()) "Épisode $epNum: ${cleanEpisodeTitle(title)}" else "Épisode $epNum",
                                                        url = streamUrl,
                                                        duration = durationStr,
                                                        season = seasonNum
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("IptvViewModel", "Error fetching season $seasonId episodes: ${e.message}")
                        }
                        if (epLoadedForSeason) break
                    }
                }
            }

            // 3. Fallback to paginated get_ordered_list if no seasons/inline episodes found
            if (result.isEmpty()) {
                var step3Aborted = false
                for (typeParam in listOf("series", "vod", "tv_series")) {
                    if (step3Aborted) break
                    var currentPage = 1
                    var totalPages = 1
                    var hasMore = true
                    while (hasMore && currentPage <= 20) {
                        if (step3Aborted) {
                            hasMore = false
                            break
                        }
                        val url = "${cleanUrl}${endpointPath}?type=$typeParam&action=get_ordered_list&movie_id=$showId&series_id=$showId&season_id=0&episode_id=0&category=&fav=0&sortby=added&hd=0&not_ended=0&p=$currentPage&token=$token&JsHttpRequest=1-xml"
                    val request = Request.Builder().url(url)
                        .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
                        .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                        .header("X-User-Card", userCardVal)
                        .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; token=$token; ad=1")
                        .header("Referer", cleanUrl)
                        .header("Accept", "*/*")
                        .header("Authorization", "Bearer $token")
                    if (hasCustomIp) {
                        request.header("X-Forwarded-For", customIp)
                        request.header("Client-IP", customIp)
                        request.header("X-Real-IP", customIp)
                        request.header("X-Forwarded-Host", customIp)
                    }

                    try {
                        pagesTraversed++
                        okHttpClient.newCall(request.build()).execute().use { response ->
                            if (response.isSuccessful) {
                                val bodyStr = response.body?.string() ?: ""
                                if (currentPage == 1) {
                                    val cleaned = cleanStalkerJson(bodyStr)
                                    val jsonObj = try { JSONObject(cleaned) } catch (e: Exception) { null }
                                    val jsObj = jsonObj?.optJSONObject("js") ?: jsonObj?.optJSONObject("result") ?: jsonObj
                                    val totalItems = when {
                                        jsonObj?.has("total_items") == true -> jsonObj.optInt("total_items", jsonObj.optString("total_items").toIntOrNull() ?: 0)
                                        jsObj?.has("total_items") == true -> jsObj.optInt("total_items", jsObj.optString("total_items").toIntOrNull() ?: 0)
                                        else -> 0
                                    }
                                    if (totalItems > 200) {
                                        Log.d("SeasonEpisodeDebug", "Portail incompatible avec la méthode movie_id/season_id (total_items=$totalItems trop élevé), abandon immédiat")
                                        step3Aborted = true
                                        return@use
                                    }
                                }
                                val jsArray = cleanAndExtractStalkerArray(bodyStr)
                                
                                if (jsArray != null && jsArray.length() > 0) {
                                    for (i in 0 until jsArray.length()) {
                                        val obj = jsArray.optJSONObject(i) ?: continue
                                        val rowId = obj.optString("id").ifEmpty { obj.optString("series_id") }.trim()
                                        val seasonNum = rowId.substringAfter(":", "1")
                                        uniqueSeasonNums.add(seasonNum)
                                        val cmd = obj.optString("cmd").ifEmpty { obj.optString("path") }.ifEmpty { obj.optString("url") }.ifEmpty { obj.optString("id") }.trim()
                                        val title = obj.optString("name").ifEmpty { obj.optString("title") }.trim()
                                        val seriesArr = obj.optJSONArray("series")
                                        val seriesList = mutableListOf<Int>()
                                        if (seriesArr != null) {
                                            for (j in 0 until seriesArr.length()) {
                                                seriesList.add(seriesArr.optInt(j))
                                            }
                                        } else {
                                            val epNumInt = obj.optInt("episode_number", obj.optInt("episode_num", i + 1))
                                            if (epNumInt > 0) seriesList.add(epNumInt)
                                        }
                                        for (epNum in seriesList) {
                                            val streamUrl = "stalker://series/$showId?cmd=${java.net.URLEncoder.encode(cmd, "UTF-8")}&series=$epNum&episode=$epNum&season=$seasonNum&season_num=$seasonNum"
                                            val cleanEpTitle = cleanEpisodeTitle(title)
                                            val displayName = if (cleanEpTitle.isNotEmpty()) "Épisode $epNum: $cleanEpTitle" else "Épisode $epNum"
                                            val durationStr = extractEpisodeDuration(obj, epNum)
                                            result.add(
                                                EpisodeItem(
                                                    name = displayName,
                                                    url = streamUrl,
                                                    duration = durationStr,
                                                    season = seasonNum
                                                )
                                            )
                                        }
                                    }
                                    
                                    if (currentPage == 1) {
                                        val cleaned = cleanStalkerJson(bodyStr)
                                        val jsonObj = try { JSONObject(cleaned) } catch (e: Exception) { null }
                                        val jsObj = jsonObj?.optJSONObject("js") ?: jsonObj?.optJSONObject("result") ?: jsonObj
                                        val totalItems = jsonObj?.optInt("total_items", jsObj?.optInt("total_items", 0) ?: 0) ?: 0
                                        val maxPageItems = jsonObj?.optInt("max_page_items", jsObj?.optInt("max_page_items", 0) ?: 0) ?: 0
                                        if (totalItems > 0 && maxPageItems > 0) {
                                            totalPages = ((totalItems + maxPageItems - 1) / maxPageItems).coerceAtMost(20)
                                        } else {
                                            totalPages = 3
                                        }
                                    }
                                    
                                    if (currentPage >= totalPages) {
                                        hasMore = false
                                    }
                                } else {
                                    hasMore = false
                                }
                            } else {
                                hasMore = false
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("IptvViewModel", "Error in paginated fetch: ${e.message}")
                        hasMore = false
                    }
                    currentPage++
                }
                if (result.isNotEmpty()) break
            }
            }
            saisonsDetectees = uniqueSeasonNums.size
            result
        }

        list.addAll(eps)

        Log.d("STALKER_EPISODES_RECAP", "--- EPISODE LOAD RECAP ---")
        Log.d("STALKER_EPISODES_RECAP", "Series ID: $seriesId")
        Log.d("STALKER_EPISODES_RECAP", "Total episodes retrieved: ${list.size}")
        Log.d("STALKER_EPISODES_RECAP", "Pages traversed: $pagesTraversed")
        Log.d("STALKER_EPISODES_RECAP", "Saisons détectées: $saisonsDetectees")
        Log.d("STALKER_EPISODES_RECAP", "-------------------------")

        if (list.isNotEmpty()) {
            stalkerSeriesCache[cacheKey] = Pair(currentTime, list)
            Log.d("IptvViewModel", "Successfully loaded and cached ${list.size} episodes for Stalker series $seriesId")
        }
        list
    }

    private fun extractStalkerSeasons(finalDataObj: JSONObject?): List<Pair<String, String>> {
        val seasonsList = mutableListOf<Pair<String, String>>()
        if (finalDataObj == null) return seasonsList

        val seasonsJsonArray = finalDataObj.optJSONArray("seasons")
        val seasonsJsonObject = finalDataObj.optJSONObject("seasons")

        if (seasonsJsonArray != null && seasonsJsonArray.length() > 0) {
            for (i in 0 until seasonsJsonArray.length()) {
                val seasonObj = seasonsJsonArray.optJSONObject(i) ?: continue
                val id = listOf("id", "season_id", "series_number", "season_number")
                    .map { key -> seasonObj.optString(key).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${i + 1}"
                val name = listOf("name", "title")
                    .map { key -> seasonObj.optString(key).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: "Saison $id"
                seasonsList.add(Pair(id, name))
            }
        } else if (seasonsJsonObject != null) {
            val keys = seasonsJsonObject.keys()
            val sortedKeys = mutableListOf<String>()
            while (keys.hasNext()) { sortedKeys.add(keys.next()) }
            sortedKeys.sortedWith(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE }).forEach { key ->
                val seasonObj = seasonsJsonObject.optJSONObject(key)
                if (seasonObj != null) {
                    val id = listOf("id", "season_id", "series_number", "season_number")
                        .map { k -> seasonObj.optString(k).trim() }
                        .firstOrNull { it.isNotEmpty() && it != "null" } ?: key
                    val name = listOf("name", "title")
                        .map { k -> seasonObj.optString(k).trim() }
                        .firstOrNull { it.isNotEmpty() && it != "null" } ?: "Saison $id"
                    seasonsList.add(Pair(id, name))
                } else {
                    seasonsList.add(Pair(key, "Saison $key"))
                }
            }
        } else {
            val seriesJsonArray = finalDataObj.optJSONArray("series") ?: finalDataObj.optJSONArray("list")
            val seriesJsonObject = finalDataObj.optJSONObject("series") ?: finalDataObj.optJSONObject("list")
            if (seriesJsonArray != null && seriesJsonArray.length() > 0) {
                for (i in 0 until seriesJsonArray.length()) {
                    val itemObj = seriesJsonArray.optJSONObject(i) ?: continue
                    val id = listOf("id", "season_id", "series_number", "season_number")
                        .map { key -> itemObj.optString(key).trim() }
                        .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${i + 1}"
                    val name = listOf("name", "title")
                        .map { key -> itemObj.optString(key).trim() }
                        .firstOrNull { it.isNotEmpty() && it != "null" } ?: "Saison $id"
                    seasonsList.add(Pair(id, name))
                }
            } else if (seriesJsonObject != null) {
                val keys = seriesJsonObject.keys()
                val sortedKeys = mutableListOf<String>()
                while (keys.hasNext()) { sortedKeys.add(keys.next()) }
                sortedKeys.sortedWith(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE }).forEach { key ->
                    val itemObj = seriesJsonObject.optJSONObject(key)
                    if (itemObj != null) {
                        val id = listOf("id", "season_id", "series_number", "season_number")
                            .map { k -> itemObj.optString(k).trim() }
                            .firstOrNull { it.isNotEmpty() && it != "null" } ?: key
                        val name = listOf("name", "title")
                            .map { k -> itemObj.optString(k).trim() }
                            .firstOrNull { it.isNotEmpty() && it != "null" } ?: "Saison $id"
                        seasonsList.add(Pair(id, name))
                    } else {
                        seasonsList.add(Pair(key, "Saison $key"))
                    }
                }
            }
        }
        return seasonsList
    }

    private fun parseInlineEpisodesForSeason(finalDataObj: JSONObject?, targetSeasonId: String, seriesId: String, list: MutableList<EpisodeItem>) {
        if (finalDataObj == null) return
        val seasonsJsonArray = finalDataObj.optJSONArray("seasons")
        val seasonsJsonObject = finalDataObj.optJSONObject("seasons")

        if (seasonsJsonArray != null && seasonsJsonArray.length() > 0) {
            for (i in 0 until seasonsJsonArray.length()) {
                val seasonObj = seasonsJsonArray.optJSONObject(i) ?: continue
                val id = listOf("id", "season_id", "series_number", "season_number")
                    .map { key -> seasonObj.optString(key).trim() }
                    .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${i + 1}"
                if (id == targetSeasonId) {
                    parseStalkerSeasonObject(seasonObj, seriesId, targetSeasonId, list)
                    return
                }
            }
        } else if (seasonsJsonObject != null) {
            val keys = seasonsJsonObject.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val seasonObj = seasonsJsonObject.optJSONObject(key)
                if (seasonObj != null) {
                    val id = listOf("id", "season_id", "series_number", "season_number")
                        .map { k -> seasonObj.optString(k).trim() }
                        .firstOrNull { it.isNotEmpty() && it != "null" } ?: key
                    if (id == targetSeasonId) {
                        parseStalkerSeasonObject(seasonObj, seriesId, targetSeasonId, list)
                        return
                    }
                } else if (key == targetSeasonId) {
                    parseStalkerSeasonObject(JSONObject(), seriesId, targetSeasonId, list)
                    return
                }
            }
        } else {
            val seriesJsonArray = finalDataObj.optJSONArray("series") ?: finalDataObj.optJSONArray("list")
            val seriesJsonObject = finalDataObj.optJSONObject("series") ?: finalDataObj.optJSONObject("list")
            if (seriesJsonArray != null && seriesJsonArray.length() > 0) {
                for (i in 0 until seriesJsonArray.length()) {
                    val itemObj = seriesJsonArray.optJSONObject(i) ?: continue
                    val id = listOf("id", "season_id", "series_number", "season_number")
                        .map { key -> itemObj.optString(key).trim() }
                        .firstOrNull { it.isNotEmpty() && it != "null" } ?: "${i + 1}"
                    if (id == targetSeasonId) {
                        parseStalkerSeasonObject(itemObj, seriesId, targetSeasonId, list)
                        return
                    }
                }
            } else if (seriesJsonObject != null) {
                val keys = seriesJsonObject.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val itemObj = seriesJsonObject.optJSONObject(key)
                    if (itemObj != null) {
                        val id = listOf("id", "season_id", "series_number", "season_number")
                            .map { k -> itemObj.optString(k).trim() }
                            .firstOrNull { it.isNotEmpty() && it != "null" } ?: key
                        if (id == targetSeasonId) {
                            parseStalkerSeasonObject(itemObj, seriesId, targetSeasonId, list)
                            return
                        }
                    }
                }
            }
        }
    }

    /**
     * Helper specifically for Stalker dynamic play url resolution
     */
    suspend fun onStalkerEpisodeClicked(playlistId: Long, episodeUrl: String): String? = withContext(Dispatchers.IO) {
        val playlist = repository.getPlaylistById(playlistId) ?: return@withContext null
        if (!playlist.type.equals("Stalker", ignoreCase = true)) return@withContext null
        val mac = playlist.macAddress ?: ""
        val formattedMac = formatMacAddress(mac)
        val handshakeResult = apiService.performHandshake(playlist.url, formattedMac)
        val token = handshakeResult.token
        val usedMac = handshakeResult.usedMac
        
        val resolved = apiService.resolveStalkerStream(playlist.url, usedMac, episodeUrl, "Series")
        if (resolved != null) {
            val deviceFields = generateStalkerDeviceFields(usedMac)
            val devId = deviceFields["device_id"] ?: ""
            var devId2 = deviceFields["device_id2"] ?: ""
            if (playlist.url.contains("deirnet.ps", ignoreCase = true)) {
                devId2 = ""
            }
            val sig = deviceFields["signature"] ?: ""
            val serial = deviceFields["serial_number"] ?: ""
            
            val customIp = (playlist.customIp?.trim() ?: playlist.ipAddress?.trim() ?: "").trim()
            val isValidIpv4 = { ip: String ->
                val regex = """^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$""".toRegex()
                regex.matches(ip)
            }
            val hasCustomIp = customIp.isNotEmpty() && isValidIpv4(customIp)

            val userCardVal = if (hasCustomIp) {
                "mac=$usedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial; ip=$customIp"
            } else {
                "mac=$usedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial"
            }
            
            val headers = mutableMapOf(
                "User-Agent" to "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
                "X-User-Agent" to "Model: MAG250; Link: WiFi",
                "X-User-Card" to userCardVal,
                "Cookie" to "mac=$usedMac; stb_lang=en; timezone=Europe/Paris; token=$token",
                "Referer" to if (playlist.url.endsWith("/")) playlist.url else "${playlist.url}/",
                "Accept" to "*/*",
                "Authorization" to "Bearer $token"
            )
            if (hasCustomIp) {
                headers["X-Forwarded-For"] = customIp
                headers["Client-IP"] = customIp
                headers["X-Real-IP"] = customIp
                headers["X-Forwarded-Host"] = customIp
            }
            com.example.data.resolveRedirects(resolved, headers)
        } else {
            null
        }
    }

    // Favorites
    private val _isCurrentChannelFavorite = MutableStateFlow(false)
    val isCurrentChannelFavorite: StateFlow<Boolean> = _isCurrentChannelFavorite.asStateFlow()

    private suspend fun checkFavoriteState(channel: ChannelItem) {
        _isCurrentChannelFavorite.value = repository.isFavorite(channel.playlistId, channel.streamUrl)
    }

    fun toggleFavorite(channel: ChannelItem) {
        viewModelScope.launch {
            val isFav = repository.isFavorite(channel.playlistId, channel.streamUrl)
            if (isFav) {
                repository.removeFavorite(channel.playlistId, channel.streamUrl)
                _isCurrentChannelFavorite.value = false
            } else {
                repository.addFavorite(channel.playlistId, channel.name, channel.streamUrl)
                _isCurrentChannelFavorite.value = true
            }
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
            if (_selectedPlaylist.value?.id == playlistId) {
                _selectedPlaylist.value = null
                _channels.value = emptyList()
                _categories.value = emptyList()
            }
        }
    }

    fun togglePlaylistActive(playlist: PlaylistItem) {
        val nextActive = !playlist.isActive
        viewModelScope.launch(Dispatchers.IO) {
            repository.updatePlaylistActiveState(playlist.id, nextActive)
            if (!nextActive && _selectedPlaylist.value?.id == playlist.id) {
                withContext(Dispatchers.Main) {
                    _selectedPlaylist.value = null
                    _channels.value = emptyList()
                    _categories.value = emptyList()
                }
            }
        }
    }

    fun resetAllPlaylists() {
        viewModelScope.launch {
            repository.deleteAllPlaylists()
            _selectedPlaylist.value = null
            _channels.value = emptyList()
            _categories.value = emptyList()
            _playlistSummaries.value = emptyMap()
        }
    }

    fun updateAndReimportPlaylist(playlist: PlaylistItem) {
        backgroundScope.launch(Dispatchers.IO) {
            _importState.value = ImportState.Loading("Mise à jour et ré-importation de la playlist '${playlist.name}'...")
            try {
                repository.updatePlaylist(playlist)
                repository.deleteChannelsByPlaylist(playlist.id)
                
                when (playlist.type) {
                    "M3U" -> {
                        val request = Request.Builder().url(playlist.url).build()
                        okHttpClient.newCall(request).execute().use { response ->
                            if (!response.isSuccessful) throw Exception("Erreur HTTP ${response.code}")
                            val body = response.body ?: throw Exception("Réponse vide.")
                            val count = body.charStream().use { reader ->
                                repository.importPlaylistData(playlist.id, reader, "m3u")
                            }
                            _importState.value = ImportState.Success("$count chaînes importées avec succès !")
                        }
                    }
                    "Xtream" -> {
                        val cleanBase = if (playlist.url.endsWith("/")) playlist.url.substring(0, playlist.url.length - 1) else playlist.url
                        val (loadLive, loadMovies, loadSeries) = getPlaylistLoadSettings(playlist.id)
                        val count = importXtreamData(
                            playlist.id, 
                            cleanBase, 
                            playlist.username ?: "", 
                            playlist.password ?: "",
                            loadLive,
                            loadMovies,
                            loadSeries
                        ) { status ->
                            _importState.value = ImportState.Loading(status)
                        }
                        _importState.value = ImportState.Success("$count chaînes, films et séries importés avec succès !")
                    }
                    "Stalker" -> {
                        val (loadLive, loadMovies, loadSeries) = getPlaylistLoadSettings(playlist.id)
                        val count = stalkerRepository.reimportStalkerPortalData(
                            playlist.id, 
                            playlist.url, 
                            playlist.macAddress ?: "",
                            loadLive,
                            loadMovies,
                            loadSeries
                        ) { status ->
                            _importState.value = ImportState.Loading(status)
                        }
                        _importState.value = ImportState.Success("$count chaînes importées avec succès !")
                    }
                }
                savePlaylistLastUpdated(playlist.id)
                refreshSummaries()
                if (_selectedPlaylist.value?.id == playlist.id) {
                    withContext(Dispatchers.Main) {
                        selectPlaylist(playlist)
                    }
                }
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error reimporting: ${e.message}", e)
                _importState.value = ImportState.Error("Erreur lors de la ré-importation : ${e.message}")
            }
        }
    }

    // Import functions
    fun importM3uPlaylist(name: String, url: String) {
        _importState.value = ImportState.Loading("Téléchargement et analyse du fichier M3U...")
        currentImportJob = backgroundScope.launch(Dispatchers.IO) {
            try {
                var cleanUrl = url.trim()
                if (!cleanUrl.startsWith("http://", ignoreCase = true) && 
                    !cleanUrl.startsWith("https://", ignoreCase = true) && 
                    !cleanUrl.startsWith("file://", ignoreCase = true)) {
                    cleanUrl = "http://$cleanUrl"
                }
                val request = Request.Builder()
                    .url(cleanUrl)
                    .header("User-Agent", "VLC/3.0.18 LibVLC/3.0.18")
                    .header("Accept", "*/*")
                    .header("Accept-Language", "en-US,fr-FR;q=0.9,en;q=0.8")
                    .header("Connection", "keep-alive")
                    .build()
                getUnsafeOkHttpClientWithoutInterceptor().newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw Exception("Impossible de récupérer le fichier M3U : Code HTTP ${response.code}")
                    val body = response.body ?: throw Exception("Le serveur a retourné une réponse vide.")
                    
                    val playlistId = repository.insertPlaylist(
                        PlaylistItem(name = name, type = "M3U", url = cleanUrl)
                    )
                    
                    // Memory-efficient parse straight from stream!
                    val count = body.charStream().use { reader ->
                        repository.importPlaylistData(playlistId, reader, "m3u")
                    }
                    
                    savePlaylistLastUpdated(playlistId)
                    _importState.value = ImportState.Success("$count chaînes importées avec succès !")
                    refreshSummaries()
                    
                    // Trigger select
                    val newPlaylist = PlaylistItem(id = playlistId, name = name, type = "M3U", url = cleanUrl)
                    _selectedPlaylist.value = newPlaylist
                    selectPlaylist(newPlaylist)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                // Arrêt demandé : on garde ce qui est déjà inséré en base (M3U importé en flux).
                _importState.value = ImportState.Success("Import M3U arrêté : les chaînes déjà lues sont conservées.")
                refreshSummaries()
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error importing M3U: ${e.message}", e)
                _importState.value = ImportState.Error(e.message ?: "M3U Import Failed")
            }
        }
    }

    fun getPlaylistLoadSettings(playlistId: Long): Triple<Boolean, Boolean, Boolean> {
        val context = getApplication<android.app.Application>()
        val prefs = context.getSharedPreferences("playlist_settings", android.content.Context.MODE_PRIVATE)
        val loadLive = prefs.getBoolean("load_live_$playlistId", true)
        val loadMovies = prefs.getBoolean("load_movies_$playlistId", true)
        val loadSeries = prefs.getBoolean("load_series_$playlistId", true)
        return Triple(loadLive, loadMovies, loadSeries)
    }

    fun savePlaylistLoadSettings(playlistId: Long, loadLive: Boolean, loadMovies: Boolean, loadSeries: Boolean) {
        val context = getApplication<android.app.Application>()
        val prefs = context.getSharedPreferences("playlist_settings", android.content.Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean("load_live_$playlistId", loadLive)
            .putBoolean("load_movies_$playlistId", loadMovies)
            .putBoolean("load_series_$playlistId", loadSeries)
            .apply()
    }

    fun importXtreamPlaylist(
        name: String, 
        baseUrl: String, 
        username: String, 
        password: String,
        loadLive: Boolean = true,
        loadMovies: Boolean = true,
        loadSeries: Boolean = true
    ) {
        _importState.value = ImportState.Loading("Authenticating with Xtream Codes...")
        currentImportJob = backgroundScope.launch(Dispatchers.IO) {
            try {
                // Parse and build proper Xtream URL
                var cleanBase = baseUrl.trim()
                if (!cleanBase.startsWith("http://", ignoreCase = true) && !cleanBase.startsWith("https://", ignoreCase = true)) {
                    cleanBase = "http://$cleanBase"
                }
                if (cleanBase.endsWith("/player_api.php", ignoreCase = true)) {
                    cleanBase = cleanBase.substring(0, cleanBase.length - "/player_api.php".length)
                }
                if (cleanBase.endsWith("/c", ignoreCase = true)) {
                    cleanBase = cleanBase.substring(0, cleanBase.length - "/c".length)
                }
                if (cleanBase.endsWith("/")) {
                    cleanBase = cleanBase.substring(0, cleanBase.length - 1)
                }
                val authUrl = "$cleanBase/player_api.php?username=$username&password=$password"
                
                val request = Request.Builder()
                    .url(authUrl)
                    .header("User-Agent", "IPTVSmartersPro")
                    .header("Accept", "*/*")
                    .header("Connection", "keep-alive")
                    .build()
                val client = getUnsafeOkHttpClientWithoutInterceptor()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw Exception("Xtream authentication failed: HTTP ${response.code}")
                    val body = response.body?.string() ?: ""
                    val jsonObj = try { JSONObject(body) } catch (e: Exception) { null }
                    
                    val auth = jsonObj?.optJSONObject("user_info")
                    val isAuthValid = auth != null && auth.optString("auth").trim() != "0" && !auth.optString("status").equals("Disabled", ignoreCase = true) && !auth.optString("status").equals("Banned", ignoreCase = true)
                    if (!isAuthValid && jsonObj?.optString("status") != "Active" && jsonObj?.optInt("auth", -1) != 1) {
                        if (auth != null && auth.optString("auth").trim() == "0") {
                            throw Exception("Invalid Xtream credentials or authentication denied.")
                        }
                    }
                    
                    val playlistId = repository.insertPlaylist(
                        PlaylistItem(
                            name = name,
                            type = "Xtream",
                            url = cleanBase,
                            username = username,
                            password = password
                        )
                    )
                    
                    val count = importXtreamData(
                        playlistId, 
                        cleanBase, 
                        username, 
                        password,
                        loadLive,
                        loadMovies,
                        loadSeries
                    ) { status ->
                        _importState.value = ImportState.Loading(status)
                    }
                    
                    savePlaylistLoadSettings(playlistId, loadLive, loadMovies, loadSeries)
                    savePlaylistLastUpdated(playlistId)
                    _importState.value = ImportState.Success("Imported $count Xtream channels, movies and series!")
                    val newPlaylist = PlaylistItem(id = playlistId, name = name, type = "Xtream", url = cleanBase)
                    _selectedPlaylist.value = newPlaylist
                    selectPlaylist(newPlaylist)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                _importState.value = ImportState.Success("Import Xtream arrêté : les sections déjà téléchargées sont conservées.")
                refreshSummaries()
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Xtream import error: ${e.message}", e)
                _importState.value = ImportState.Error(e.message ?: "Xtream Import Failed")
            }
        }
    }

    private suspend fun importXtreamData(
        playlistId: Long,
        cleanBase: String,
        username: String,
        password: String,
        loadLive: Boolean = true,
        loadMovies: Boolean = true,
        loadSeries: Boolean = true,
        onStatusUpdate: (String) -> Unit
    ): Int {
        onStatusUpdate("Chargement des catégories Xtream...")
        val baseApiUrl = "$cleanBase/player_api.php?username=$username&password=$password"
        val liveCats = if (loadLive) fetchXtreamCategories(okHttpClient, baseApiUrl, "get_live_categories") else emptyMap()
        val vodCats = if (loadMovies) fetchXtreamCategories(okHttpClient, baseApiUrl, "get_vod_categories") else emptyMap()
        val seriesCats = if (loadSeries) fetchXtreamCategories(okHttpClient, baseApiUrl, "get_series_categories") else emptyMap()

        val channelsList = java.util.Collections.synchronizedList(mutableListOf<ChannelItem>())

        kotlinx.coroutines.coroutineScope {
            val liveDeferred: kotlinx.coroutines.Deferred<List<ChannelItem>>? = if (loadLive) {
                async(Dispatchers.IO) {
                    try {
                        onStatusUpdate("Téléchargement des chaînes Live Xtream...")
                        val liveUrl = "$baseApiUrl&action=get_live_streams"
                        val liveRequest = Request.Builder().url(liveUrl).build()
                        okHttpClient.newCall(liveRequest).execute().use { liveResponse ->
                            if (liveResponse.isSuccessful) {
                                val liveBody = liveResponse.body?.string() ?: ""
                                val arr = try { org.json.JSONArray(liveBody) } catch (t: Throwable) { null }
                                if (arr != null) {
                                    val list = ArrayList<ChannelItem>(arr.length())
                                    for (i in 0 until arr.length()) {
                                        val obj = arr.optJSONObject(i) ?: continue
                                        val streamId = obj.optString("stream_id")
                                        val streamUrl = "$cleanBase/live/$username/$password/$streamId.ts"
                                        val categoryId = obj.optString("category_id")
                                        val groupName = liveCats[categoryId] ?: obj.optString("category_name").ifEmpty { "Général" }
                                        val tvArchive = obj.optInt("tv_archive", 0)
                                        val tvArchiveDuration = obj.optInt("tv_archive_duration", 0)
                                        val hasCatchup = tvArchive > 0 || tvArchiveDuration > 0 || obj.optInt("archive", 0) > 0
                                        val catchupDays = if (tvArchiveDuration > 0) tvArchiveDuration / 24 else if (hasCatchup) 3 else 0
                                        val archiveHours = if (tvArchiveDuration > 0) tvArchiveDuration else if (hasCatchup) 72 else 0

                                        list.add(
                                            ChannelItem(
                                                playlistId = playlistId,
                                                name = obj.optString("name"),
                                                logoUrl = obj.optString("stream_icon"),
                                                streamUrl = streamUrl,
                                                groupName = groupName,
                                                type = "Live",
                                                hasCatchup = hasCatchup,
                                                catchupDurationDays = catchupDays,
                                                tvArchiveDuration = archiveHours,
                                                stalkerId = streamId
                                            )
                                        )
                                    }
                                    list
                                } else emptyList()
                            } else emptyList()
                        }
                    } catch (e: Throwable) {
                        Log.e("IptvViewModel", "Error fetching Xtream live streams: ${e.message}")
                        emptyList()
                    }
                }
            } else null

            val moviesDeferred: kotlinx.coroutines.Deferred<List<ChannelItem>>? = if (loadMovies) {
                async(Dispatchers.IO) {
                    try {
                        onStatusUpdate("Téléchargement des Films VOD Xtream...")
                        val vodUrl = "$baseApiUrl&action=get_vod_streams"
                        val vodRequest = Request.Builder().url(vodUrl).build()
                        okHttpClient.newCall(vodRequest).execute().use { vodResponse ->
                            if (vodResponse.isSuccessful) {
                                val vodBody = vodResponse.body?.string() ?: ""
                                val arr = try { org.json.JSONArray(vodBody) } catch (t: Throwable) { null }
                                if (arr != null) {
                                    val list = ArrayList<ChannelItem>(arr.length())
                                    for (i in 0 until arr.length()) {
                                        val obj = arr.optJSONObject(i) ?: continue
                                        val streamId = obj.optString("stream_id")
                                        val ext = obj.optString("container_extension", "mp4").ifEmpty { "mp4" }
                                        val streamUrl = "$cleanBase/movie/$username/$password/$streamId.$ext"
                                        val categoryId = obj.optString("category_id")
                                        val groupName = vodCats[categoryId] ?: "Films VOD"
                                        list.add(
                                            ChannelItem(
                                                playlistId = playlistId,
                                                name = obj.optString("name"),
                                                logoUrl = obj.optString("stream_icon"),
                                                streamUrl = streamUrl,
                                                groupName = groupName,
                                                type = "Movie"
                                            )
                                        )
                                    }
                                    list
                                } else emptyList()
                            } else emptyList()
                        }
                    } catch (e: Throwable) {
                        Log.e("IptvViewModel", "Error fetching Xtream movies: ${e.message}")
                        emptyList()
                    }
                }
            } else null

            val seriesDeferred: kotlinx.coroutines.Deferred<List<ChannelItem>>? = if (loadSeries) {
                async(Dispatchers.IO) {
                    try {
                        onStatusUpdate("Téléchargement des Séries Xtream...")
                        val seriesUrl = "$baseApiUrl&action=get_series"
                        val seriesRequest = Request.Builder().url(seriesUrl).build()
                        okHttpClient.newCall(seriesRequest).execute().use { seriesResponse ->
                            if (seriesResponse.isSuccessful) {
                                val seriesBody = seriesResponse.body?.string() ?: ""
                                val arr = try { org.json.JSONArray(seriesBody) } catch (t: Throwable) { null }
                                if (arr != null) {
                                    val list = ArrayList<ChannelItem>(arr.length())
                                    for (i in 0 until arr.length()) {
                                        val obj = arr.optJSONObject(i) ?: continue
                                        val seriesId = obj.optString("series_id")
                                        val streamUrl = "xtream://series/$seriesId"
                                        val categoryId = obj.optString("category_id")
                                        val groupName = seriesCats[categoryId] ?: "Séries TV"
                                        list.add(
                                            ChannelItem(
                                                playlistId = playlistId,
                                                name = obj.optString("name"),
                                                logoUrl = obj.optString("cover"),
                                                streamUrl = streamUrl,
                                                groupName = groupName,
                                                type = "Series"
                                            )
                                        )
                                    }
                                    list
                                } else emptyList()
                            } else emptyList()
                        }
                    } catch (e: Throwable) {
                        Log.e("IptvViewModel", "Error fetching Xtream series: ${e.message}")
                        emptyList()
                    }
                }
            } else null

            liveDeferred?.await()?.let { channelsList.addAll(it) }
            moviesDeferred?.await()?.let { channelsList.addAll(it) }
            seriesDeferred?.await()?.let { channelsList.addAll(it) }
        }

        if (channelsList.isNotEmpty()) {
            repository.deleteChannelsByPlaylist(playlistId)
            repository.insertChannels(channelsList)
        }
        return channelsList.size
    }

    private fun fetchXtreamCategories(client: okhttp3.OkHttpClient, baseApiUrl: String, action: String): Map<String, String> {
        val categoryMap = mutableMapOf<String, String>()
        try {
            val url = "$baseApiUrl&action=$action"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val arr = try { org.json.JSONArray(body) } catch (t: Throwable) { null }
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val obj = arr.optJSONObject(i) ?: continue
                            val id = obj.optString("category_id")
                            val name = obj.optString("category_name")
                            if (id.isNotEmpty() && name.isNotEmpty()) {
                                categoryMap[id] = name
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("IptvViewModel", "Error fetching Xtream categories for action $action: ${e.message}")
        }
        return categoryMap
    }

    fun importStalkerPortal(
        name: String, 
        portalUrl: String, 
        macAddress: String, 
        hideDns: Boolean,
        ipAddress: String? = null,
        loadLive: Boolean = true,
        loadMovies: Boolean = true,
        loadSeries: Boolean = true
    ) {
        _importState.value = ImportState.Loading("Préparation de l'importation Stalker...")
        currentImportJob = backgroundScope.launch {
            try {
                val effectiveName = if (name.isBlank()) {
                    val existing = playlists.value.map { it.name }
                    com.example.data.extractStalkerPlaylistNameFromUrl(portalUrl, existing)
                } else {
                    name.trim()
                }
                val playlistId = stalkerRepository.importStalkerPortal(
                    playlistName = effectiveName,
                    portalUrl = portalUrl,
                    macAddress = macAddress,
                    hideDns = hideDns,
                    ipAddress = ipAddress,
                    loadLive = loadLive,
                    loadMovies = loadMovies,
                    loadSeries = loadSeries,
                    onStatusUpdate = { status ->
                        _importState.value = ImportState.Loading(status)
                    }
                )
                
                savePlaylistLoadSettings(playlistId, loadLive, loadMovies, loadSeries)
                savePlaylistLastUpdated(playlistId)
                val dbPlaylist = repository.getPlaylistById(playlistId)
                val activeMac = dbPlaylist?.macAddress ?: ""
                _importState.value = ImportState.Success("Portail Stalker importé avec succès! (MAC active: $activeMac)")
                
                if (dbPlaylist != null) {
                    _selectedPlaylist.value = dbPlaylist
                    selectPlaylist(dbPlaylist)
                }
            } catch (e: com.example.data.StalkerRepository.ImportStoppedException) {
                finishStoppedImport(e.playlistId, e.savedCount)
            } catch (e: kotlinx.coroutines.CancellationException) {
                _importState.value = ImportState.Idle
                throw e
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Stalker import error: ${e.message}", e)
                _importState.value = ImportState.Error(e.message ?: "Stalker Portal Import Failed")
            }
        }
    }

    fun testAndImportBulkMacs(portalUrl: String, rawMacsText: String) {
        val macs = extractAndNormalizeMacs(rawMacsText)
        if (macs.isEmpty()) {
            _bulkMacTestProgress.value = BulkMacTestProgress(
                statusText = "Aucune adresse MAC valide trouvée."
            )
            return
        }

        bulkMacTestJob?.cancel()
        _bulkMacTestProgress.value = BulkMacTestProgress(
            isTesting = true,
            totalCount = macs.size,
            currentIndex = 0,
            currentMac = "",
            successCount = 0,
            failureCount = 0,
            isCompleted = false,
            results = emptyList(),
            statusText = "Démarrage des tests..."
        )

        bulkMacTestJob = backgroundScope.launch {
            ApiService.resetHandshakeCounter()
            val resultsList = mutableListOf<MacTestItemResult>()

            for ((index, mac) in macs.withIndex()) {
                if (!coroutineContext.isActive) break

                _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(
                    currentIndex = index + 1,
                    currentMac = mac,
                    statusText = "Test de la MAC $mac (handshake + get_profile)..."
                )

                try {
                    // 2a. Tente UNIQUEMENT la connexion (handshake + get_profile) avec cette URL de portail + cette MAC
                    val token = apiService.authenticateStalker(mac, portalUrl, null)

                    if (token.isNotEmpty()) {
                        // 2b. Vérifier si une playlist avec ce portail et cette MAC existe déjà
                        val cleanPortal = portalUrl.trim().trimEnd('/')
                        val existing = playlists.value.find {
                            it.type.equals("Stalker", ignoreCase = true) &&
                            it.url.trimEnd('/').equals(cleanPortal, ignoreCase = true) &&
                            it.macAddress?.replace("-", ":")?.equals(mac, ignoreCase = true) == true
                        }

                        val res = MacTestItemResult(
                            mac = mac,
                            success = true,
                            liveChannelsCount = 0,
                            playlistId = existing?.id,
                            isCreated = existing != null,
                            playlistName = existing?.name
                        )
                        resultsList.add(res)

                        _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(
                            successCount = _bulkMacTestProgress.value.successCount + 1,
                            results = resultsList.toList()
                        )
                    } else {
                        val res = MacTestItemResult(
                            mac = mac,
                            success = false,
                            errorMessage = "Échec d'authentification (Token vide)"
                        )
                        resultsList.add(res)

                        _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(
                            failureCount = _bulkMacTestProgress.value.failureCount + 1,
                            results = resultsList.toList()
                        )
                    }
                } catch (e: Exception) {
                    Log.e("IptvViewModel", "Bulk MAC test failed for MAC $mac: ${e.message}")
                    val reason = e.message ?: "Échec de connexion"
                    val res = MacTestItemResult(
                        mac = mac,
                        success = false,
                        errorMessage = reason
                    )
                    resultsList.add(res)

                    _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(
                        failureCount = _bulkMacTestProgress.value.failureCount + 1,
                        results = resultsList.toList()
                    )
                }

                // 2e. Court délai (500ms) entre chaque tentative de MAC pour éviter de spammer le serveur
                if (index < macs.size - 1 && coroutineContext.isActive) {
                    kotlinx.coroutines.delay(500)
                }
            }

            _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(
                isTesting = false,
                isCompleted = true,
                statusText = "Test terminé (${_bulkMacTestProgress.value.successCount} MAC retenues valables)."
            )

            refreshSummaries()
        }
    }

    fun createPlaylistsForValidMacs(
        portalUrl: String,
        macs: List<String>,
        customBaseName: String? = null,
        onCompleted: ((Int) -> Unit)? = null
    ) {
        if (macs.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val cleanPortalUrl = portalUrl.trim()
            val currentPlaylists = playlists.value
            val existingNames = currentPlaylists.map { it.name }
            val baseName = if (!customBaseName.isNullOrBlank()) {
                customBaseName.trim()
            } else {
                com.example.data.extractStalkerPlaylistNameFromUrl(cleanPortalUrl, existingNames)
            }

            val updatedResults = _bulkMacTestProgress.value.results.toMutableList()
            var createdCount = 0

            for (mac in macs) {
                val existing = currentPlaylists.find {
                    it.type.equals("Stalker", ignoreCase = true) &&
                    it.url.trimEnd('/').equals(cleanPortalUrl.trimEnd('/'), ignoreCase = true) &&
                    it.macAddress?.replace("-", ":")?.equals(mac, ignoreCase = true) == true
                }

                val id: Long
                val name: String
                if (existing != null) {
                    id = existing.id
                    name = existing.name
                } else {
                    val plName = "$baseName ($mac)"
                    id = repository.insertPlaylist(
                        PlaylistItem(
                            name = plName,
                            type = "Stalker",
                            url = cleanPortalUrl,
                            macAddress = mac,
                            ipAddress = null,
                            customIp = null,
                            isActive = true
                        )
                    )
                    createdCount++
                    name = plName
                }

                val idx = updatedResults.indexOfFirst { it.mac.equals(mac, ignoreCase = true) }
                if (idx != -1) {
                    updatedResults[idx] = updatedResults[idx].copy(
                        isCreated = true,
                        playlistId = id,
                        playlistName = name
                    )
                }
            }

            _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(
                results = updatedResults
            )
            refreshSummaries()
            withContext(Dispatchers.Main) {
                onCompleted?.invoke(createdCount)
            }
        }
    }

    fun loadSmartPlaylistForMac(
        portalUrl: String,
        mac: String,
        customBaseName: String? = null,
        loadLive: Boolean = true,
        loadMovies: Boolean = false,
        loadSeries: Boolean = false,
        onSuccess: ((PlaylistItem, Int) -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val cleanPortalUrl = portalUrl.trim()
            try {
                // Marquer en cours de chargement dans l'UI
                val currentResults = _bulkMacTestProgress.value.results.toMutableList()
                val idx = currentResults.indexOfFirst { it.mac.equals(mac, ignoreCase = true) }
                if (idx != -1) {
                    currentResults[idx] = currentResults[idx].copy(isLoadingChannels = true)
                    _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(results = currentResults)
                }

                // 1. Trouver ou créer la playlist correspondante
                val currentPlaylists = playlists.value
                val existing = currentPlaylists.find {
                    it.type.equals("Stalker", ignoreCase = true) &&
                    it.url.trimEnd('/').equals(cleanPortalUrl.trimEnd('/'), ignoreCase = true) &&
                    it.macAddress?.replace("-", ":")?.equals(mac, ignoreCase = true) == true
                }

                val playlistId: Long
                val playlistName: String
                if (existing != null) {
                    playlistId = existing.id
                    playlistName = existing.name
                } else {
                    val base = if (!customBaseName.isNullOrBlank()) {
                        customBaseName.trim()
                    } else {
                        com.example.data.extractStalkerPlaylistNameFromUrl(cleanPortalUrl, currentPlaylists.map { it.name })
                    }
                    playlistName = "$base ($mac)"
                    playlistId = repository.insertPlaylist(
                        PlaylistItem(
                            name = playlistName,
                            type = "Stalker",
                            url = cleanPortalUrl,
                            macAddress = mac,
                            isActive = true
                        )
                    )
                }

                // 2. Importer intelligemment les chaînes (Par défaut uniquement Live TV pour un chargement ultra rapide)
                val count = stalkerRepository.reimportStalkerPortalData(
                    playlistId = playlistId,
                    portalUrl = cleanPortalUrl,
                    macAddress = mac,
                    loadLive = loadLive,
                    loadMovies = loadMovies,
                    loadSeries = loadSeries,
                    onStatusUpdate = { status ->
                        _importState.value = ImportState.Loading("[$mac] $status")
                    }
                )

                savePlaylistLastUpdated(playlistId)
                savePlaylistLoadSettings(playlistId, loadLive = loadLive, loadMovies = loadMovies, loadSeries = loadSeries)
                refreshSummaries()

                val afterResults = _bulkMacTestProgress.value.results.toMutableList()
                val afterIdx = afterResults.indexOfFirst { it.mac.equals(mac, ignoreCase = true) }
                if (afterIdx != -1) {
                    afterResults[afterIdx] = afterResults[afterIdx].copy(
                        isCreated = true,
                        playlistId = playlistId,
                        playlistName = playlistName,
                        isLoadingChannels = false,
                        channelsLoadedCount = count,
                        liveChannelsCount = count
                    )
                    _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(results = afterResults)
                }

                val pl = repository.getPlaylistById(playlistId) ?: PlaylistItem(
                    id = playlistId,
                    name = playlistName,
                    type = "Stalker",
                    url = cleanPortalUrl,
                    macAddress = mac
                )

                withContext(Dispatchers.Main) {
                    _selectedPlaylist.value = pl
                    selectPlaylist(pl)
                    val contentDescription = if (loadLive && !loadMovies && !loadSeries) "Live TV uniquement" else "Direct + Médias"
                    _importState.value = ImportState.Success("Playlist '$playlistName' chargée avec succès ($count chaînes, $contentDescription) !")
                    onSuccess?.invoke(pl, count)
                }
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error in loadSmartPlaylistForMac for $mac: ${e.message}", e)
                val currentResults = _bulkMacTestProgress.value.results.toMutableList()
                val idx = currentResults.indexOfFirst { it.mac.equals(mac, ignoreCase = true) }
                if (idx != -1) {
                    currentResults[idx] = currentResults[idx].copy(isLoadingChannels = false)
                    _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(results = currentResults)
                }
                withContext(Dispatchers.Main) {
                    _importState.value = ImportState.Error("Erreur chargement ($mac) : ${e.message}")
                    onError?.invoke(e.message ?: "Erreur de chargement")
                }
            }
        }
    }

    fun loadAllSelectedPlaylistsForMacs(
        portalUrl: String,
        macs: List<String>,
        customBaseName: String? = null,
        loadLive: Boolean = true,
        loadMovies: Boolean = false,
        loadSeries: Boolean = false,
        onFinished: ((Int) -> Unit)? = null
    ) {
        if (macs.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            var countSuccess = 0
            for (mac in macs) {
                try {
                    loadSmartPlaylistForMac(
                        portalUrl = portalUrl,
                        mac = mac,
                        customBaseName = customBaseName,
                        loadLive = loadLive,
                        loadMovies = loadMovies,
                        loadSeries = loadSeries
                    )
                    countSuccess++
                    kotlinx.coroutines.delay(500)
                } catch (e: Exception) {
                    Log.e("IptvViewModel", "Batch load error for MAC $mac: ${e.message}")
                }
            }
            withContext(Dispatchers.Main) {
                onFinished?.invoke(countSuccess)
            }
        }
    }

    fun cancelBulkMacTest() {
        bulkMacTestJob?.cancel()
        _bulkMacTestProgress.value = _bulkMacTestProgress.value.copy(
            isTesting = false,
            statusText = "Test annulé par l'utilisateur."
        )
    }

    fun resetBulkMacTest() {
        bulkMacTestJob?.cancel()
        _bulkMacTestProgress.value = BulkMacTestProgress()
    }

    // --- RECORDINGS ACTIONS ---
    private var recordingJob: kotlinx.coroutines.Job? = null
    private var recordingTimerJob: kotlinx.coroutines.Job? = null
    private var currentRecordingUri: Uri? = null

    // Requirement 2: Dedicated OkHttpClient for recording live streams
    private val recordingOkHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(0, java.util.concurrent.TimeUnit.MILLISECONDS) // Unlimited for live streams
            .writeTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    // Requirement 1: MediaStore output stream creation helper
    private fun createRecordingOutputStream(context: android.content.Context, fileName: String): Pair<Uri, java.io.OutputStream>? {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp2t")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/IPTVRecordings")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        return try {
            val itemUri = resolver.insert(collection, contentValues) ?: return null
            val outputStream = resolver.openOutputStream(itemUri) ?: return null
            Log.d("RecordingDebug", "Création réussie du fichier MediaStore: URI=$itemUri")
            Pair(itemUri, outputStream)
        } catch (e: Exception) {
            Log.e("RecordingDebug", "Échec de la création MediaStore: ${e.message}", e)
            null
        }
    }

    private fun finalizeRecordingUri(context: android.content.Context, uri: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            try {
                context.contentResolver.update(uri, contentValues, null, null)
                Log.d("RecordingDebug", "MediaStore IS_PENDING mis à 0 pour: $uri")
            } catch (e: Exception) {
                Log.e("RecordingDebug", "Erreur finalisation IS_PENDING pour $uri: ${e.message}")
            }
        }
    }

    fun startRecording(channel: ChannelItem) {
        if (_isRecording.value) return
        _isRecording.value = true
        _recordingChannel.value = channel
        _recordingDurationSeconds.value = 0
        _recordingError.value = null

        val context = getApplication<Application>()
        val timestamp = System.currentTimeMillis()
        val cleanName = channel.name.replace(Regex("[^a-zA-Z0-9_]"), "_")
        val fileName = "IPTV_REC_${cleanName}_${timestamp}.ts"

        val mediaStoreResult = createRecordingOutputStream(context, fileName)
        if (mediaStoreResult == null) {
            Log.e("RecordingDebug", "Impossible de créer l'OutputStream MediaStore pour le fichier $fileName")
            _recordingError.value = "Échec de l'enregistrement : impossible de créer le fichier dans le stockage"
            _isRecording.value = false
            _recordingChannel.value = null
            return
        }

        val (recordingUri, outputStream) = mediaStoreResult
        currentRecordingUri = recordingUri

        recordingTimerJob = viewModelScope.launch {
            while (_isRecording.value) {
                kotlinx.coroutines.delay(1000)
                _recordingDurationSeconds.value += 1
            }
        }

        recordingJob = viewModelScope.launch(Dispatchers.IO) {
            var totalBytesWritten = 0L
            val startTimeMs = System.currentTimeMillis()
            var lastLogTimeMs = System.currentTimeMillis()

            try {
                outputStream.use { output ->
                    val currentPlaying = _selectedChannel.value
                    val finalUrl: String
                    val finalHeaders: Map<String, String>
                    if (currentPlaying != null && currentPlaying.streamUrl == channel.streamUrl && !_playbackUrl.value.isNullOrBlank()) {
                        finalUrl = _playbackUrl.value!!
                        finalHeaders = _playbackHeaders.value
                        Log.d("RecordingDebug", "Utilisation de l'URL résolue du lecteur actuel: $finalUrl")
                    } else {
                        val playbackInfo = resolveChannelPlayback(channel)
                        finalUrl = playbackInfo.url
                        finalHeaders = playbackInfo.headers
                        Log.d("RecordingDebug", "URL résolue pour l'enregistrement: $finalUrl")
                    }

                    // Requirement 5: Log final headers used for ExoPlayer vs recording comparison
                    Log.d("RecordingDebug", "En-têtes transmis à la requête d'enregistrement: $finalHeaders")

                    val isHls = finalUrl.lowercase().contains(".m3u8") || finalUrl.lowercase().contains("m3u8")

                    if (isHls) {
                        recordHlsStream(
                            manifestUrl = finalUrl,
                            outputStream = output,
                            headers = finalHeaders,
                            onBytesWritten = { count ->
                                totalBytesWritten += count
                                val now = System.currentTimeMillis()
                                if (now - lastLogTimeMs >= 5000) {
                                    Log.d("RecordingDebug", "Pendant l'enregistrement HLS: $totalBytesWritten octets écrits au total")
                                    lastLogTimeMs = now
                                }
                            },
                            checkNoDataTimeout = {
                                val now = System.currentTimeMillis()
                                if (totalBytesWritten == 0L && (now - startTimeMs >= 10000)) {
                                    Log.e("RecordingDebug", "Aucune donnée reçue du flux après 10s")
                                    _recordingError.value = "Échec de l'enregistrement : aucune donnée reçue après 10s"
                                    _isRecording.value = false
                                    true
                                } else {
                                    false
                                }
                            }
                        )
                    } else {
                        val requestBuilder = Request.Builder().url(finalUrl)
                        finalHeaders.forEach { (key, value) ->
                            requestBuilder.header(key, value)
                        }
                        requestBuilder.header("Accept", "*/*")
                        val request = requestBuilder.build()

                        // Requirement 2: Use dedicated recordingOkHttpClient
                        recordingOkHttpClient.newCall(request).execute().use { response ->
                            // Requirement 3: Diagnostic logs
                            Log.d("RecordingDebug", "Code HTTP de la réponse: ${response.code}")
                            Log.d("RecordingDebug", "Content-Type: ${response.header("Content-Type") ?: "Non spécifié"}")
                            Log.d("RecordingDebug", "Content-Length: ${response.header("Content-Length") ?: "Inconnu (live stream/chunked)"}")

                            if (response.isSuccessful) {
                                val body = response.body
                                if (body != null) {
                                    body.byteStream().use { input ->
                                        val buffer = ByteArray(32768)
                                        var bytesRead: Int
                                        while (_isRecording.value) {
                                            val now = System.currentTimeMillis()
                                            if (totalBytesWritten == 0L && (now - startTimeMs >= 10000)) {
                                                Log.e("RecordingDebug", "Aucune donnée reçue du flux après 10s")
                                                _recordingError.value = "Échec de l'enregistrement : aucune donnée reçue du flux après 10s"
                                                _isRecording.value = false
                                                break
                                            }

                                            bytesRead = input.read(buffer)
                                            if (bytesRead == -1) break
                                            if (bytesRead > 0) {
                                                output.write(buffer, 0, bytesRead)
                                                totalBytesWritten += bytesRead

                                                if (now - lastLogTimeMs >= 5000) {
                                                    Log.d("RecordingDebug", "Pendant l'enregistrement direct: $totalBytesWritten octets écrits au total")
                                                    lastLogTimeMs = now
                                                }
                                            }
                                        }
                                        output.flush()
                                    }
                                } else {
                                    Log.e("RecordingDebug", "Le corps de la réponse HTTP est vide")
                                    _recordingError.value = "Échec de l'enregistrement : flux vide reçu"
                                }
                            } else {
                                val errorBody = try { response.body?.string() } catch (e: Exception) { null }
                                Log.e("RecordingDebug", "Erreur HTTP ${response.code} lors de l'enregistrement direct. Corps : $errorBody")
                                _recordingError.value = when (response.code) {
                                    509 -> "Limite de connexion atteinte : votre abonnement IPTV n'autorise probablement qu'une seule connexion simultanée. Fermez le lecteur en direct avant d'enregistrer."
                                    429 -> "Trop de requêtes envoyées au serveur. Réessayez dans quelques instants."
                                    406 -> "Le serveur a refusé la requête d'enregistrement (406). Détails : $errorBody"
                                    else -> "Échec de l'enregistrement : erreur HTTP ${response.code}"
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("RecordingDebug", "Erreur de connexion lors de l'enregistrement: ${e.message}", e)
                _recordingError.value = "Échec de l'enregistrement : ${e.message}"
            } finally {
                _isRecording.value = false
                saveRecordingToDatabase(totalBytesWritten)
            }
        }
    }

    private fun recordHlsStream(
        manifestUrl: String,
        outputStream: java.io.OutputStream,
        headers: Map<String, String>,
        onBytesWritten: (Int) -> Unit,
        checkNoDataTimeout: () -> Boolean
    ) {
        val downloadedSegments = java.util.Collections.synchronizedSet(HashSet<String>())
        val client = recordingOkHttpClient
        var currentManifestUrl = manifestUrl

        Log.d("RecordingDebug", "Démarrage enregistrement HLS. Manifest URL: $currentManifestUrl")
        Log.d("RecordingDebug", "En-têtes HLS: $headers")

        while (_isRecording.value) {
            if (checkNoDataTimeout()) break

            try {
                val requestBuilder = Request.Builder().url(currentManifestUrl)
                headers.forEach { (k, v) -> requestBuilder.header(k, v) }
                requestBuilder.header("Accept", "*/*")
                val request = requestBuilder.build()

                client.newCall(request).execute().use { response ->
                    Log.d("RecordingDebug", "Code HTTP réponse Manifest HLS: ${response.code}")
                    Log.d("RecordingDebug", "Content-Type Manifest HLS: ${response.header("Content-Type") ?: "Inconnu"}")

                    if (response.isSuccessful) {
                        val bodyString = response.body?.string() ?: ""
                        val lines = bodyString.split("\n").map { it.trim() }.filter { it.isNotEmpty() }

                        // Check if it's a master playlist
                        val subPlaylist = lines.firstOrNull { !it.startsWith("#") && (it.contains(".m3u8") || it.contains("m3u8")) }
                        if (subPlaylist != null) {
                            currentManifestUrl = resolveUrl(currentManifestUrl, subPlaylist)
                            Log.d("RecordingDebug", "Sous-playlist HLS trouvée, redirection vers: $currentManifestUrl")
                            return@use
                        }

                        val segments = lines.filter { !it.startsWith("#") && !it.contains(".m3u8") }
                        for (segment in segments) {
                            if (!_isRecording.value) break
                            if (checkNoDataTimeout()) break

                            val fullSegmentUrl = resolveUrl(currentManifestUrl, segment)
                            if (downloadedSegments.add(fullSegmentUrl)) {
                                try {
                                    val segReqBuilder = Request.Builder().url(fullSegmentUrl)
                                    headers.forEach { (k, v) -> segReqBuilder.header(k, v) }
                                    segReqBuilder.header("Accept", "*/*")
                                    val segReq = segReqBuilder.build()

                                    client.newCall(segReq).execute().use { segResp ->
                                        if (segResp.isSuccessful) {
                                            val bytes = segResp.body?.bytes()
                                            if (bytes != null && bytes.isNotEmpty()) {
                                                synchronized(outputStream) {
                                                    outputStream.write(bytes)
                                                    outputStream.flush()
                                                }
                                                onBytesWritten(bytes.size)
                                            }
                                        } else {
                                            Log.e("RecordingDebug", "Échec téléchargement segment HLS, code HTTP: ${segResp.code}")
                                        }
                                        Unit
                                    }
                                } catch (e: Exception) {
                                    Log.e("RecordingDebug", "Erreur lors du téléchargement du segment HLS: ${e.message}")
                                }
                            }
                        }
                    } else {
                        val errorBody = try { response.body?.string() } catch (e: Exception) { null }
                        Log.e("RecordingDebug", "Échec manifest HLS, code HTTP : ${response.code}. Corps : $errorBody")
                    }
                    Unit
                }
            } catch (e: Exception) {
                Log.e("RecordingDebug", "Erreur lors de la récupération du manifest HLS: ${e.message}")
            }

            try {
                Thread.sleep(3000)
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    private fun resolveUrl(baseUrl: String, segmentPath: String): String {
        if (segmentPath.startsWith("http://") || segmentPath.startsWith("https://")) {
            return segmentPath
        }
        val urlWithoutQuery = baseUrl.substringBefore("?")
        val query = if (baseUrl.contains("?")) baseUrl.substringAfter("?") else ""
        
        val base = urlWithoutQuery.substringBeforeLast("/")
        val resolvedWithoutQuery = if (segmentPath.startsWith("/")) {
            val hostIndex = urlWithoutQuery.indexOf("/", urlWithoutQuery.indexOf("//") + 2)
            val host = if (hostIndex != -1) urlWithoutQuery.substring(0, hostIndex) else urlWithoutQuery
            "$host$segmentPath"
        } else {
            "$base/$segmentPath"
        }
        
        return if (query.isNotEmpty() && !resolvedWithoutQuery.contains("?")) {
            "$resolvedWithoutQuery?$query"
        } else {
            resolvedWithoutQuery
        }
    }

    fun stopRecording() {
        if (!_isRecording.value) return
        _isRecording.value = false
        recordingJob?.cancel()
        recordingTimerJob?.cancel()
    }

    private fun saveRecordingToDatabase(totalBytesWritten: Long) {
        val channel = _recordingChannel.value ?: return
        val recordingUri = currentRecordingUri ?: return
        val durationSecs = _recordingDurationSeconds.value
        val context = getApplication<Application>()

        _recordingChannel.value = null
        currentRecordingUri = null

        if (totalBytesWritten == 0L) {
            Log.e("RecordingDebug", "Enregistrement terminé avec 0 octet écrit. Suppression du fichier MediaStore...")
            if (_recordingError.value.isNullOrBlank()) {
                _recordingError.value = "Échec de l'enregistrement : aucune donnée reçue"
            }
            try {
                context.contentResolver.delete(recordingUri, null, null)
            } catch (e: Exception) {
                Log.e("RecordingDebug", "Erreur lors de la suppression de l'enregistrement vide MediaStore: ${e.message}")
            }
            return
        }

        finalizeRecordingUri(context, recordingUri)

        viewModelScope.launch(Dispatchers.IO) {
            val recItem = RecordingItem(
                playlistId = channel.playlistId,
                channelName = channel.name,
                streamUrl = channel.streamUrl,
                programTitle = "Enregistrement Direct (${durationSecs}s)",
                scheduledAt = System.currentTimeMillis(),
                durationMinutes = (durationSecs / 60).coerceAtLeast(1),
                isCompleted = true,
                filepath = recordingUri.toString()
            )
            repository.insertRecording(recItem)
            Log.d("RecordingDebug", "Enregistrement sauvegardé avec succès en BDD : ${recItem.filepath}")
        }
    }

    fun deleteRecording(id: Long, filepath: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteRecording(id)
            try {
                if (filepath.startsWith("content://")) {
                    val uri = Uri.parse(filepath)
                    getApplication<Application>().contentResolver.delete(uri, null, null)
                } else {
                    val file = java.io.File(filepath)
                    if (file.exists()) {
                        file.delete()
                    }
                }
            } catch (e: Exception) {
                Log.e("RecordingDebug", "Failed to delete recording file: ${e.message}")
            }
        }
    }

    fun createDemoPlaylist() {
        _importState.value = ImportState.Error("La playlist de démonstration est désactivée. Veuillez fournir une URL de playlist ou de portail réelle.")
    }

    private fun savePlaylistLastUpdated(playlistId: Long) {
        val context = getApplication<android.app.Application>().applicationContext
        context.getSharedPreferences("playlist_cache", android.content.Context.MODE_PRIVATE)
            .edit()
            .putLong("last_updated_${playlistId}", System.currentTimeMillis())
            .apply()
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun importBulkPlaylists(items: List<BulkImportItem>, clearExisting: Boolean = false) {
        _importState.value = ImportState.Loading("Importation en masse commencée...")
        viewModelScope.launch(Dispatchers.IO) {
            if (clearExisting) {
                repository.deleteAllPlaylists()
                _selectedPlaylist.value = null
                _channels.value = emptyList()
                _categories.value = emptyList()
                _playlistSummaries.value = emptyMap()
            }
            
            val currentPlaylists = playlists.value
            val distinctItems = items.distinctBy { it.url }
            
            var successCount = 0
            var errorCount = 0
            var lastPlaylist: PlaylistItem? = null
            
            for ((index, item) in distinctItems.withIndex()) {
                try {
                    _importState.value = ImportState.Loading("Importation (${index + 1}/${distinctItems.size}) : ${item.name}...")
                    
                    // If not clearing all, wisely remove existing playlist with the exact same URL first to prevent duplicate lists
                    if (!clearExisting) {
                        val existing = currentPlaylists.find { it.url.equals(item.url, ignoreCase = true) }
                        if (existing != null) {
                            repository.deletePlaylist(existing.id)
                        }
                    }
                    
                    if (item.type.lowercase() == "m3u") {
                        val request = Request.Builder().url(item.url).build()
                        okHttpClient.newCall(request).execute().use { response ->
                            if (!response.isSuccessful) throw Exception("Échec HTTP: ${response.code}")
                            val body = response.body ?: throw Exception("Le corps de la réponse est vide.")
                            val playlistId = repository.insertPlaylist(
                                PlaylistItem(name = item.name, type = "M3U", url = item.url)
                            )
                            val count = body.charStream().use { reader ->
                                repository.importPlaylistData(playlistId, reader, "m3u")
                            }
                            successCount++
                            lastPlaylist = PlaylistItem(id = playlistId, name = item.name, type = "M3U", url = item.url)
                        }
                    } else if (item.type.lowercase() == "stalker") {
                        val playlistId = stalkerRepository.importStalkerPortal(
                            playlistName = item.name,
                            portalUrl = item.url,
                            macAddress = item.macAddress,
                            hideDns = false,
                            onStatusUpdate = { status ->
                                _importState.value = ImportState.Loading("[${item.name}] $status")
                            }
                        )
                        successCount++
                        lastPlaylist = PlaylistItem(id = playlistId, name = item.name, type = "Stalker", url = item.url, macAddress = item.macAddress)
                    }
                } catch (e: Exception) {
                    Log.e("IptvViewModel", "Error bulk importing ${item.name}: ${e.message}", e)
                    errorCount++
                }
            }
            
            if (successCount > 0) {
                _importState.value = ImportState.Success("$successCount playlist(s) importée(s) avec succès ! ($errorCount échec(s))")
                refreshSummaries()
                lastPlaylist?.let { playlist ->
                    _selectedPlaylist.value = playlist
                    selectPlaylist(playlist)
                }
            } else {
                _importState.value = ImportState.Error("Toutes les importations ont échoué ($errorCount échecs).")
            }
        }
    }

    fun clearImportState() {
        _importState.value = ImportState.Idle
    }

    @Volatile private var currentImportJob: kotlinx.coroutines.Job? = null

    /**
     * « Arrêter & Sauvegarder » : interrompt le téléchargement de la playlist en cours et GARDE ce qui est déjà récupéré.
     * - Stalker : chaînes/films/séries déjà reçus + configuration du portail sont enregistrés.
     * - M3U / Xtream : ce qui est déjà inséré en base est conservé.
     */
    fun stopImportAndSave() {
        val job = currentImportJob ?: return
        _importState.value = ImportState.Loading("Arrêt en cours et sauvegarde de ce qui est déjà téléchargé...")
        stalkerRepository.requestStopAndSave()
        job.cancel()
    }

    private suspend fun finishStoppedImport(playlistId: Long, savedCount: Int) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
            try {
                if (playlistId > 0L) {
                    savePlaylistLastUpdated(playlistId)
                    refreshSummaries()
                    val dbPlaylist = repository.getPlaylistById(playlistId)
                    _importState.value = ImportState.Success(
                        if (savedCount > 0) "Import arrêté : $savedCount éléments sauvegardés. Vous pourrez relancer la mise à jour plus tard."
                        else "Import arrêté : la playlist est enregistrée (sans contenu). Relancez la mise à jour quand vous voulez."
                    )
                    if (dbPlaylist != null) {
                        _selectedPlaylist.value = dbPlaylist
                        selectPlaylist(dbPlaylist)
                    }
                } else {
                    _importState.value = ImportState.Success("Import arrêté.")
                }
            } catch (e: Exception) {
                _importState.value = ImportState.Success("Import arrêté.")
            }
        }
    }

    fun startBulkImportSequential(text: String, clearExisting: Boolean = false) {
        val parsed = parseBulkPortalText(text)
        if (parsed.isEmpty()) {
            _bulkImportProgress.value = BulkImportProgressState(
                isRunning = false,
                isFinished = true,
                currentIndex = 0,
                totalCount = 0,
                items = emptyList(),
                successCount = 0,
                failureCount = 0
            )
            return
        }

        _bulkImportProgress.value = BulkImportProgressState(
            isRunning = true,
            isFinished = false,
            currentIndex = 0,
            totalCount = parsed.size,
            items = parsed.map { BulkImportItemStatus(url = it.url, mac = it.mac, domain = it.domain) },
            successCount = 0,
            failureCount = 0
        )

        viewModelScope.launch(Dispatchers.IO) {
            if (clearExisting) {
                repository.deleteAllPlaylists()
                _selectedPlaylist.value = null
                _channels.value = emptyList()
                _categories.value = emptyList()
                _playlistSummaries.value = emptyMap()
            }

            val itemsList = _bulkImportProgress.value.items.toMutableList()
            var successCount = 0
            var failureCount = 0
            var lastSuccessPlaylist: PlaylistItem? = null

            for (i in parsed.indices) {
                val item = parsed[i]
                itemsList[i] = itemsList[i].copy(status = BulkPortalStatus.IN_PROGRESS)
                _bulkImportProgress.value = _bulkImportProgress.value.copy(
                    currentIndex = i + 1,
                    items = itemsList.toList()
                )

                try {
                    if (item.mac.isNotEmpty()) {
                        val playlistId = stalkerRepository.importStalkerPortal(
                            playlistName = item.domain,
                            portalUrl = item.url,
                            macAddress = item.mac,
                            hideDns = false,
                            loadLive = true,
                            loadMovies = true,
                            loadSeries = true,
                            onStatusUpdate = { _ -> }
                        )
                        savePlaylistLoadSettings(playlistId, true, true, true)
                        savePlaylistLastUpdated(playlistId)
                        successCount++
                        itemsList[i] = itemsList[i].copy(status = BulkPortalStatus.SUCCESS)
                        val dbPl = repository.getPlaylistById(playlistId)
                        if (dbPl != null) lastSuccessPlaylist = dbPl
                    } else if (item.url.contains(".m3u", ignoreCase = true) || item.url.contains("get.php")) {
                        val request = Request.Builder().url(item.url).build()
                        okHttpClient.newCall(request).execute().use { response ->
                            if (!response.isSuccessful) throw Exception("Impossible de contacter le serveur M3U (HTTP ${response.code})")
                            val body = response.body ?: throw Exception("Le serveur a retourné une réponse vide.")
                            val playlistId = repository.insertPlaylist(
                                PlaylistItem(name = item.domain, type = "M3U", url = item.url)
                            )
                            body.charStream().use { reader ->
                                repository.importPlaylistData(playlistId, reader, "m3u")
                            }
                            savePlaylistLoadSettings(playlistId, true, true, true)
                            savePlaylistLastUpdated(playlistId)
                            successCount++
                            itemsList[i] = itemsList[i].copy(status = BulkPortalStatus.SUCCESS)
                            val dbPl = repository.getPlaylistById(playlistId)
                            if (dbPl != null) lastSuccessPlaylist = dbPl
                        }
                    } else {
                        val playlistId = stalkerRepository.importStalkerPortal(
                            playlistName = item.domain,
                            portalUrl = item.url,
                            macAddress = "00:1A:79:00:00:00",
                            hideDns = false,
                            loadLive = true,
                            loadMovies = true,
                            loadSeries = true,
                            onStatusUpdate = { _ -> }
                        )
                        savePlaylistLoadSettings(playlistId, true, true, true)
                        savePlaylistLastUpdated(playlistId)
                        successCount++
                        itemsList[i] = itemsList[i].copy(status = BulkPortalStatus.SUCCESS)
                        val dbPl = repository.getPlaylistById(playlistId)
                        if (dbPl != null) lastSuccessPlaylist = dbPl
                    }
                } catch (e: Exception) {
                    Log.e("IptvViewModel", "Bulk import error for ${item.domain}: ${e.message}", e)
                    failureCount++
                    val cleanErrMsg = e.message ?: "Échec de connexion au portail"
                    itemsList[i] = itemsList[i].copy(
                        status = BulkPortalStatus.FAILURE,
                        errorMessage = cleanErrMsg
                    )
                }

                _bulkImportProgress.value = _bulkImportProgress.value.copy(
                    items = itemsList.toList(),
                    successCount = successCount,
                    failureCount = failureCount
                )
            }

            refreshSummaries()
            val targetPlaylist = lastSuccessPlaylist
            if (targetPlaylist != null) {
                _selectedPlaylist.value = targetPlaylist
                selectPlaylist(targetPlaylist)
            }

            _bulkImportProgress.value = _bulkImportProgress.value.copy(
                isRunning = false,
                isFinished = true
            )
        }
    }

    fun resetBulkImportProgress() {
        _bulkImportProgress.value = BulkImportProgressState()
    }

    // WEB SERVER METHODS FOR REMOTE IMPORT
    fun getLocalIpAddress(): String? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress) {
                        val sAddr = addr.hostAddress
                        if (sAddr != null && !sAddr.contains(':')) return sAddr
                    }
                }
            }
        } catch (ex: Exception) {
            Log.e("IptvViewModel", "Error getting IP Address", ex)
        }
        return null
    }

    fun startWebServer() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val ip = getLocalIpAddress()
                if (ip == null) {
                    _webServerStatus.value = "Pas de Wi-Fi"
                    return@launch
                }
                _webServerIp.value = ip
                
                val server = ServerSocket(webServerPort)
                serverSocket = server
                _webServerStatus.value = "Actif"
                Log.d("IptvViewModel", "Web Server started at http://$ip:$webServerPort")
                
                while (serverSocket != null && !server.isClosed) {
                    val client = try {
                        server.accept()
                    } catch (e: Exception) {
                        break
                    }
                    
                    launch(Dispatchers.IO) {
                        handleWebClient(client)
                    }
                }
            } catch (e: Exception) {
                Log.e("IptvViewModel", "Error in Web Server", e)
                _webServerStatus.value = "Erreur: ${e.message}"
            }
        }
    }

    fun stopWebServer() {
        try {
            serverSocket?.close()
            serverSocket = null
            _webServerStatus.value = "Arrêté"
        } catch (e: Exception) {
            Log.e("IptvViewModel", "Error closing Web Server", e)
        }
    }

    private suspend fun handleWebClient(client: Socket) {
        try {
            val reader = BufferedReader(InputStreamReader(client.getInputStream()))
            val out = PrintWriter(client.getOutputStream())
            
            val requestLine = reader.readLine() ?: return
            Log.d("IptvViewModel", "HTTP Request: $requestLine")
            
            var contentLength = 0
            var line: String? = reader.readLine()
            while (line != null && line.isNotEmpty()) {
                if (line.startsWith("Content-Length:", ignoreCase = true)) {
                    contentLength = line.substring(15).trim().toIntOrNull() ?: 0
                }
                line = reader.readLine()
            }
            
            if (requestLine.startsWith("GET")) {
                val html = getWebServerHtmlPage()
                out.print("HTTP/1.1 200 OK\r\n")
                out.print("Content-Type: text/html; charset=UTF-8\r\n")
                out.print("Content-Length: ${html.toByteArray(Charsets.UTF_8).size}\r\n")
                out.print("Connection: close\r\n\r\n")
                out.print(html)
                out.flush()
            } else if (requestLine.startsWith("POST /submit", ignoreCase = true)) {
                val bodyChars = CharArray(contentLength)
                var read = 0
                while (read < contentLength) {
                    val r = reader.read(bodyChars, read, contentLength - read)
                    if (r == -1) break
                    read += r
                }
                val body = String(bodyChars)
                
                val params = parseUrlEncodedForm(body)
                val type = params["type"] ?: "M3U"
                val name = params["name"] ?: "Imported"
                val url = params["url"] ?: ""
                val username = params["username"] ?: ""
                val password = params["password"] ?: ""
                val mac = params["mac"] ?: ""
                val actionType = params["action_type"] ?: "create"
                val playlistIdStr = params["playlist_id"] ?: ""
                val playlistId = playlistIdStr.toLongOrNull()
                
                if (url.isNotEmpty()) {
                    if (actionType == "update" && playlistId != null) {
                        val playlist = PlaylistItem(
                            id = playlistId,
                            name = name,
                            type = type,
                            url = url,
                            username = if (username.isNotEmpty()) username else null,
                            password = if (password.isNotEmpty()) password else null,
                            macAddress = if (mac.isNotEmpty()) mac else null
                        )
                        updateAndReimportPlaylist(playlist)
                    } else {
                        withContext(Dispatchers.Main) {
                            when (type) {
                                "M3U" -> importM3uPlaylist(name, url)
                                "Xtream" -> importXtreamPlaylist(name, url, username, password)
                                "Stalker" -> importStalkerPortal(name, url, mac, false)
                            }
                        }
                    }
                    
                    val responseHtml = """
                        <!DOCTYPE html>
                        <html>
                        <head>
                        <meta name="viewport" content="width=device-width, initial-scale=1">
                        <meta charset="UTF-8">
                        <title>Playlist Envoyée !</title>
                        <style>
                        body { font-family: sans-serif; background: #0f172a; color: #f8fafc; padding: 40px; text-align: center; }
                        .card { background: #1e293b; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; border: 1px solid #10b981; }
                        button { padding: 10px 20px; background: #10b981; border: none; color: white; font-weight: bold; border-radius: 8px; cursor: pointer; margin-top: 20px; }
                        </style>
                        <script>
                        setTimeout(function() { window.location.href = "/"; }, 2000);
                        </script>
                        </head>
                        <body>
                        <div class="card">
                        <h2 style="color: #10b981;">Succès !</h2>
                        <p>La playlist <strong>${name}</strong> a été enregistrée avec succès sur votre Google TV !</p>
                        <p>L'opération est en cours d'exécution.</p>
                        <button onclick="window.location.href='/'">Retour à la liste</button>
                        </div>
                        </body>
                        </html>
                    """.trimIndent()
                    
                    out.print("HTTP/1.1 200 OK\r\n")
                    out.print("Content-Type: text/html; charset=UTF-8\r\n")
                    out.print("Content-Length: ${responseHtml.toByteArray(Charsets.UTF_8).size}\r\n")
                    out.print("Connection: close\r\n\r\n")
                    out.print(responseHtml)
                    out.flush()
                } else {
                    val errorHtml = """
                        <!DOCTYPE html>
                        <html>
                        <head>
                        <meta name="viewport" content="width=device-width, initial-scale=1">
                        <meta charset="UTF-8">
                        <title>Erreur</title>
                        <style>
                        body { font-family: sans-serif; background: #0f172a; color: #f8fafc; padding: 40px; text-align: center; }
                        .card { background: #1e293b; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; border: 1px solid #ef4444; }
                        button { padding: 10px 20px; background: #3b82f6; border: none; color: white; font-weight: bold; border-radius: 8px; cursor: pointer; margin-top: 20px; }
                        </style>
                        </head>
                        <body>
                        <div class="card">
                        <h2 style="color: #ef4444;">Erreur</h2>
                        <p>L'URL de la playlist ne peut pas être vide.</p>
                        <button onclick="window.history.back()">Retour</button>
                        </div>
                        </body>
                        </html>
                    """.trimIndent()
                    
                    out.print("HTTP/1.1 400 Bad Request\r\n")
                    out.print("Content-Type: text/html; charset=UTF-8\r\n")
                    out.print("Content-Length: ${errorHtml.toByteArray(Charsets.UTF_8).size}\r\n")
                    out.print("Connection: close\r\n\r\n")
                    out.print(errorHtml)
                    out.flush()
                }
            } else if (requestLine.startsWith("POST /delete", ignoreCase = true)) {
                val bodyChars = CharArray(contentLength)
                var read = 0
                while (read < contentLength) {
                    val r = reader.read(bodyChars, read, contentLength - read)
                    if (r == -1) break
                    read += r
                }
                val body = String(bodyChars)
                val params = parseUrlEncodedForm(body)
                val playlistIdStr = params["playlist_id"] ?: ""
                val playlistId = playlistIdStr.toLongOrNull()
                
                if (playlistId != null) {
                    withContext(Dispatchers.Main) {
                        deletePlaylist(playlistId)
                    }
                }
                
                out.print("HTTP/1.1 303 See Other\r\n")
                out.print("Location: /\r\n")
                out.print("Connection: close\r\n\r\n")
                out.flush()
            } else if (requestLine.startsWith("POST /select", ignoreCase = true)) {
                val bodyChars = CharArray(contentLength)
                var read = 0
                while (read < contentLength) {
                    val r = reader.read(bodyChars, read, contentLength - read)
                    if (r == -1) break
                    read += r
                }
                val body = String(bodyChars)
                val params = parseUrlEncodedForm(body)
                val playlistIdStr = params["playlist_id"] ?: ""
                val playlistId = playlistIdStr.toLongOrNull()
                
                if (playlistId != null) {
                    withContext(Dispatchers.Main) {
                        val playlist = playlists.value.find { it.id == playlistId }
                        if (playlist != null) {
                            selectPlaylist(playlist)
                        }
                    }
                }
                
                out.print("HTTP/1.1 303 See Other\r\n")
                out.print("Location: /\r\n")
                out.print("Connection: close\r\n\r\n")
                out.flush()
            } else if (requestLine.startsWith("POST /clipboard", ignoreCase = true)) {
                val bodyChars = CharArray(contentLength)
                var read = 0
                while (read < contentLength) {
                    val r = reader.read(bodyChars, read, contentLength - read)
                    if (r == -1) break
                    read += r
                }
                val body = String(bodyChars)
                val params = parseUrlEncodedForm(body)
                val text = params["text"] ?: ""
                
                if (text.isNotEmpty()) {
                    withContext(Dispatchers.Main) {
                        try {
                            val context = getApplication<Application>()
                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            val clip = android.content.ClipData.newPlainText("Pro IPTV Remote Paste", text)
                            clipboard.setPrimaryClip(clip)
                            Log.d("IptvViewModel", "Shared clipboard text copied to TV: $text")
                        } catch (e: Exception) {
                            Log.e("IptvViewModel", "Error copying to TV clipboard", e)
                        }
                    }
                }
                
                val responseHtml = """
                    <!DOCTYPE html>
                    <html>
                    <head>
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <meta charset="UTF-8">
                    <title>Texte Envoyé !</title>
                    <style>
                    body { font-family: sans-serif; background: #0f172a; color: #f8fafc; padding: 40px; text-align: center; }
                    .card { background: #1e293b; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; border: 1px solid #10b981; }
                    button { padding: 10px 20px; background: #10b981; border: none; color: white; font-weight: bold; border-radius: 8px; cursor: pointer; margin-top: 20px; }
                    </style>
                    <script>
                    setTimeout(function() { window.location.href = "/"; }, 1500);
                    </script>
                    </head>
                    <body>
                    <div class="card">
                    <h2 style="color: #10b981;">Texte Copié !</h2>
                    <p>Le texte a été envoyé et copié avec succès dans le presse-papiers de votre Google TV !</p>
                    <p>Vous pouvez maintenant faire un appui long ou cliquer sur <strong>"Coller"</strong> sur votre TV pour l'insérer.</p>
                    <button onclick="window.location.href='/'">Retour</button>
                    </div>
                    </body>
                    </html>
                """.trimIndent()
                
                out.print("HTTP/1.1 200 OK\r\n")
                out.print("Content-Type: text/html; charset=UTF-8\r\n")
                out.print("Content-Length: ${responseHtml.toByteArray(Charsets.UTF_8).size}\r\n")
                out.print("Connection: close\r\n\r\n")
                out.print(responseHtml)
                out.flush()
            } else {
                out.print("HTTP/1.1 404 Not Found\r\n\r\n")
                out.flush()
            }
        } catch (e: Exception) {
            Log.e("IptvViewModel", "Error handling HTTP client", e)
        } finally {
            try {
                client.close()
            } catch (e: Exception) {}
        }
    }

    private fun parseUrlEncodedForm(body: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        if (body.isEmpty()) return map
        val pairs = body.split("&")
        for (pair in pairs) {
            val idx = pair.indexOf("=")
            if (idx > 0) {
                val key = URLDecoder.decode(pair.substring(0, idx), "UTF-8")
                val value = URLDecoder.decode(pair.substring(idx + 1), "UTF-8")
                map[key] = value
            }
        }
        return map
    }

    private fun getWebServerHtmlPage(): String {
        val currentPlaylists = playlists.value
        val listBuilder = StringBuilder()
        
        if (currentPlaylists.isEmpty()) {
            listBuilder.append("<p style='color: #9ca3af; text-align: center; margin: 16px 0;'>Aucune playlist configurée pour le moment.</p>")
        } else {
            for (pl in currentPlaylists) {
                val badgeColor = when (pl.type) {
                    "M3U" -> "#10b981"
                    "Xtream" -> "#3b82f6"
                    "Stalker" -> "#8b5cf6"
                    else -> "#6b7280"
                }
                listBuilder.append("""
                    <div class="playlist-card">
                        <div class="playlist-info">
                            <span class="playlist-badge" style="background-color: $badgeColor">${pl.type}</span>
                            <strong class="playlist-name">${pl.name}</strong>
                            <div class="playlist-url">${pl.url}</div>
                        </div>
                        <div class="playlist-actions">
                            <form method="POST" action="/select" style="display:inline;">
                                <input type="hidden" name="playlist_id" value="${pl.id}">
                                <button type="submit" class="btn-select">Activer</button>
                            </form>
                            <button type="button" class="btn-edit" onclick="editPlaylist(${pl.id})">Modifier</button>
                            <form method="POST" action="/delete" style="display:inline;" onsubmit="return confirm('Voulez-vous vraiment supprimer cette playlist ?');">
                                <input type="hidden" name="playlist_id" value="${pl.id}">
                                <button type="submit" class="btn-delete">Supprimer</button>
                            </form>
                        </div>
                    </div>
                """.trimIndent())
            }
        }

        val playlistsJson = currentPlaylists.joinToString(prefix = "[", postfix = "]") { pl ->
            """{"id": ${pl.id}, "name": "${pl.name.replace("\"", "\\\"")}", "type": "${pl.type}", "url": "${pl.url.replace("\"", "\\\"")}", "username": "${(pl.username ?: "").replace("\"", "\\\"")}", "password": "${(pl.password ?: "").replace("\"", "\\\"")}", "macAddress": "${(pl.macAddress ?: "").replace("\"", "\\\"")}"}"""
        }

        return """
            <!DOCTYPE html>
            <html>
            <head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta charset="UTF-8">
            <title>Pro IPTV - Télécommande Web</title>
            <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #0b0f19; color: #f1f5f9; padding: 24px; margin: 0; display: flex; flex-direction: column; align-items: center; min-height: 100vh; box-sizing: border-box; }
            .container { max-width: 500px; width: 100%; display: flex; flex-direction: column; gap: 24px; box-sizing: border-box; }
            .card { background: #111827; padding: 24px; border-radius: 16px; border: 1px solid #1f2937; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3); box-sizing: border-box; }
            h2, h3 { text-align: center; margin-top: 0; color: #10b981; font-weight: 700; margin-bottom: 20px; }
            h3 { color: #f1f5f9; font-size: 18px; margin-bottom: 16px; border-bottom: 1px solid #1f2937; padding-bottom: 8px; text-align: left; }
            label { display: block; margin-top: 14px; margin-bottom: 6px; color: #9ca3af; font-size: 14px; font-weight: 500; }
            input, select, textarea { width: 100%; padding: 12px 16px; border: 1px solid #374151; background: #1f2937; color: white; border-radius: 10px; box-sizing: border-box; font-size: 15px; outline: none; transition: border 0.2s; }
            input:focus, select:focus, textarea:focus { border-color: #10b981; }
            button { width: 100%; padding: 14px; background: #10b981; border: none; color: white; font-weight: bold; border-radius: 10px; cursor: pointer; font-size: 16px; margin-top: 20px; transition: background 0.2s; }
            button:hover { background: #059669; }
            
            /* Playlist management styling */
            .playlist-card { background: #1f2937; padding: 16px; border-radius: 12px; margin-bottom: 12px; border: 1px solid #374151; display: flex; flex-direction: column; gap: 12px; }
            .playlist-info { display: flex; flex-direction: column; }
            .playlist-name { font-size: 16px; color: white; font-weight: 600; margin-top: 4px; }
            .playlist-badge { font-size: 10px; font-weight: bold; color: white; padding: 2px 8px; border-radius: 20px; width: fit-content; text-transform: uppercase; }
            .playlist-url { font-size: 11px; color: #6b7280; word-break: break-all; margin-top: 4px; }
            .playlist-actions { display: flex; gap: 8px; justify-content: flex-end; }
            .playlist-actions button, .playlist-actions .btn-delete { width: auto; margin-top: 0; padding: 8px 12px; font-size: 13px; border-radius: 6px; font-weight: 500; }
            .btn-select { background: #10b981; }
            .btn-select:hover { background: #059669; }
            .btn-edit { background: #3b82f6; border: none; color: white; font-weight: bold; cursor: pointer; }
            .btn-edit:hover { background: #2563eb; }
            .btn-delete { background: #ef4444; border: none; color: white; font-weight: bold; cursor: pointer; }
            .btn-delete:hover { background: #dc2626; }
            
            .btn-cancel { background: #4b5563; margin-top: 12px; }
            .btn-cancel:hover { background: #374151; }
            
            .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #4b5563; }
            .section-xtream, .section-stalker { display: none; }
            textarea { height: 100px; resize: vertical; }
            </style>
            <script>
            var playlists = $playlistsJson;
            
            function updateFormFields() {
                var type = document.getElementById('type').value;
                document.getElementById('section-xtream').style.display = (type === 'Xtream') ? 'block' : 'none';
                document.getElementById('section-stalker').style.display = (type === 'Stalker') ? 'block' : 'none';
                
                var urlLabel = document.getElementById('url-label');
                var urlInput = document.getElementById('url');
                if (type === 'Xtream') {
                    urlLabel.innerText = "URL du Serveur Xtream";
                    urlInput.placeholder = "http://exemple.com:8080";
                } else if (type === 'Stalker') {
                    urlLabel.innerText = "URL du Portail Stalker";
                    urlInput.placeholder = "http://exemple.com/c/";
                } else {
                    urlLabel.innerText = "Lien M3U (URL)";
                    urlInput.placeholder = "http://exemple.com/playlist.m3u";
                }
            }
            
            function editPlaylist(id) {
                var pl = playlists.find(function(p) { return p.id === id; });
                if (pl) {
                    document.getElementById('action_type').value = 'update';
                    document.getElementById('playlist_id').value = pl.id;
                    document.getElementById('type').value = pl.type;
                    document.getElementById('name').value = pl.name;
                    document.getElementById('url').value = pl.url;
                    document.getElementById('username').value = pl.username || '';
                    document.getElementById('password').value = pl.password || '';
                    document.getElementById('mac').value = pl.macAddress || '';
                    updateFormFields();
                    document.getElementById('submit-btn').innerText = "Enregistrer sur la TV";
                    document.getElementById('form-title').innerText = "Modifier : " + pl.name;
                    document.getElementById('cancel-edit-btn').style.display = 'block';
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
            }
            
            function cancelEdit() {
                document.getElementById('action_type').value = 'create';
                document.getElementById('playlist_id').value = '';
                document.getElementById('type').value = 'M3U';
                document.getElementById('name').value = '';
                document.getElementById('url').value = '';
                document.getElementById('username').value = '';
                document.getElementById('password').value = '';
                document.getElementById('mac').value = '';
                updateFormFields();
                document.getElementById('submit-btn').innerText = "Importer sur Google TV";
                document.getElementById('form-title').innerText = "Ajouter une Playlist";
                document.getElementById('cancel-edit-btn').style.display = 'none';
            }
            </script>
            </head>
            <body>
            <div class="container">
                <div class="card">
                    <h2 id="form-title">Ajouter une Playlist</h2>
                    <form method="POST" action="/submit">
                        <input type="hidden" id="action_type" name="action_type" value="create">
                        <input type="hidden" id="playlist_id" name="playlist_id" value="">
                        
                        <label for="type">Type de Playlist</label>
                        <select id="type" name="type" onchange="updateFormFields()">
                            <option value="M3U">Lien M3U (URL)</option>
                            <option value="Xtream">Serveur Xtream Codes</option>
                            <option value="Stalker">Portail Stalker</option>
                        </select>
                        
                        <label for="name">Nom de la Playlist</label>
                        <input type="text" id="name" name="name" placeholder="Ex: Ma Super Playlist" required>
                        
                        <label id="url-label" for="url">Lien M3U (URL)</label>
                        <input type="url" id="url" name="url" placeholder="http://exemple.com/playlist.m3u" required>
                        
                        <div id="section-xtream" class="section-xtream">
                            <label for="username">Nom d'utilisateur</label>
                            <input type="text" id="username" name="username" placeholder="Identifiant">
                            
                            <label for="password">Mot de passe</label>
                            <input type="password" id="password" name="password" placeholder="Mot de passe">
                        </div>
                        
                        <div id="section-stalker" class="section-stalker">
                            <label for="mac">Adresse MAC</label>
                            <input type="text" id="mac" name="mac" placeholder="00:1A:79:00:00:00">
                        </div>
                        
                        <button type="submit" id="submit-btn">Importer sur Google TV</button>
                        <button type="button" id="cancel-edit-btn" class="btn-cancel" style="display:none;" onclick="cancelEdit()">Annuler les modifications</button>
                    </form>
                </div>
                
                <div class="card">
                    <h3>Presse-papiers Partagé</h3>
                    <p style="font-size: 13px; color: #9ca3af; margin-top: 0;">Collez n'importe quel texte ou URL ci-dessous pour l'envoyer directement dans le presse-papiers de votre TV !</p>
                    <form method="POST" action="/clipboard">
                        <textarea id="clipboard-text" name="text" placeholder="Collez un lien M3U, un mot clé à rechercher ou du texte..." required></textarea>
                        <button type="submit" style="background-color: #3b82f6;">Copier sur la Google TV</button>
                    </form>
                </div>
                
                <div class="card">
                    <h3>Playlists configurées sur la TV</h3>
                    <div class="playlists-list">
                        $listBuilder
                    </div>
                </div>
                
                <div class="footer">Pro IPTV - Connecté au Wi-Fi local</div>
            </div>
            </body>
            </html>
        """.trimIndent()
    }
}

data class BulkImportItem(
    val name: String,
    val url: String,
    val macAddress: String = "",
    val type: String // "m3u" or "stalker"
)

enum class BulkPortalStatus {
    PENDING,
    IN_PROGRESS,
    SUCCESS,
    FAILURE
}

data class BulkImportItemStatus(
    val url: String,
    val mac: String,
    val domain: String,
    val status: BulkPortalStatus = BulkPortalStatus.PENDING,
    val errorMessage: String? = null
)

data class BulkImportProgressState(
    val isRunning: Boolean = false,
    val isFinished: Boolean = false,
    val currentIndex: Int = 0,
    val totalCount: Int = 0,
    val items: List<BulkImportItemStatus> = emptyList(),
    val successCount: Int = 0,
    val failureCount: Int = 0
)

data class MacTestItemResult(
    val mac: String,
    val success: Boolean,
    val liveChannelsCount: Int = 0,
    val playlistId: Long? = null,
    val errorMessage: String? = null,
    val isCreated: Boolean = false,
    val isLoadingChannels: Boolean = false,
    val channelsLoadedCount: Int? = null,
    val playlistName: String? = null
)

data class BulkMacTestProgress(
    val isTesting: Boolean = false,
    val totalCount: Int = 0,
    val currentIndex: Int = 0,
    val currentMac: String = "",
    val successCount: Int = 0,
    val failureCount: Int = 0,
    val statusText: String = "",
    val isCompleted: Boolean = false,
    val results: List<MacTestItemResult> = emptyList()
)

fun extractAndNormalizeMacs(input: String): List<String> {
    val result = mutableListOf<String>()
    if (input.isBlank()) return emptyList()

    // 1. Recherche globale par Regex de toute MAC standard XX:XX:XX:XX:XX:XX ou XX-XX-XX-XX-XX-XX
    val formattedMacRegex = Regex("""(?i)\b([0-9A-F]{2}[:\-]){5}[0-9A-F]{2}\b""")
    formattedMacRegex.findAll(input).forEach { match ->
        val mac = match.value.uppercase().replace("-", ":")
        result.add(mac)
    }

    // 2. Recherche par jetons (mots séparés par espaces, virgules, points-virgules, sauts de ligne)
    val tokens = input.split(Regex("""[\s,;\t\n\r]+"""))
    val raw12HexRegex = Regex("""(?i)^[0-9A-F]{12}$""")
    for (tok in tokens) {
        val clean = tok.trim().trim('"', '\'', '[', ']', '(', ')', '{', '}', '=')
        if (clean.length == 12 && raw12HexRegex.matches(clean)) {
            val formatted = clean.uppercase().chunked(2).joinToString(":")
            result.add(formatted)
        }
    }

    return result.distinct()
}

data class ParsedPortalItem(
    val url: String,
    val mac: String,
    val domain: String
)

fun parseBulkPortalText(text: String): List<ParsedPortalItem> {
    val items = mutableListOf<ParsedPortalItem>()
    val lines = text.split("\n")
    val macRegex = Regex("(?i)([0-9a-f]{2}[:-]){5}[0-9a-f]{2}")
    val rawHexMacRegex = Regex("(?i)^[0-9a-f]{12}$")

    for (rawLine in lines) {
        val line = rawLine.trim()
        if (line.isEmpty() || line.startsWith("#")) continue

        val tokens = when {
            line.contains(",") -> line.split(",")
            line.contains("\t") -> line.split("\t")
            line.contains(";") -> line.split(";")
            line.contains("|") -> line.split("|")
            else -> line.split(Regex("\\s+"))
        }.map { it.trim() }.filter { it.isNotEmpty() }

        var foundUrl = ""
        var foundMac = ""

        for (token in tokens) {
            val cleanToken = token.replace("\"", "").replace("'", "").trim()
            if (macRegex.matches(cleanToken) || (cleanToken.length == 17 && cleanToken.count { it == ':' || it == '-' } == 5)) {
                foundMac = cleanToken
            } else if (rawHexMacRegex.matches(cleanToken)) {
                foundMac = cleanToken.chunked(2).joinToString(":")
            } else if (cleanToken.startsWith("http://") || cleanToken.startsWith("https://") || cleanToken.contains(".")) {
                if (foundUrl.isEmpty()) {
                    foundUrl = if (cleanToken.startsWith("http://") || cleanToken.startsWith("https://")) {
                        cleanToken
                    } else {
                        "http://$cleanToken"
                    }
                }
            }
        }

        if (foundUrl.isNotEmpty()) {
            val domain = try {
                val uri = android.net.Uri.parse(foundUrl)
                val host = uri.host ?: foundUrl.substringAfter("://").substringBefore("/").substringBefore(":")
                val clean = host.replace("www.", "").trim()
                if (clean.isNotEmpty()) clean else foundUrl
            } catch (e: Exception) {
                foundUrl.substringAfter("://").substringBefore("/").substringBefore(":")
            }

            items.add(ParsedPortalItem(url = foundUrl, mac = foundMac, domain = domain))
        }
    }
    return items
}

data class PlaybackInfo(
    val url: String,
    val headers: Map<String, String> = emptyMap()
)

sealed class ImportState {
    object Idle : ImportState()
    data class Loading(val message: String) : ImportState()
    data class Success(val message: String) : ImportState()
    data class Error(val message: String) : ImportState()
}

data class M3uSeriesInfo(
    val baseName: String,
    val season: String,
    val episode: String,
    val episodeTitle: String
)

fun parseM3uSeriesInfo(fullName: String): M3uSeriesInfo {
    val name = fullName.trim()
    
    // Pattern 1: S01E01, S1E1, S01 E01, S01 - E01, S1 EP 1, S1 Ep.1, S1 - Ep 1, S01-EP01 (case insensitive)
    val sXeyRegex = Regex("""(?i)\bS(\d+)\s*(?:-|E|EP|ÉP|EP\.|ÉP\.|EPISODE|ÉPISODE)?\s*E(?:P|ÉP|ISODE)?(?:\.)?\s*(\d+)\b""")
    sXeyRegex.find(name)?.let { match ->
        val seasonNum = match.groupValues[1].toIntOrNull()?.toString() ?: "1"
        val epNum = match.groupValues[2].toIntOrNull()?.toString() ?: "1"
        val matchIndex = match.range.first
        var base = name.substring(0, matchIndex).trim()
        base = cleanBaseName(base)
        val title = name.substring(match.range.last + 1).trim().removePrefix("-").removePrefix(":").trim()
        val epTitle = if (title.isNotEmpty()) title else "Épisode $epNum"
        return M3uSeriesInfo(base, seasonNum, epNum, epTitle)
    }

    // Pattern 2: 1x01 or 01x01 or 1x1 (case insensitive)
    val xRegex = Regex("""(?i)\b(\d+)\s*x\s*(\d+)\b""")
    xRegex.find(name)?.let { match ->
        val seasonNum = match.groupValues[1].toIntOrNull()?.toString() ?: "1"
        val epNum = match.groupValues[2].toIntOrNull()?.toString() ?: "1"
        val matchIndex = match.range.first
        var base = name.substring(0, matchIndex).trim()
        base = cleanBaseName(base)
        val title = name.substring(match.range.last + 1).trim().removePrefix("-").removePrefix(":").trim()
        val epTitle = if (title.isNotEmpty()) title else "Épisode $epNum"
        return M3uSeriesInfo(base, seasonNum, epNum, epTitle)
    }

    // Pattern 3: Saison 1 Episode 2 or Season 1 Ep 2 etc.
    val seasonEpRegex = Regex("""(?i)\b(?:SAISON|SEASON)\s*(\d+)\s*(?:-|EPISODE|EP|ÉPISODE|ÉP|EP\.|ÉP\.)\s*(\d+)\b""")
    seasonEpRegex.find(name)?.let { match ->
        val seasonNum = match.groupValues[1].toIntOrNull()?.toString() ?: "1"
        val epNum = match.groupValues[2].toIntOrNull()?.toString() ?: "1"
        val matchIndex = match.range.first
        var base = name.substring(0, matchIndex).trim()
        base = cleanBaseName(base)
        val title = name.substring(match.range.last + 1).trim().removePrefix("-").removePrefix(":").trim()
        val epTitle = if (title.isNotEmpty()) title else "Épisode $epNum"
        return M3uSeriesInfo(base, seasonNum, epNum, epTitle)
    }

    // Pattern 4: Saison 1 / Season 1 / Season 01
    val seasonOnlyRegex = Regex("""(?i)\b(?:SAISON|SEASON)\s*(\d+)\b""")
    val epOnlyRegex = Regex("""(?i)\b(?:EPISODE|EP|ÉPISODE|ÉP|E)(?:\.)?\s*(\d+)\b""")
    val sMatch = seasonOnlyRegex.find(name)
    val eMatch = epOnlyRegex.find(name)
    if (sMatch != null && eMatch != null) {
        val seasonNum = sMatch.groupValues[1].toIntOrNull()?.toString() ?: "1"
        val epNum = eMatch.groupValues[1].toIntOrNull()?.toString() ?: "1"
        val firstMatchIndex = minOf(sMatch.range.first, eMatch.range.first)
        var base = name.substring(0, firstMatchIndex).trim()
        base = cleanBaseName(base)
        return M3uSeriesInfo(base, seasonNum, epNum, "Épisode $epNum")
    } else if (sMatch != null) {
        val seasonNum = sMatch.groupValues[1].toIntOrNull()?.toString() ?: "1"
        var base = name.substring(0, sMatch.range.first).trim()
        base = cleanBaseName(base)
        return M3uSeriesInfo(base, seasonNum, "1", "Épisode 1")
    } else if (eMatch != null) {
        val epNum = eMatch.groupValues[1].toIntOrNull()?.toString() ?: "1"
        var base = name.substring(0, eMatch.range.first).trim()
        base = cleanBaseName(base)
        return M3uSeriesInfo(base, "1", epNum, "Épisode $epNum")
    }

    // Default fallback: if no pattern matches, return the name as is
    return M3uSeriesInfo(name, "1", "1", "Épisode 1")
}

fun normalizeBaseName(base: String): String {
    var b = base.lowercase().trim()
    // Remove tags in square brackets or parentheses
    b = b.replace(Regex("""\[[^\]]*\]"""), "")
    b = b.replace(Regex("""\([^)]*\)"""), "")
    // Remove common prefixes/suffixes
    val wordsToRemove = listOf("nf", "netflix", "vf", "vostfr", "multi", "fr", "en", "hd", "4k", "1080p", "720p")
    wordsToRemove.forEach { word ->
        b = b.replace(Regex("""\b$word\b"""), "")
    }
    // Remove special characters and clean up extra spaces
    b = b.replace(Regex("""[^a-z0-9\s]"""), " ")
    b = b.replace(Regex("""\s+"""), " ").trim()
    return b.ifEmpty { base.lowercase().trim() }
}

fun cleanBaseName(base: String): String {
    var b = base
    while (b.isNotEmpty() && (b.endsWith("-") || b.endsWith("/") || b.endsWith("|") || b.endsWith(":") || b.endsWith(" ") || b.endsWith("_"))) {
        b = b.substring(0, b.length - 1).trim()
    }
    return b.ifEmpty { "Série sans nom" }
}

fun cleanEpisodeTitle(rawTitle: String): String {
    if (rawTitle.isBlank()) return ""
    var title = rawTitle.trim()
    
    var changed = true
    var iterations = 0
    while (changed && iterations < 5) {
        iterations++
        val prev = title
        
        // Pattern 1: S01E01, S1E1, S01 E01, S01 - E01, S1 - Ep 1, S1 Ep 1, S1 - EPISODE 1, S01-EP01
        title = title.replace(Regex("""(?i)^\s*S\d+\s*(?:-|E|EP|ÉP|EP\.|ÉP\.|EPISODE|ÉPISODE)?\s*E(?:P|ÉP|ISODE)?(?:\.)?\s*\d+\s*(?:-|:|\.|\|)?\s*"""), "").trim()
        
        // Pattern 2: SAISON 1 - ÉPISODE 1, SEASON 1 EPISODE 1, SAISON 1 EP 1, SAISON 1 - EPISODE 1:
        title = title.replace(Regex("""(?i)^\s*(?:SAISON|SEASON|S)\s*\d+\s*(?:-|:|\.|\|)?\s*(?:ÉPISODE|EPISODE|ÉP|EP|E)?\s*\d+\s*(?:-|:|\.|\|)?\s*"""), "").trim()
        
        // Pattern 3: 1x01 - or 01x01 - 
        title = title.replace(Regex("""(?i)^\s*\d+\s*x\s*\d+\s*(?:-|:|\.|\|)?\s*"""), "").trim()
        
        // Pattern 4: ÉPISODE 1 - or EPISODE 1: or EP 1 - or SAISON 1 -
        title = title.replace(Regex("""(?i)^\s*(?:ÉPISODE|EPISODE|ÉP|EP|E|SAISON|SEASON)(?:\.)?\s*\d+\s*(?:-|:|\.|\|)?\s*"""), "").trim()
        
        changed = (title != prev)
    }
    
    // Remove leading punctuation like "-", ":", "|", "." left over
    title = title.replace(Regex("""^\s*[-:|\.]+\s*"""), "").trim()
    
    return title
}

private fun androidx.media3.exoplayer.ExoPlayer.experimentalSetOffloadSchedulingEnabled(enabled: Boolean) {
    try {
        val m = this.javaClass.getMethod("experimentalSetOffloadSchedulingEnabled", java.lang.Boolean.TYPE)
        m.invoke(this, enabled)
    } catch (_: Throwable) {
        // En Media3 l'offload scheduling est désactivé via TrackSelectionParameters.AudioOffloadPreferences
    }
}

