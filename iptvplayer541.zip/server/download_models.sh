#!/usr/bin/env bash
set -e

# ==============================================================================
# Script de téléchargement des modèles Sherpa-ONNX pour Serveur Ubuntu
# Modèles : 
# 1. Silero VAD (Détection d'activité vocale temps réel)
# 2. Streaming-Zipformer Français (Transcription Live faible latence)
# 3. Whisper-Small Offline (Transcription VOD haute précision)
# ==============================================================================

MODELS_DIR="$(dirname "$0")/models"
mkdir -p "$MODELS_DIR"
cd "$MODELS_DIR"

echo "=== 1. Téléchargement de Silero VAD ==="
if [ ! -f "silero_vad.onnx" ]; then
    wget -c https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/silero_vad.onnx
else
    echo "silero_vad.onnx déjà présent."
fi

echo "=== 2. Téléchargement du modèle Live Streaming (Zipformer Français) ==="
STREAMING_MODEL_TAR="sherpa-onnx-streaming-zipformer-fr-2023-04-14.tar.bz2"
STREAMING_MODEL_DIR="sherpa-onnx-streaming-zipformer-fr-2023-04-14"

if [ ! -d "$STREAMING_MODEL_DIR" ]; then
    wget -c "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/$STREAMING_MODEL_TAR"
    tar xvf "$STREAMING_MODEL_TAR"
    rm -f "$STREAMING_MODEL_TAR"
else
    echo "$STREAMING_MODEL_DIR déjà présent."
fi

echo "=== 3. Téléchargement du modèle VOD Offline (Whisper-Small) ==="
WHISPER_MODEL_TAR="sherpa-onnx-whisper-small.tar.bz2"
WHISPER_MODEL_DIR="sherpa-onnx-whisper-small"

if [ ! -d "$WHISPER_MODEL_DIR" ]; then
    wget -c "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/$WHISPER_MODEL_TAR"
    tar xvf "$WHISPER_MODEL_TAR"
    rm -f "$WHISPER_MODEL_TAR"
else
    echo "$WHISPER_MODEL_DIR déjà présent."
fi

echo "=== Tous les modèles sont prêts dans : $MODELS_DIR ==="
ls -lh "$MODELS_DIR"
